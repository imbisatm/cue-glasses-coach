"""Printable props for the demo: big labels the glasses camera can read through a video call."""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas

W, H = letter
M = 0.6 * inch


def wrap(c, text, font, size, width):
    words, lines, line = text.split(), [], ""
    for w in words:
        trial = f"{line} {w}".strip()
        if c.stringWidth(trial, font, size) <= width:
            line = trial
        else:
            lines.append(line)
            line = w
    if line:
        lines.append(line)
    return lines


def label(c, x, y, w, h, title, body, note=""):
    c.setLineWidth(2)
    c.setDash(6, 4)
    c.rect(x, y, w, h)  # dashed = cut line
    c.setDash()
    c.setFont("Helvetica-Bold", 30)
    c.drawString(x + 18, y + h - 46, title)
    size = 20
    ty = y + h - 84
    for line in wrap(c, body, "Helvetica-Bold", size, w - 36):
        c.setFont("Helvetica-Bold", size)
        c.drawString(x + 18, ty, line)
        ty -= size * 1.25
    if note:
        c.setFont("Helvetica", 9)
        c.drawString(x + 18, y + 10, note)


def header(c, text, sub):
    c.setFont("Helvetica-Bold", 16)
    c.drawString(M, H - M, text)
    c.setFont("Helvetica", 10)
    c.drawString(M, H - M - 16, sub)


c = canvas.Canvas("props_to_print.pdf", pagesize=letter)
c.setTitle("Cue demo props")

# Page 1: weight labels
header(c, "1. Weight labels (gym)", "Cut out and tape one on each end of the dumbbell or water jug, facing you.")
for i, (txt, y) in enumerate((("10 LB", H - 3.3 * inch), ("10 LB", H - 5.9 * inch), ("8 LB", H - 8.5 * inch))):
    for col in range(2):
        x = M + col * 3.7 * inch
        c.setDash(6, 4); c.rect(x, y, 3.4 * inch, 2.2 * inch); c.setDash()
        c.setFont("Helvetica-Bold", 78)
        tw = c.stringWidth(txt, "Helvetica-Bold", 78)
        c.drawString(x + (3.4 * inch - tw) / 2, y + 0.75 * inch, txt)
c.showPage()

# Page 2: allergy labels
header(c, "2. Food labels (allergy check, beta)", "Tape over the back of two snack packets. Set your food rule to 'no peanuts' or 'no milk'.")
label(c, M, H - 5.4 * inch, W - 2 * M, 4.1 * inch, "TRAIL MIX",
      "INGREDIENTS: PEANUTS, ALMONDS, RAISINS, MILK CHOCOLATE (SUGAR, MILK, COCOA BUTTER), SALT. "
      "CONTAINS: PEANUTS, TREE NUTS, MILK.")
label(c, M, H - 9.9 * inch, W - 2 * M, 4.1 * inch, "RICE CRACKERS",
      "INGREDIENTS: WHOLE GRAIN BROWN RICE, SUNFLOWER OIL, SEA SALT. "
      "MADE IN A FACILITY FREE FROM PEANUTS AND TREE NUTS.")
c.showPage()

# Page 3: medicine + cleaning
header(c, "3. Medicine and cleaning labels (beta)", "Use EMPTY bottles only. Put mints or candy in the pill bottle. No real chemicals at the booth.")
label(c, M, H - 4.1 * inch, W - 2 * M, 2.8 * inch, "VITAMIN D3 1000 IU",
      "TAKE 1 TABLET ONCE DAILY WITH FOOD. DO NOT TAKE MORE THAN 1 PER DAY.",
      "Demo prop: bottle contains mints.")
label(c, M, H - 7.1 * inch, W - 2 * M, 2.8 * inch, "BLEACH",
      "WARNING: NEVER MIX WITH AMMONIA OR ACIDS. MIXING RELEASES TOXIC GAS.",
      "Demo prop: empty bottle.")
label(c, M, H - 10.1 * inch, W - 2 * M, 2.8 * inch, "GLASS CLEANER",
      "CONTAINS AMMONIA. DO NOT MIX WITH BLEACH.",
      "Demo prop: empty bottle.")
c.showPage()

# Page 4: recipe card + station signs
header(c, "4. Recipe card and station signs", "Recipe card goes on the kitchen table. Signs fold in half to stand up.")
c.setDash(6, 4); c.rect(M, H - 5.0 * inch, W - 2 * M, 3.7 * inch); c.setDash()
c.setFont("Helvetica-Bold", 30); c.drawString(M + 18, H - 1.85 * inch, "Kitchen basics")
c.setFont("Helvetica-Bold", 20)
for i, step in enumerate(["1. Put the bowl in front of you",
                          "2. Add 1 teaspoon of water",
                          "3. Add 1 tablespoon of water",
                          "4. Cut a folded paper towel in half (claw grip!)"]):
    c.drawString(M + 18, H - (2.4 + i * 0.52) * inch, step)
c.setFont("Helvetica", 12)
c.drawString(M + 18, H - 4.75 * inch, "Cue checks each step through your glasses before moving on.")
for i, sign in enumerate(("GYM", "KITCHEN")):
    x = M + i * 3.7 * inch
    y = 0.8 * inch
    c.setDash(6, 4); c.rect(x, y, 3.4 * inch, 4.2 * inch); c.setDash()
    c.line(x, y + 2.1 * inch, x + 3.4 * inch, y + 2.1 * inch)  # fold line
    c.setFont("Helvetica-Bold", 44)
    tw = c.stringWidth(sign, "Helvetica-Bold", 44)
    c.drawString(x + (3.4 * inch - tw) / 2, y + 2.9 * inch, sign)
    c.setFont("Helvetica", 13)
    sub = "Cue counts your reps" if sign == "GYM" else "Cue checks every step"
    tw = c.stringWidth(sub, "Helvetica", 13)
    c.drawString(x + (3.4 * inch - tw) / 2, y + 2.45 * inch, sub)
c.showPage()

# ---- page 5: spoon labels ----
header(c, "5. Spoon labels (kitchen)", "Cut out and tape around each printed spoon handle so the camera can read it (black-on-black lettering is too hard to see).")
for i, (txt, n) in enumerate([("TSP", 4), ("TBSP", 4)]):
    for j in range(n):
        x = M + j * 1.85 * inch
        y = H - (2.2 + i * 1.5) * inch
        c.setDash(4, 3); c.rect(x, y, 1.7 * inch, 1.0 * inch); c.setDash()
        c.setFont("Helvetica-Bold", 34 if txt == "TSP" else 28)
        c.drawCentredString(x + 0.85 * inch, y + 0.32 * inch, txt)
c.showPage()

# ---- page 6: skill library sign ----
header(c, "6. Skill Library sign (table)", "Stand it next to the laptop. Point at it during the 'how it works' part of the demo.")
c.setFont("Helvetica-Bold", 40); c.drawString(M, H - 1.9 * inch, "Cue Skill Library")
c.setFont("Helvetica", 14); c.drawString(M, H - 2.25 * inch, "Every skill = a plan of steps + what the glasses check + how Cue corrects you.")
rows = [
    ("TESTED", ["Gym: rep count, tempo, reads the weight", "Cooking: claw grip, right spoon, step order"]),
    ("BETA", ["Hand washing, allergy check, medicine dose", "Cleaning (never mix bleach + ammonia)"]),
    ("ROADMAP", ["Laundry, homework, breadboard wiring, running, jump rope,", "CPR, guitar, piano / rehab, drawing, food safety,", "baby formula, repairs, car basics"]),
]
y = H - 3.0 * inch
for tag, lines in rows:
    c.setLineWidth(1.5); c.roundRect(M, y - 0.95 * inch, W - 2 * M, 1.1 * inch, 10)
    c.setFont("Helvetica-Bold", 22); c.drawString(M + 16, y - 0.35 * inch, tag)
    c.setFont("Helvetica", 13)
    for k, line in enumerate(lines):
        c.drawString(M + 2.3 * inch, y - (0.2 + 0.26 * k) * inch, line)
    y -= 1.35 * inch
c.setFont("Helvetica-Oblique", 12)
c.drawString(M, y - 0.2 * inch, "Meta glasses see it  ->  AI checks the step  ->  voice + Cue Clip buzz correct you, in the moment.")
c.showPage()
c.save()
print("saved props_to_print.pdf")
