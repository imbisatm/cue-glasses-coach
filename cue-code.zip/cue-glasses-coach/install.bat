@echo off
cd /d "%~dp0"
echo === Setting up Cue (this takes a few minutes) ===
set "PY="
py -3.12 --version >nul 2>&1 && set "PY=py -3.12"
if not defined PY (py -3.11 --version >nul 2>&1 && set "PY=py -3.11")
if not defined PY (
  echo.
  echo Python 3.12 was not found.
  echo Install it from https://www.python.org/downloads/release/python-31210/
  echo   - scroll down and pick "Windows installer (64-bit)"
  echo   - on the first screen, tick "Add python.exe to PATH"
  echo Then double-click install.bat again.
  pause
  exit /b 1
)
echo Using %PY%
%PY% -m venv .venv
if errorlevel 1 (
  echo Could not create the Python environment. Send this window's text to Claude.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed. Copy the text above and send it to Claude.
  pause
  exit /b 1
)
echo.
echo === Done! Next: double-click run_webcam_test.bat ===
pause
