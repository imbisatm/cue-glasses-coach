"""Habit rules with a fake model answer (no network)."""

import time

from cue_core import habits as H
from cue_core.habits import HabitCoach, parse_observation


def coach(mode):
    c = HabitCoach()
    c.clock.mode = mode
    return c


def obs(*seen, **flags):
    return parse_observation({"seen": list(seen), **flags})


def test_same_coffee_morning_vs_night():
    m = coach("morning").observe(obs("coffee"))
    n = coach("night").observe(obs("energy_drink"))
    assert m and not m[0].warn and "Last call" in m[0].text
    assert n and n[0].warn and "Put the energy drink back" in n[0].text


def test_water_logs_and_cools_down():
    c = coach("afternoon")
    assert "Water logged" in c.observe(obs("drinking_water"))[0].text
    assert c.observe(obs("drinking_water")) == []          # same sip, 30 s cooldown
    assert c.stats.water_ml == 250
    c._last.clear()
    c.observe(obs("drinking_water"))
    assert c.stats.water_ml == 500 and c.status("water")[1] == "0.5 of 2 L"


def test_scrolling_warns_right_away_and_depends_on_time():
    c = coach("afternoon")
    n = c.observe(obs("phone_scrolling"))
    assert n and "walk" in n[0].text and n[0].warn
    assert c.observe(obs("phone_scrolling")) == []          # cooldown: not every frame
    c = coach("night")
    n = c.observe(obs("phone_scrolling", "screen"))
    assert "Phone down" in n[0].text and c.stats.night_screen == 1
    assert c.status("screens")[0] == "warn"


def test_morning_sun_counts_only_in_the_morning():
    c = coach("morning")
    n = c.observe(obs(outdoors=True, sunlight=True), dt=4)
    assert "Morning light" in n[0].text and c.stats.sun_s == 4
    c.clock.mode = "afternoon"
    c.observe(obs(outdoors=True, sunlight=True), dt=4)
    assert c.stats.sun_s == 4 and c.stats.outside_s == 8


def test_unknown_ids_ignored_and_score_moves():
    c = coach("afternoon")
    assert parse_observation({"seen": ["laser", "Drinking_Water"]})["seen"] == ["drinking_water"]
    base = c.score()
    c.observe(obs("drinking_water", "fruit_veg"))
    assert c.score() > base
    c.clock.mode = "morning"
    c.observe(obs("coffee"))
    c.clock.mode = "night"
    c._last.clear()
    c.observe(obs("coffee"))
    assert c.stats.caffeine_late == 1 and c.status("caffeine")[0] == "warn"


def test_prompt_lists_every_sign():
    p = H.build_prompt()
    assert all(k in p for k in H.SIGNS)


def test_demo_clock_switch_gives_new_verdict_immediately():
    c = coach("morning")
    assert "Last call" in c.observe(obs("coffee"))[0].text
    c.set_clock("night")
    n = c.observe(obs("coffee"))
    assert n and n[0].warn and "Put the coffee back" in n[0].text


def test_vape_warns_right_away_with_quitline_once():
    c = coach("afternoon")
    assert c.status("nicotine") == ("done", "Free today")
    n = c.observe(obs("vape"))
    assert n and n[0].warn and "Craving" in n[0].text and "QUIT-NOW" in n[0].text
    c._last.clear()
    n = c.observe(obs("vape"))
    assert "2 today" in n[0].text and "QUIT-NOW" not in n[0].text
    assert c.status("nicotine")[0] == "warn"


def test_bad_habits_lower_the_score():
    c = coach("afternoon")
    base = c.score()
    c.observe(obs("soda"))
    c.observe(obs("betting")); c.observe(obs("betting"))
    assert c.stats.soda == 1 and c.stats.betting == 1 and c.score() < base


def test_model_wording_and_note_still_count():
    o = parse_observation({"seen": ["water bottle", "E-Cigarette"], "note": ""})
    assert o["seen"] == ["drinking_water", "vape"]
    o = parse_observation({"seen": [], "note": "Holding a water bottle at a desk"})
    assert "drinking_water" in o["seen"]
    assert parse_observation({"seen": [], "note": "No water bottle visible"})["seen"] == []
    c = coach("afternoon")
    assert "Water logged" in c.observe(parse_observation({"seen": [], "note": "holding up a water bottle"}))[0].text


def test_night_laptop_screen_warns_right_away():
    c = coach("night")
    n = c.observe(obs("screen", "desk"))
    assert n and n[0].warn and "screen away" in n[0].text
