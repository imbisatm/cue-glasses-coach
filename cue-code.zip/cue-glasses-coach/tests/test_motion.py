import numpy as np
import pytest

from cue_core.motion import (
    RepCounter,
    TempoTarget,
    target_from_reps,
    VerticalMotionTracker,
    dtw_distance,
    target_curve,
    tempo_feedback,
)

RATE = 15.0  # frames per second, like the call video


def make_session(reps, rate=RATE, depth=30.0, rest=1.0, noise=0.6, drift=0.4, sign=-1, seed=0):
    """Fake height signal: rest, then reps with given (down, up) seconds."""
    rng = np.random.default_rng(seed)
    parts = [np.zeros(int(rest * rate))]
    for down, up in reps:
        parts.append(sign * depth * target_curve(down, up, rate))
        parts.append(np.zeros(int(0.4 * rate)))
    parts.append(np.zeros(int(rest * rate)))
    sig = np.concatenate(parts)
    t = np.arange(len(sig)) / rate
    sig = sig + drift * t + rng.normal(0, noise, len(sig))
    return t, sig


@pytest.mark.parametrize("sign", [-1, 1])
def test_counts_reps_either_direction(sign):
    reps = [(2.0, 1.5)] * 6
    t, sig = make_session(reps, sign=sign)
    rc = RepCounter(threshold=6.0)
    events = [e for ti, v in zip(t, sig) if (e := rc.update(ti, v))]
    assert len(events) == 6
    for e in events:
        # 10%->90% of a smooth 2 s / 1.5 s rep is about 1.18 s / 0.89 s
        assert e.down_time == pytest.approx(1.18, abs=0.35)
        assert e.up_time == pytest.approx(0.89, abs=0.35)


def test_fast_rep_flagged():
    t, sig = make_session([(2.0, 1.5), (0.5, 0.5)])
    rc = RepCounter(threshold=6.0)
    events = [e for ti, v in zip(t, sig) if (e := rc.update(ti, v))]
    assert len(events) == 2
    good, _ = tempo_feedback(events[0], TempoTarget())
    bad, cue = tempo_feedback(events[1], TempoTarget())
    assert good and not bad and "Slower" in cue


def test_small_wobble_is_not_a_rep():
    t = np.arange(0, 10, 1 / RATE)
    sig = 2.0 * np.sin(2 * np.pi * 0.5 * t)
    rc = RepCounter(threshold=6.0)
    assert not any(rc.update(ti, v) for ti, v in zip(t, sig))


def test_dtw_prefers_same_shape():
    ideal = target_curve(2.0, 1.5)
    slower_same_shape = target_curve(3.0, 2.2)
    jerky = np.concatenate([np.ones(5), np.zeros(20), np.ones(5)])
    assert dtw_distance(ideal, slower_same_shape) < 0.05
    assert dtw_distance(ideal, jerky) > dtw_distance(ideal, slower_same_shape)


def test_tracker_follows_vertical_camera_motion():
    rng = np.random.default_rng(1)
    world = (rng.random((900, 400)) * 255).astype(np.uint8)
    world = np.dstack([world] * 3)
    import cv2

    world = cv2.GaussianBlur(world, (5, 5), 0)
    tracker = VerticalMotionTracker(width=160)
    offsets = list(range(200, 260, 3)) + list(range(260, 200, -3))
    positions = []
    for off in offsets:
        frame = world[off : off + 300, 50:350]
        positions.append(tracker.update(frame))
    positions = np.array(positions)
    swing = positions.max() - positions.min()
    # 60 px of camera travel at 300 px tall, scaled to 160 px wide -> ~32 units
    assert swing > 20
    assert abs(positions[-1] - positions[0]) < 6  # comes back to start


def test_calibration_from_good_reps():
    t, sig = make_session([(2.0, 1.5)] * 3 + [(0.6, 0.6)])
    rc = RepCounter(threshold=6.0)
    events = [e for ti, v in zip(t, sig) if (e := rc.update(ti, v))]
    target = target_from_reps(events[:3])
    assert all(tempo_feedback(e, target)[0] for e in events[:3])
    assert not tempo_feedback(events[3], target)[0]


def _simulate_clip_curls(mount, n_reps=6, seed=0, step_mg=46.9):
    """Fake clip data: dumbbell on the table, picked up, held, then n curls. Returns (t, pitch, roll) lists
    computed exactly like the Arduino does (smoothed x/y/z -> pitch/roll)."""
    rng = np.random.default_rng(seed)

    def rot(axis, deg):
        a = np.radians(deg)
        c, s = np.cos(a), np.sin(a)
        x, y, z = axis
        return np.array([[c + x*x*(1-c), x*y*(1-c) - z*s, x*z*(1-c) + y*s],
                         [y*x*(1-c) + z*s, c + y*y*(1-c), y*z*(1-c) - x*s],
                         [z*x*(1-c) - y*s, z*y*(1-c) + x*s, c + z*z*(1-c)]])

    ease = lambda f: (1 - np.cos(np.pi * np.clip(f, 0, 1))) / 2
    # timeline of (duration, pickup_deg_start, pickup_deg_end, curl_deg_start, curl_deg_end)
    plan = [(2.0, 0, 0, 0, 0), (1.0, 0, 90, 0, 0), (2.0, 90, 90, 0, 0)]
    for _ in range(n_reps):
        plan += [(1.0, 90, 90, 0, 120), (0.2, 90, 90, 120, 120), (1.6, 90, 90, 120, 0), (0.4, 90, 90, 0, 0)]
    plan += [(2.0, 90, 90, 0, 0)]
    ts, ps, rs = [], [], []
    sx = sy = sz = None
    t = 0.0
    for dur, p0, p1, c0, c1 in plan:
        for i in range(int(dur * 50)):
            f = ease(i / (dur * 50))
            # curl = swing about a horizontal (world X) axis; pickup = turn about another horizontal axis
            dumbbell = rot((1, 0, 0), c0 + (c1 - c0) * f) @ rot((0, 1, 0), p0 + (p1 - p0) * f)
            g = (dumbbell @ mount).T @ np.array([0, 0, 1.0]) * 1000 + rng.normal(0, 15, 3)
            g = np.round(g / step_mg) * step_mg
            if sx is None:
                sx, sy, sz = g
            sx, sy, sz = 0.7 * sx + 0.3 * g[0], 0.7 * sy + 0.3 * g[1], 0.7 * sz + 0.3 * g[2]
            ts.append(t)
            ps.append(np.degrees(np.arctan2(-sx, np.hypot(sy, sz))))
            rs.append(np.degrees(np.arctan2(sy, sz)))
            t += 0.02
    return ts, ps, rs


def test_clip_counts_curls_in_any_mounting():
    from scipy.spatial.transform import Rotation

    from cue_core.motion import RepCounter, TiltTracker

    for seed in range(20):
        mount = Rotation.random(random_state=seed).as_matrix()
        ts, ps, rs = _simulate_clip_curls(mount, n_reps=6, seed=seed)
        counter, tilt = RepCounter(threshold=20.0, smoothing=0.2), TiltTracker()
        for t, p, r in zip(ts, ps, rs):
            ang, relearned = tilt.update(t, p, r, counter.state == RepCounter.REST)
            if relearned:
                counter.rebase(0.0)
            counter.update(t, ang)
        assert counter.count == 6, f"mount {seed}: counted {counter.count}"
        assert all(100 < rep.depth < 135 for rep in counter.reps), f"mount {seed}: depths {[r.depth for r in counter.reps]}"
        lifts = [rep.down_time for rep in counter.reps]
        lowers = [rep.up_time for rep in counter.reps]
        assert np.mean(lowers) > np.mean(lifts), f"mount {seed}: lift/lower timing swapped"


def test_tempo_feedback_words():
    from cue_core.motion import CLIP_TEMPO, RepEvent, tempo_feedback

    fast_lift = RepEvent(1, 0, 0.3, 1.5, 100, down_time=0.15, up_time=1.0)
    good, cue = tempo_feedback(fast_lift, CLIP_TEMPO, away="up", back="down")
    assert not good and cue == "Slower on the way up"
