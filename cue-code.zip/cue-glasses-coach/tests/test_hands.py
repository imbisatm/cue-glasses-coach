import numpy as np

from cue_core.hands import ClawGripMonitor, HandReading, curl_ratio


def hand(tip_y):
    """Simple upright hand: wrist at 0, knuckles going up, fingertip at tip_y."""
    pts = np.zeros((21, 2))
    for base, x in ((5, -0.3), (9, 0.0), (13, 0.3), (17, 0.55)):
        pts[base] = [x, -1.0]      # big knuckle (MCP)
        pts[base + 1] = [x, -1.45]  # middle knuckle (PIP)
        pts[base + 2] = [x, -1.7]
        pts[base + 3] = [x, tip_y]  # fingertip
    return pts


def test_flat_vs_curled():
    assert curl_ratio(hand(-2.0)) > 1.3   # straight fingers
    assert curl_ratio(hand(-1.2)) < 1.0   # tips tucked under


def test_monitor_needs_flat_for_half_a_second():
    m = ClawGripMonitor(hold=0.5)
    flat = [HandReading(points=hand(-2.0), ratio=1.4, flat=True)]
    assert not m.update(flat, now=0.0)
    assert not m.update(flat, now=0.3)
    assert m.update(flat, now=0.6)
    assert not m.update([], now=0.7)  # hand curled/gone resets the timer
