"""CPR detector on simulated clip data: MMA7660 steps (46.9 mg), +-1.5 g limit, random mounting,
USB timing jitter, and the clip's own buzz shaking the sensor."""

import math

import numpy as np
from scipy.spatial.transform import Rotation

from cue_core.cpr import CprDrill, CompressionDetector

STEP = 46.9


def simulate(bpm, depth_cm, seconds, seed=0, buzz_at=(), rest_before=1.5, mount=None, harmonic=0.3):
    """Returns (times, amag_mg) at 50 per second for compressions on a pillow."""
    rng = np.random.default_rng(seed)
    R = mount if mount is not None else Rotation.random(random_state=seed).as_matrix()
    f = bpm / 60.0
    out_t, out_a = [], []
    n = int((seconds + rest_before) * 50)
    for i in range(n):
        t = i / 50.0 + rng.normal(0, 0.004)
        tc = t - rest_before
        if tc < 0 or tc > seconds:
            av = 0.0
        else:
            w = 2 * math.pi * f
            # displacement D/2 (1 - cos wt) plus a sharper bottom (2nd harmonic); accel = 2nd derivative
            av = depth_cm / 100 / 2 * (w ** 2 * math.cos(w * tc) + harmonic * (2 * w) ** 2 * math.cos(2 * w * tc) / 4)
        rock = math.radians(4) * math.sin(2 * math.pi * f * max(tc, 0))   # wrist rocks a little
        Rr = Rotation.from_euler("x", rock).as_matrix() @ R
        spec = np.array([0, 0, 1.0 + av / 9.81])              # what an accelerometer feels, in g
        body = Rr.T @ spec
        if any(b <= t < b + 0.55 for b in buzz_at):              # servo wiggle shakes the sensor
            body = body + rng.normal(0, 0.45, 3)
        steps = np.clip(np.round(body * 1000 / STEP + rng.normal(0, 0.35, 3)), -32, 31)
        mg = steps * STEP
        out_t.append(t)
        out_a.append(round(float(np.linalg.norm(mg))))
    return out_t, out_a


def run(bpm, depth=5.0, seconds=30, seed=0, buzz_at=()):
    drill = CprDrill(seconds=seconds)
    cues = []
    ts, amags = simulate(bpm, depth, seconds + 1.5, seed, buzz_at)
    for t, a in zip(ts, amags):
        for b in buzz_at:
            if abs(t - b) < 0.011:
                drill.blind(t + 0.6)
        cues += [c.text for c in drill.update(t, a)]
    return drill, cues


def test_counts_and_rate_at_good_pace():
    for seed in range(8):
        drill, cues = run(110, seed=seed)
        s = drill.summary
        expected = 110 * 30 / 60
        assert s is not None
        assert abs(s["count"] - expected) <= 2, (seed, s["count"], expected)
        assert abs(s["avg_rate"] - 110) <= 5, (seed, s["avg_rate"])
        assert s["pct"] >= 85, (seed, s["pct"])
        assert "Faster" not in cues and "Slower" not in cues, (seed, cues)


def test_slow_and_fast_get_coached():
    drill, cues = run(80, seed=3)
    assert "Faster" in cues and drill.summary["pct"] < 20
    assert abs(drill.summary["avg_rate"] - 80) <= 5
    drill, cues = run(140, seed=4)
    assert "Slower" in cues and drill.summary["pct"] < 20
    assert abs(drill.summary["avg_rate"] - 140) <= 6


def test_depth_estimate_tells_light_from_firm():
    firm = [run(110, depth=5.0, seed=s)[0].summary["depth_cm"] for s in range(4)]
    light = [run(110, depth=1.5, seed=s)[0].summary["depth_cm"] for s in range(4)]
    assert all(3.5 <= d <= 7.5 for d in firm), firm
    assert all(d < 2.8 for d in light if d is not None), light
    assert "Push harder" in run(110, depth=1.5, seed=1)[1]


def test_buzz_gaps_are_filled_in():
    drill, cues = run(110, seed=5, buzz_at=(6.0, 12.0, 18.0, 24.0))
    assert abs(drill.summary["count"] - 55) <= 3, drill.summary["count"]


def test_no_false_counts_at_rest():
    det = CompressionDetector()
    ts, amags = simulate(110, 5.0, seconds=0.0, rest_before=12.0, seed=9)
    assert sum(det.update(t, a) is not None for t, a in zip(ts, amags)) == 0
