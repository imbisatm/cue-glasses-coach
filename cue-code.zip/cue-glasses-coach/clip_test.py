"""Cue Clip test: checks the USB connection, the motion sensor and the servo.

Double-click run_clip_test.bat. You should see:
  1. "connected"
  2. live tilt numbers that change when you tilt the clip
  3. a short buzz every 4 seconds
  4. "REP n" when you do a curl with the clip on a bottle or dumbbell
Close the window (or press Ctrl+C) to stop.
"""

import time

from cue_core.clip import GOOD
from cue_core.config import load_config
from cue_core.serial_clip import make_clip
from cue_core.motion import RepCounter, TiltTracker


def main() -> None:
    clip = make_clip(load_config())
    counter = RepCounter(threshold=20.0, smoothing=0.2)  # degrees turned from rest
    tilt = TiltTracker()
    t0 = time.monotonic()
    last_print = last_buzz = 0.0
    last_status = ""
    try:
        while True:
            now = time.monotonic()
            if clip.status != last_status:
                print(f"[clip] {clip.status}")
                last_status = clip.status
            for s in clip.new_samples():
                ang, relearned = tilt.update(s.t - t0, s.pitch, s.roll, counter.state == RepCounter.REST)
                if relearned:
                    counter.rebase(0.0)
                    print("   (learned the resting position)")
                rep = counter.update(s.t - t0, ang)
                if rep:
                    print(f"   REP {rep.number}: up {rep.down_time:.1f}s  down {rep.up_time:.1f}s  ({rep.depth:.0f} degrees)")
                    clip.buzz(GOOD)
            if clip.connected:
                s = clip.latest()
                if s and now - last_print > 0.25:
                    print(f"moved {counter.deviation:6.1f} deg from rest   (tilt {s.pitch:6.1f}  side {s.roll:6.1f}  accel {s.accel_mg:5.0f} mg)")
                    last_print = now
                if now - last_buzz > 4:
                    clip.buzz(GOOD)
                    last_buzz = now
            time.sleep(0.02)
    except KeyboardInterrupt:
        pass
    finally:
        clip.close()


if __name__ == "__main__":
    main()
