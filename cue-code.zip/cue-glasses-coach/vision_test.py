"""Checks the vision model on AMD (or the Hugging Face backup).

Double-click run_vision_test.bat. The first time, paste the endpoint URL when asked.
It runs 3 tests and prints PASS/FAIL with how long each answer took.
"""

import sys

import cv2
import numpy as np

from cue_core.config import load_config, save_config
from cue_core.vision import make_vision_client


def test_image_weight() -> np.ndarray:
    img = np.full((360, 640, 3), 235, np.uint8)
    cv2.rectangle(img, (120, 150), (520, 210), (60, 60, 60), -1)  # handle
    for x in (90, 470):
        cv2.rectangle(img, (x, 90), (x + 80, 270), (30, 30, 30), -1)  # weights
    cv2.putText(img, "10 LB", (480, 190), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 3)
    cv2.putText(img, "10 LB", (98, 190), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 3)
    return img


def test_image_label() -> np.ndarray:
    img = np.full((400, 640, 3), 250, np.uint8)
    lines = ["CRUNCHY GRANOLA BAR", "INGREDIENTS: OATS, SUGAR,", "PEANUTS, MILK POWDER, SALT.", "CONTAINS: PEANUTS, MILK."]
    for i, line in enumerate(lines):
        cv2.putText(img, line, (30, 80 + i * 75), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (20, 20, 20), 2)
    return img


def main() -> int:
    cfg = load_config()
    if not cfg.get("vision_url"):
        cfg["vision_url"] = input("Paste the endpoint URL (from the AMD page) and press ENTER:\n> ").strip()
        save_config(cfg)
    client = make_vision_client(cfg)
    print(f"\nTalking to: {client.base_url}  (model: {client.model})\n")
    results = []

    print("1) Is the model online?")
    try:
        models = client.list_models()
        print(f"   models: {models[:5]}{' ...' if len(models) > 5 else ''}")
        # A vLLM server lists only its own model(s); a big hosted router (Hugging Face) lists hundreds,
        # so only auto-switch the model name when the list is short.
        if models and client.model not in models and len(models) <= 5:
            print(f"   note: '{client.model}' isn't listed; using '{models[0]}' instead")
            client.model = models[0]
            cfg["vision_model"] = models[0]
            save_config(cfg)
        results.append(("online", True))
    except Exception as exc:
        # some services (like Gemini) may not list models; carry on and let the real tests decide
        print(f"   (couldn't list models: {str(exc)[:120]}) - trying the tests anyway")

    print("2) Read the weight on a dumbbell picture")
    try:
        weight, unit = client.read_weight(test_image_weight())
        ok = weight == 10
        print(f"   {'PASS' if ok else 'FAIL'}: read {weight} {unit}  ({client.last_latency:.1f} s)")
        results.append(("weight", ok))
    except Exception as exc:
        print(f"   FAIL: {exc}")
        results.append(("weight", False))

    print("3) Read a food label and spot the allergens")
    try:
        text = client.read_label(test_image_label())
        ok = "PEANUT" in text.upper() and "MILK" in text.upper()
        print(f"   {'PASS' if ok else 'FAIL'}: ({client.last_latency:.1f} s)\n   {text[:200]}")
        results.append(("label", ok))
    except Exception as exc:
        print(f"   FAIL: {exc}")
        results.append(("label", False))

    print("4) Yes/no step check")
    try:
        answer, reason = client.check(test_image_weight(), "A dumbbell is visible")
        ok = answer == "yes"
        print(f"   {'PASS' if ok else 'FAIL'}: {answer} - {reason}  ({client.last_latency:.1f} s)")
        results.append(("check", ok))
    except Exception as exc:
        print(f"   FAIL: {exc}")
        results.append(("check", False))

    passed = sum(ok for _, ok in results)
    print(f"\n{passed}/{len(results)} passed. Send this whole window to Claude.")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
