/*
  Cue Clip firmware
  -----------------
  An ESP32 + MPU6050 motion sensor + vibration motor that straps onto a tool
  (dumbbell, spatula...). It:
    - streams the tool's tilt and rotation to the laptop over Bluetooth (50 times a second)
    - buzzes when the laptop tells it to (good rep, warning, or a steady rhythm)

  Works on ESP32, ESP32-C3 and ESP32-S3 boards (NOT ESP32-S2: no Bluetooth).
  No extra libraries needed: only what comes with "esp32 by Espressif".

  Wiring (see WIRING.md):
    MPU6050 VCC -> 3V3      MPU6050 GND -> GND
    MPU6050 SDA -> SDA pin  MPU6050 SCL -> SCL pin   (printed in Serial Monitor at start)
    Vibration module IN/SIG -> MOTOR_PIN, VCC -> 3V3, GND -> GND
*/

#include <Arduino.h>
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ---------- pins (change here if your board needs it) ----------
#if defined(CONFIG_IDF_TARGET_ESP32C3)
  #define MOTOR_PIN 3
#elif defined(CONFIG_IDF_TARGET_ESP32S3)
  #define MOTOR_PIN 4
#else
  #define MOTOR_PIN 25   // classic ESP32 DevKit
#endif

// ---------- Bluetooth IDs (the laptop looks for these) ----------
#define DEVICE_NAME  "CueClip"
#define SERVICE_UUID "6e5a0001-8b3c-4f1e-9a2d-c0e5c11b0001"
#define MOTION_UUID  "6e5a0002-8b3c-4f1e-9a2d-c0e5c11b0001"   // clip -> laptop
#define BUZZ_UUID    "6e5a0003-8b3c-4f1e-9a2d-c0e5c11b0001"   // laptop -> clip

// ---------- MPU6050 ----------
uint8_t mpuAddr = 0x68;
bool mpuOk = false;

void mpuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(mpuAddr);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool mpuRead(uint8_t reg, uint8_t* buf, uint8_t len) {
  Wire.beginTransmission(mpuAddr);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)mpuAddr, (int)len) != len) return false;
  for (uint8_t i = 0; i < len; i++) buf[i] = Wire.read();
  return true;
}

bool mpuBegin() {
  for (uint8_t addr : {0x68, 0x69}) {
    mpuAddr = addr;
    uint8_t who = 0xFF;
    if (mpuRead(0x75, &who, 1) && who != 0xFF && who != 0x00) {
      Serial.printf("Motion sensor found at 0x%02X (id 0x%02X)\n", addr, who);
      mpuWrite(0x6B, 0x00);  // wake up
      delay(50);
      mpuWrite(0x1A, 0x03);  // smoothing filter ~44 Hz
      mpuWrite(0x1B, 0x08);  // gyro +/-500 deg/s  (65.5 per deg/s)
      mpuWrite(0x1C, 0x08);  // accel +/-4 g       (8192 per g)
      return true;
    }
  }
  Serial.println("!! Motion sensor NOT found. Check SDA/SCL/3V3/GND wires.");
  return false;
}

// ---------- vibration patterns ----------
// Commands from the laptop (first byte):
//   1 = short buzz (good)     2 = double buzz (warning)     3 = long buzz (stop/fix)
//   4 = rhythm: bytes 2-3 = beat period in ms (little-endian)  0 = stop rhythm
struct Step { uint16_t ms; bool on; };
Step pattern[8];
uint8_t patternLen = 0, patternIdx = 0;
uint32_t stepStart = 0;
uint16_t rhythmPeriod = 0;
uint32_t lastBeat = 0;

void motor(bool on) { digitalWrite(MOTOR_PIN, on ? HIGH : LOW); }

void playPattern(const Step* steps, uint8_t n) {
  for (uint8_t i = 0; i < n && i < 8; i++) pattern[i] = steps[i];
  patternLen = n; patternIdx = 0; stepStart = millis();
  motor(pattern[0].on);
}

void handleCommand(const uint8_t* d, size_t n) {
  if (n == 0) return;
  static const Step SHORT[] = {{120, true}, {10, false}};
  static const Step DOUBLE[] = {{110, true}, {110, false}, {110, true}, {10, false}};
  static const Step LONG[] = {{500, true}, {10, false}};
  switch (d[0]) {
    case 0: rhythmPeriod = 0; motor(false); break;
    case 1: playPattern(SHORT, 2); break;
    case 2: playPattern(DOUBLE, 4); break;
    case 3: playPattern(LONG, 2); break;
    case 4:
      if (n >= 3) { rhythmPeriod = d[1] | (d[2] << 8); lastBeat = millis(); }
      break;
  }
}

void updateMotor() {
  uint32_t now = millis();
  if (patternLen > 0) {
    if (now - stepStart >= pattern[patternIdx].ms) {
      patternIdx++;
      if (patternIdx >= patternLen) { patternLen = 0; motor(false); }
      else { stepStart = now; motor(pattern[patternIdx].on); }
    }
    return;  // a pattern overrides the rhythm while it plays
  }
  if (rhythmPeriod >= 200) {
    uint32_t since = now - lastBeat;
    if (since >= rhythmPeriod) { lastBeat = now; motor(true); }
    else if (since >= 70) motor(false);
  }
}

// ---------- Bluetooth ----------
BLECharacteristic* motionChar = nullptr;
bool connected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override { connected = true; Serial.println("Laptop connected"); }
  void onDisconnect(BLEServer* s) override {
    connected = false;
    rhythmPeriod = 0; motor(false);
    Serial.println("Laptop disconnected, advertising again");
    s->getAdvertising()->start();
  }
};

class BuzzCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    auto v = c->getValue();
    handleCommand((const uint8_t*)v.c_str(), v.length());
  }
};

// ---------- motion processing ----------
float pitch = 0, roll = 0;  // degrees, smoothed with a complementary filter
uint32_t lastSample = 0;

void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(MOTOR_PIN, OUTPUT);
  motor(false);
  Serial.println("\n=== Cue Clip ===");
  Serial.printf("SDA pin = %d, SCL pin = %d, motor pin = %d\n", SDA, SCL, MOTOR_PIN);

  Wire.begin();
  Wire.setClock(400000);
  mpuOk = mpuBegin();

  BLEDevice::init(DEVICE_NAME);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService* service = server->createService(SERVICE_UUID);
  motionChar = service->createCharacteristic(MOTION_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  motionChar->addDescriptor(new BLE2902());
  BLECharacteristic* buzz = service->createCharacteristic(
      BUZZ_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  buzz->setCallbacks(new BuzzCallbacks());
  service->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("Bluetooth ready as \"CueClip\"");

  // Hello buzz so you know the motor works.
  static const Step HELLO[] = {{150, true}, {120, false}, {150, true}, {10, false}};
  playPattern(HELLO, 4);
}

void loop() {
  updateMotor();

  uint32_t now = millis();
  if (now - lastSample < 20) return;  // 50 samples per second
  float dt = (now - lastSample) / 1000.0f;
  lastSample = now;

  int16_t ax = 0, ay = 0, az = 0, gx = 0, gy = 0, gz = 0;
  if (mpuOk) {
    uint8_t b[14];
    if (mpuRead(0x3B, b, 14)) {
      ax = (b[0] << 8) | b[1];  ay = (b[2] << 8) | b[3];  az = (b[4] << 8) | b[5];
      gx = (b[8] << 8) | b[9];  gy = (b[10] << 8) | b[11]; gz = (b[12] << 8) | b[13];
    }
  }

  // Tilt from gravity (accelerometer), smoothed with rotation speed (gyro).
  float accPitch = atan2f(-ax, sqrtf((float)ay * ay + (float)az * az)) * 57.2958f;
  float accRoll = atan2f(ay, az) * 57.2958f;
  float gyroX = gx / 65.5f, gyroY = gy / 65.5f, gyroZ = gz / 65.5f;  // deg/s
  pitch = 0.96f * (pitch + gyroY * dt) + 0.04f * accPitch;
  roll = 0.96f * (roll + gyroX * dt) + 0.04f * accRoll;
  float accMag = sqrtf((float)ax * ax + (float)ay * ay + (float)az * az) / 8.192f;  // milli-g

  if (connected && motionChar) {
    // 6 numbers x 2 bytes: pitch, roll (0.01 deg), gyro x/y/z (0.1 deg/s), accel size (milli-g)
    int16_t packet[6] = {
        (int16_t)(pitch * 100), (int16_t)(roll * 100),
        (int16_t)constrain(gyroX * 10, -32767, 32767),
        (int16_t)constrain(gyroY * 10, -32767, 32767),
        (int16_t)constrain(gyroZ * 10, -32767, 32767),
        (int16_t)constrain(accMag, 0, 32767)};
    motionChar->setValue((uint8_t*)packet, sizeof(packet));
    motionChar->notify();
  }

  static uint32_t lastPrint = 0;
  if (now - lastPrint > 500) {
    lastPrint = now;
    Serial.printf("pitch %6.1f  roll %6.1f  spin %6.1f  %s\n", pitch, roll, gyroZ,
                  connected ? "[laptop connected]" : "[waiting for laptop]");
  }
}
