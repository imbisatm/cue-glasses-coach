/*
  Cue Clip (USB version) for the MLH hardware lab parts
  -----------------------------------------------------
  Arduino (UNO R3 / UNO R4 / similar) + Grove 3-Axis Digital Accelerometer
  + servo motor (wiggles fast = you feel it through the dumbbell) + optional buzzer.
  Talks to the laptop over the USB cable (no Bluetooth needed).

  It sends 50 lines per second like:   M,<tilt>,<side tilt>,<accel in milli-g>
  It listens for:  1 = short buzz, 2 = double buzz, 3 = long buzz,
                   R<ms> = steady rhythm every <ms> milliseconds, 0 = stop

  Supported motion sensors (found automatically):
    ADXL345 (Grove 3-Axis Digital Accelerometer +-16g), MMA7660FC (Grove +-1.5g),
    LIS3DHTR (newer Grove version), H3LIS331DL (Grove +-400g), BMA400, LSM6DS3 / LSM6DSOX,
    MPU6050. If none is found it prints the I2C addresses it can see.

  Wiring: see hardware/WIRING_USB.md
*/

#include <Arduino.h>
#include <Wire.h>
#include <Servo.h>

// The servo signal is sent on EVERY digital pin 2-13 (12 = the most an UNO can drive),
// so the servo's signal wire works in any of those holes or Grove D sockets.
const uint8_t SERVO_PINS[] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
const uint8_t SERVO_COUNT = sizeof(SERVO_PINS);
#define BUZZER_PIN 8
#define USE_BUZZER 0   // buzzer off by default (pin 8 is used for the servo signal)

// Types live up here: the Arduino IDE adds function prototypes above the first function,
// so every type a function uses must already be defined there.
struct Step { uint16_t ms; bool on; };

// ---------------- motion sensor ----------------
enum SensorType { NONE, ADXL345, LIS3DH, LIS331, LSM6DS, MPU6050, BMA400, MMA7660 };
SensorType sensor = NONE;
uint8_t addr = 0;
TwoWire* bus = &Wire;

bool readRegs(uint8_t reg, uint8_t* buf, uint8_t len) {
  bus->beginTransmission(addr);
  bus->write(reg);
  if (bus->endTransmission() != 0) return false;
  if (bus->requestFrom((int)addr, (int)len) != len) return false;
  for (uint8_t i = 0; i < len; i++) buf[i] = bus->read();
  return true;
}

void writeReg(uint8_t reg, uint8_t val) {
  bus->beginTransmission(addr);
  bus->write(reg);
  bus->write(val);
  bus->endTransmission();
}

// true if a chip answers at address a
bool ack(uint8_t a) {
  bus->beginTransmission(a);
  return bus->endTransmission() == 0;
}

// reads one "who am I" register at address a and returns it (0xFF = nothing there)
uint8_t whoAmI(uint8_t a, uint8_t reg) {
  addr = a;
  uint8_t v = 0xFF;
  if (!readRegs(reg, &v, 1)) return 0xFF;
  return v;
}

bool findSensorOn(TwoWire* w) {
  bus = w;
  bus->begin();
#if defined(WIRE_HAS_TIMEOUT)
  bus->setWireTimeout(3000, true);  // never freeze if a wire is loose
#endif
  const uint8_t two[2][2] = {{0x53, 0x1D}, {0x19, 0x18}};
  // Grove 3-Axis Digital Accelerometer +-16g (ADXL345)
  for (uint8_t i = 0; i < 2; i++) if (whoAmI(two[0][i], 0x00) == 0xE5) {
    sensor = ADXL345;
    writeReg(0x2C, 0x0A);  // 100 Hz
    writeReg(0x31, 0x0B);  // full resolution, +-16 g (3.9 mg per step)
    writeReg(0x2D, 0x08);  // start measuring
    return true;
  }
  // Grove LIS3DHTR (0x33) or Grove +-400g H3LIS331DL (0x32)
  for (uint8_t i = 0; i < 2; i++) {
    uint8_t id = whoAmI(two[1][i], 0x0F);
    if (id == 0x33) {
      sensor = LIS3DH;
      writeReg(0x20, 0x57);  // 100 Hz, x/y/z on
      writeReg(0x23, 0x98);  // +-4 g, high resolution (2 mg per step)
      return true;
    }
    if (id == 0x32) {
      sensor = LIS331;
      writeReg(0x20, 0x27);  // normal mode, 50 Hz, x/y/z on
      writeReg(0x23, 0x80);  // +-100 g
      return true;
    }
  }
  // Grove 6-Axis (LSM6DS3 = 0x69/0x6A) or Modulino Movement (LSM6DSOX = 0x6C)
  for (uint8_t a = 0x6A; a <= 0x6B; a++) {
    uint8_t id = whoAmI(a, 0x0F);
    if (id == 0x69 || id == 0x6A || id == 0x6C) {
      sensor = LSM6DS;
      writeReg(0x10, 0x48);  // accel 104 Hz, +-4 g (0.122 mg per step)
      return true;
    }
  }
  // Grove BMA400
  for (uint8_t a = 0x14; a <= 0x15; a++) if (whoAmI(a, 0x00) == 0x90) {
    sensor = BMA400;
    writeReg(0x19, 0x02);  // normal mode
    delay(5);
    writeReg(0x1A, 0x48);  // +-4 g, 100 Hz (512 per g)
    return true;
  }
  // MPU6050 / MPU9250 family
  for (uint8_t a = 0x68; a <= 0x69; a++) {
    uint8_t id = whoAmI(a, 0x75);
    if (id != 0xFF && id != 0x00) {
      sensor = MPU6050;
      writeReg(0x6B, 0x00);  // wake up
      delay(50);
      writeReg(0x1A, 0x03);  // smoothing
      writeReg(0x1C, 0x08);  // +-4 g (8192 per g)
      return true;
    }
  }
  // Grove 3-Axis Digital Accelerometer +-1.5g (MMA7660FC): no ID register, it just answers at 0x4C
  if (ack(0x4C)) {
    sensor = MMA7660;
    addr = 0x4C;
    writeReg(0x07, 0x00);  // standby (needed to change settings)
    writeReg(0x08, 0x00);  // 120 samples per second
    writeReg(0x07, 0x01);  // active
    return true;
  }
  return false;
}

const char* sensorName() {
  switch (sensor) {
    case ADXL345: return "ADXL345";
    case LIS3DH: return "LIS3DH";
    case LIS331: return "H3LIS331DL";
    case LSM6DS: return "LSM6DS";
    case MPU6050: return "MPU6050";
    case BMA400: return "BMA400";
    case MMA7660: return "MMA7660";
    default: return "none";
  }
}

// When no known sensor is found: list every address that answers, so we know what's plugged in.
void reportBus() {
  Serial.print("ERR,no known motion sensor. I2C devices found:");
  uint8_t n = 0;
  for (uint8_t a = 1; a < 127; a++) {
    if (ack(a)) {
      Serial.print(" 0x");
      if (a < 16) Serial.print('0');
      Serial.print(a, HEX);
      n++;
    }
  }
  if (n == 0) Serial.print(" none - push the Grove cable in at both ends (I2C socket)");
  Serial.println();
}

// Reads acceleration in milli-g. Returns false if the read failed.
bool readAccel(float& x, float& y, float& z) {
  uint8_t b[6];
  int16_t rx, ry, rz;
  switch (sensor) {
    case ADXL345:
      if (!readRegs(0x32, b, 6)) return false;
      rx = (int16_t)(b[1] << 8 | b[0]); ry = (int16_t)(b[3] << 8 | b[2]); rz = (int16_t)(b[5] << 8 | b[4]);
      x = rx * 3.9f; y = ry * 3.9f; z = rz * 3.9f;
      return true;
    case LIS3DH:
    case LIS331:
      if (!readRegs(0x28 | 0x80, b, 6)) return false;
      rx = (int16_t)(b[1] << 8 | b[0]) >> 4; ry = (int16_t)(b[3] << 8 | b[2]) >> 4; rz = (int16_t)(b[5] << 8 | b[4]) >> 4;
      {
        float k = (sensor == LIS3DH) ? 2.0f : 49.0f;
        x = rx * k; y = ry * k; z = rz * k;
      }
      return true;
    case LSM6DS:
      if (!readRegs(0x28, b, 6)) return false;
      rx = (int16_t)(b[1] << 8 | b[0]); ry = (int16_t)(b[3] << 8 | b[2]); rz = (int16_t)(b[5] << 8 | b[4]);
      x = rx * 0.122f; y = ry * 0.122f; z = rz * 0.122f;
      return true;
    case MPU6050:
      if (!readRegs(0x3B, b, 6)) return false;
      rx = (int16_t)(b[0] << 8 | b[1]); ry = (int16_t)(b[2] << 8 | b[3]); rz = (int16_t)(b[4] << 8 | b[5]);
      x = rx / 8.192f; y = ry / 8.192f; z = rz / 8.192f;
      return true;
    case BMA400: {
      if (!readRegs(0x04, b, 6)) return false;
      int16_t v[3];
      for (uint8_t i = 0; i < 3; i++) {
        v[i] = (int16_t)(((uint16_t)b[2 * i + 1] << 8 | b[2 * i]) & 0x0FFF);
        if (v[i] > 2047) v[i] -= 4096;
      }
      x = v[0] * 1.953f; y = v[1] * 1.953f; z = v[2] * 1.953f;
      return true;
    }
    case MMA7660: {
      if (!readRegs(0x00, b, 3)) return false;
      int8_t v[3];
      for (uint8_t i = 0; i < 3; i++) {
        if (b[i] & 0x40) return false;  // the chip was mid-update; skip this sample
        v[i] = b[i] & 0x3F;
        if (v[i] & 0x20) v[i] -= 64;   // 6-bit signed
      }
      x = v[0] * 46.9f; y = v[1] * 46.9f; z = v[2] * 46.9f;  // 21.3 steps per g
      return true;
    }
    default:
      return false;
  }
}

// ---------------- feedback (servo wiggle + buzzer) ----------------
Servo servos[SERVO_COUNT];
void servoWrite(int angle) {
  for (uint8_t i = 0; i < SERVO_COUNT; i++) servos[i].write(angle);
}
Step pattern[8];
uint8_t patternLen = 0, patternIdx = 0;
uint32_t stepStart = 0, lastWiggle = 0;
bool buzzing = false, wiggleSide = false;
uint16_t rhythmPeriod = 0;
uint32_t lastBeat = 0;

void setBuzz(bool on) {
  if (on == buzzing) return;
  buzzing = on;
#if USE_BUZZER
  if (on) tone(BUZZER_PIN, 2200); else noTone(BUZZER_PIN);
#endif
  if (!on) servoWrite(90);
}

void playPattern(const Step* steps, uint8_t n) {
  for (uint8_t i = 0; i < n && i < 8; i++) pattern[i] = steps[i];
  patternLen = n; patternIdx = 0; stepStart = millis();
  setBuzz(pattern[0].on);
}

void handleCommand(const String& cmd) {
  static const Step SHORT[] = {{150, true}, {10, false}};
  static const Step DOUBLE[] = {{130, true}, {120, false}, {130, true}, {10, false}};
  static const Step LONG[] = {{550, true}, {10, false}};
  if (cmd.length() == 0) return;
  char c = cmd.charAt(0);
  if (c == '0') { rhythmPeriod = 0; patternLen = 0; setBuzz(false); }
  else if (c == '1') playPattern(SHORT, 2);
  else if (c == '2') playPattern(DOUBLE, 4);
  else if (c == '3') playPattern(LONG, 2);
  else if (c == 'R') { rhythmPeriod = cmd.substring(1).toInt(); lastBeat = millis(); }
}

void updateFeedback() {
  uint32_t now = millis();
  if (patternLen > 0) {
    if (now - stepStart >= pattern[patternIdx].ms) {
      patternIdx++;
      if (patternIdx >= patternLen) { patternLen = 0; setBuzz(false); }
      else { stepStart = now; setBuzz(pattern[patternIdx].on); }
    }
  } else if (rhythmPeriod >= 200) {
    uint32_t since = now - lastBeat;
    if (since >= rhythmPeriod) { lastBeat = now; setBuzz(true); }
    else if (since >= 90) setBuzz(false);
  }
  // While buzzing, flick the servo back and forth quickly: that's the vibration.
  if (buzzing && now - lastWiggle >= 30) {
    lastWiggle = now;
    wiggleSide = !wiggleSide;
    servoWrite(wiggleSide ? 72 : 108);
  }
}

// ---------------- main ----------------
float pitch = 0, roll = 0, amag = 1000;
float sx = 0, sy = 0, sz = 1000;
bool haveSmooth = false;
uint32_t lastSample = 0, lastNotice = 0;
String inbox;

void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < SERVO_COUNT; i++) servos[i].attach(SERVO_PINS[i]);
  servoWrite(90);
#if USE_BUZZER
  pinMode(BUZZER_PIN, OUTPUT);
#endif
  bool found = findSensorOn(&Wire);
#if defined(ARDUINO_UNOR4_WIFI)
  if (!found) found = findSensorOn(&Wire1);  // the Qwiic plug on UNO R4 WiFi
#endif
  Serial.print("CUE,");
  Serial.println(sensorName());
  if (!found) reportBus();
  static const Step HELLO[] = {{150, true}, {120, false}, {150, true}, {10, false}};
  playPattern(HELLO, 4);
}

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n' || ch == '\r') { inbox.trim(); handleCommand(inbox); inbox = ""; }
    else if (inbox.length() < 16) inbox += ch;
  }
  updateFeedback();

  uint32_t now = millis();
  if (sensor == NONE) {
    // keep looking every 2 seconds, so re-plugging the sensor works without re-uploading
    if (now - lastNotice > 2000) {
      lastNotice = now;
      bool found = findSensorOn(&Wire);
#if defined(ARDUINO_UNOR4_WIFI)
      if (!found) found = findSensorOn(&Wire1);
#endif
      if (found) { Serial.print("CUE,"); Serial.println(sensorName()); }
      else reportBus();
    }
    return;
  }
  if (now - lastSample < 20) return;  // 50 per second
  lastSample = now;

  float x, y, z;
  if (!readAccel(x, y, z)) return;
  // Light smoothing on the raw x/y/z (smoothing the angles would glitch when roll flips from +180 to -180).
  if (!haveSmooth) { sx = x; sy = y; sz = z; haveSmooth = true; }
  sx = 0.7f * sx + 0.3f * x;
  sy = 0.7f * sy + 0.3f * y;
  sz = 0.7f * sz + 0.3f * z;
  pitch = atan2(-sx, sqrt(sy * sy + sz * sz)) * 57.2958f;
  roll = atan2(sy, sz) * 57.2958f;
  amag = sqrt(x * x + y * y + z * z);

  Serial.print("M,");
  Serial.print(pitch, 1); Serial.print(',');
  Serial.print(roll, 1); Serial.print(',');
  Serial.println(amag, 0);
}
