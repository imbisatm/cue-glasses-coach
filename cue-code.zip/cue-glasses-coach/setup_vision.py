"""Connect Cue to its vision model (reads the dumbbell weight, checks recipe steps and spoons).

Double-click run_setup_vision.bat and pick:
  1  AMD   - paste the endpoint URL from the AMD notebook (and its key, if it gave one)
  2  Hugging Face - paste your Hugging Face token (starts with hf_)
  3  Google Gemini (free backup) - paste a key from aistudio.google.com/apikey
  4  AMD through the notebook - paste the notebook's web address and its key (token)
It tests the connection, saves it in config.json, then runs the full 4-part vision test.
"""

from __future__ import annotations

import os

import numpy as np

from cue_core.config import load_config, save_config
from cue_core.vision import VisionClient

HF_URL = "https://router.huggingface.co/v1"
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
GEMINI_MODELS = [  # free key from aistudio.google.com; tried in this order
    "gemini-2.5-flash-lite",
    "gemini-flash-lite-latest",
    "gemini-2.5-flash",
    "gemini-flash-latest",
    "gemini-2.0-flash",
    "gemma-3-27b-it",
]
HF_MODELS = [  # tried in this order; the first one that answers is used
    "Qwen/Qwen2.5-VL-7B-Instruct",
    "Qwen/Qwen3-VL-8B-Instruct",
    "Qwen/Qwen2.5-VL-32B-Instruct",
    "Qwen/Qwen2.5-VL-72B-Instruct",
]


def red_square() -> np.ndarray:
    img = np.full((240, 320, 3), 255, np.uint8)
    img[60:180, 100:220] = (0, 0, 255)  # BGR red
    return img


def hide_screen() -> None:
    """Wipe the window so the pasted key/token isn't in any screenshot."""
    os.system("cls" if os.name == "nt" else "clear")
    print("Key received (hidden from this window).\n")


def works(url: str, key: str, model: str, bill_to: str = "", client=None) -> tuple[bool, str]:
    client = client or VisionClient(url, key, model, timeout=60, bill_to=bill_to)
    try:
        answer = client.ask(red_square(), "What colour is the square? Answer with one word.", max_tokens=20)
    except Exception as exc:
        return False, str(exc)[:200]
    return ("red" in answer.lower()), answer


def main() -> None:
    cfg = load_config()
    print(__doc__)
    choice = input("Type 1 (AMD address), 2 (Hugging Face), 3 (Gemini) or 4 (AMD through the notebook) and press ENTER: ").strip()
    bill_to = ""
    if choice == "1":
        url = input("Paste the AMD endpoint URL and press ENTER:\n> ").strip()
        key = input("Paste its key (or just press ENTER to use the default):\n> ").strip() or cfg.get("vision_key", "")
        hide_screen()
        client = VisionClient(url, key, cfg.get("vision_model", "cue-vision"))
        try:
            models = client.list_models()
            model = "cue-vision" if "cue-vision" in models else (models[0] if models else "cue-vision")
        except Exception as exc:
            print(f"\nCould not reach it: {exc}\nSend Claude a screenshot of this window.")
            input("Press ENTER to close.")
            return
        ok, answer = works(url, key, model)
        tried = [(model, ok, answer)]
    elif choice == "4":
        try:
            import websocket  # noqa: F401
        except ImportError:
            import subprocess
            import sys

            print("Installing one small add-on (websocket-client)...")
            subprocess.run([sys.executable, "-m", "pip", "install", "-q", "websocket-client"])
        from cue_core.amd_relay import NotebookRelayClient

        address = input("Paste the notebook's web address (copy it from the browser bar while the notebook is open):\n> ").strip()
        token = input("Paste the notebook key (the long code the notebook cell printed):\n> ").strip()
        cookie = input("Paste the browser cookie line (see Claude's steps), or just press ENTER to skip:\n> ").strip()
        hide_screen()
        key = "cue-k7m2q9x4w1"  # the --api-key the AMD notebook started the model with
        relay = NotebookRelayClient(address, token, key, "cue-vision", cookie=cookie)
        print(f"Notebook: {relay.base_url}")
        try:
            relay.check_access()
            print("Notebook reached. Starting a session on the AMD machine...")
            models = relay.list_models()
            print(f"Models on the AMD GPU: {models}")
        except Exception as exc:
            print(f"\nCould not use the notebook: {str(exc)[:300]}")
            print("403 nginx = the AMD site wants your browser login (cookie). Send Claude a screenshot.")
            input("Press ENTER to close.")
            return
        model = "cue-vision" if "cue-vision" in models else (models[0] if models else "cue-vision")
        relay.model = model
        url = relay.base_url
        ok, answer = works(url, key, model, client=relay)
        tried = [(model + " on AMD", ok, answer)]
        if ok:
            cfg.update(vision_mode="amd_notebook", amd_notebook=relay.base_url, amd_token=token, amd_cookie=relay.cookie)
    elif choice == "3":
        key = input("Paste your Gemini API key and press ENTER:\n> ").strip()
        hide_screen()
        url, tried, model, ok = GEMINI_URL, [], "", False
        for candidate in GEMINI_MODELS:
            print(f"Trying {candidate} ...")
            ok, answer = works(url, key, candidate)
            tried.append((candidate, ok, answer))
            if ok:
                model = candidate
                break
    else:
        key = input("Paste your Hugging Face token (starts with hf_) and press ENTER:\n> ").strip()
        hide_screen()
        bill_to = input("Hackathon credits through a Hugging Face organization? Type the organization's name,\n"
                        "or just press ENTER to use your own account:\n> ").strip()
        url, tried, model, ok = HF_URL, [], "", False
        for candidate in HF_MODELS:
            print(f"Trying {candidate} ...")
            ok, answer = works(url, key, candidate, bill_to)
            tried.append((candidate, ok, answer))
            if ok:
                model = candidate
                break
    for name, good, answer in tried:
        print(f"  {'OK  ' if good else 'FAIL'}  {name}: {answer}")
    if not ok:
        print("\nNo model answered correctly. Send Claude a screenshot of this window.")
        input("Press ENTER to close.")
        return
    if choice != "4":
        cfg["vision_mode"] = "direct"
    cfg.update(vision_url=url, vision_key=key, vision_model=model, vision_bill_to=bill_to,
               habit_every=5.0 if choice == "3" else 3.0)  # Gemini's free plan allows fewer requests a minute
    save_config(cfg)
    print(f"\nSaved: {url}  (model {model})\nNow running the full vision test...\n")
    import vision_test

    vision_test.main()
    input("\nPress ENTER to close.")


if __name__ == "__main__":
    main()
