"""Cue Clip over a USB cable (Arduino version). Same interface as the Bluetooth ClipClient.

- Finds the Arduino by itself (looks for the "CUE," / "M," lines it prints).
- Reads tilt samples, sends buzz commands, reconnects if the cable is pulled.
- Set "clip_port": "COM5" in config.json to skip the search.
"""

from __future__ import annotations

import threading
import time
from collections import deque

from cue_core.clip import GOOD, ClipSample


last_search_problem = ""  # why the last search failed, in plain words


def find_port(preferred: str = "") -> str | None:
    global last_search_problem
    import serial
    from serial.tools import list_ports

    # skip Bluetooth serial ports: opening them can hang for a long time
    ports = [p.device for p in list_ports.comports() if "bluetooth" not in (p.description or "").lower()]
    if preferred:  # try the saved port first, then every other port (the COM number changes with the USB socket)
        ports = [preferred] + [d for d in ports if d.upper() != preferred.upper()]
    if not ports:
        last_search_problem = "no USB devices found: is the Arduino plugged in? (try another cable)"
        return None
    problems = []
    for dev in ports:
        try:
            with serial.Serial(dev, 115200, timeout=0.3) as s:
                deadline = time.monotonic() + 3.5  # an UNO R3 restarts when the port opens
                while time.monotonic() < deadline:
                    line = s.readline().decode(errors="ignore").strip()
                    if line.startswith(("CUE,", "M,", "ERR,")):
                        last_search_problem = ""
                        return dev
                problems.append(f"{dev} is not sending Cue data (upload cue_clip_usb.ino again)")
        except Exception as exc:
            text = str(exc).lower()
            if "access" in text or "denied" in text or "busy" in text or "permission" in text:
                problems.append(f"{dev} is busy: close Arduino IDE / Serial Monitor")
            else:
                problems.append(f"{dev}: {exc}")
    last_search_problem = "; ".join(problems)
    return None


class SerialClipClient:
    def __init__(self, port: str = ""):
        self.port_hint = port
        self.status = "searching for the Arduino clip..."
        self.connected = False
        self.sensor = ""
        self.samples: deque[ClipSample] = deque(maxlen=1000)
        self._total = 0
        self._read_index = 0
        self._lock = threading.Lock()
        self._ser = None
        self._stop = False
        threading.Thread(target=self._run, daemon=True).start()

    # ---- same API as ClipClient ----
    def new_samples(self) -> list[ClipSample]:
        with self._lock:
            fresh = self._total - self._read_index
            self._read_index = self._total
            if fresh <= 0:
                return []
            return list(self.samples)[-min(fresh, len(self.samples)):]

    def latest(self) -> ClipSample | None:
        return self.samples[-1] if self.samples else None

    def buzz(self, pattern: int = GOOD) -> None:
        self._send(f"{pattern}\n")

    def rhythm(self, period_ms: int) -> None:
        self._send(f"R{int(period_ms)}\n" if period_ms > 0 else "0\n")

    def close(self) -> None:
        self._stop = True
        self.rhythm(0)
        time.sleep(0.1)
        try:
            if self._ser:
                self._ser.close()
        except Exception:
            pass

    # ---- background ----
    def _send(self, text: str) -> None:
        ser = self._ser
        if not (self.connected and ser):
            return
        try:
            ser.write(text.encode())
        except Exception as exc:
            print(f"[clip] send failed: {exc}")

    def _handle(self, line: str) -> None:
        if line.startswith("M,"):
            parts = line.split(",")
            if len(parts) >= 4:
                try:
                    p, r, a = float(parts[1]), float(parts[2]), float(parts[3])
                except ValueError:
                    return
                with self._lock:
                    self.samples.append(ClipSample(time.monotonic(), p, r, 0.0, 0.0, 0.0, a))
                    self._total += 1
        elif line.startswith("CUE,"):
            self.sensor = line[4:]
            self.status = f"connected ({self.sensor})" if self.sensor != "none" else "connected, but NO motion sensor found"
        elif line.startswith("ERR,"):
            self.status = line[4:]

    def _run(self) -> None:
        try:
            import serial
        except ImportError:
            self.status = "pyserial not installed: run install.bat again"
            return
        while not self._stop:
            port = find_port(self.port_hint)
            if not port:
                self.status = "Arduino clip not found: " + (last_search_problem or "plugged in? Arduino IDE closed?")
                time.sleep(2)
                continue
            try:
                self._ser = serial.Serial(port, 115200, timeout=0.5)
                time.sleep(2.0)  # let the board restart
                self.connected = True
                self.status = f"connected on {port}"
                buf = b""
                while not self._stop:
                    chunk = self._ser.read(self._ser.in_waiting or 1)
                    if not chunk:
                        continue
                    buf += chunk
                    while b"\n" in buf:
                        raw, buf = buf.split(b"\n", 1)
                        self._handle(raw.decode(errors="ignore").strip())
            except Exception as exc:
                self.status = f"clip disconnected: {exc}"
            finally:
                self.connected = False
                try:
                    if self._ser:
                        self._ser.close()
                except Exception:
                    pass
                self._ser = None
                time.sleep(1)


def make_clip(cfg: dict):
    """Picks the USB (Arduino) clip or the Bluetooth (ESP32) clip from config.json."""
    if cfg.get("clip_type", "usb") == "ble":
        from cue_core.clip import ClipClient

        return ClipClient()
    return SerialClipClient(cfg.get("clip_port", ""))
