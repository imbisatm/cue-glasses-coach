"""CPR practice: counts chest compressions from the Cue Clip and coaches the pace.

The clip sits on the back of the wrist. Every push down and back up on a pillow makes the
total acceleration swing above and below 1 g, so one full swing = one compression.

- Speed (compressions per minute) comes from the time between compressions. Measured.
- Depth is an ESTIMATE: for a back-and-forth motion at frequency f, distance = acceleration / (2*pi*f)^2.
  Good enough to tell a light tap from a real push, not a medical measurement.
- While the clip is buzzing, its own motor shakes the sensor, so those moments are skipped
  and any pushes hidden in that gap are filled in from the current pace.

Hands-only CPR guidance (adults): push hard and fast in the center of the chest,
100 to 120 pushes a minute, at least 2 inches deep, letting the chest come all the way back up.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from statistics import median
from typing import Optional

CM_PER_IN = 2.54


@dataclass
class Compression:
    t: float
    interval: Optional[float]   # seconds since the previous one (None after a pause)
    depth_cm: Optional[float]   # estimate
    after_blind: bool = False   # the gap before it included a buzz (sensor ignored)


class CompressionDetector:
    """Turns acceleration-size samples (milli-g, about 1000 at rest) into compressions."""

    def __init__(self, min_swing_mg: float = 70.0, refractory: float = 0.25):
        self.min_swing = min_swing_mg
        self.refractory = refractory
        self.reset()

    def reset(self) -> None:
        self.base: Optional[float] = None
        self.fast = 0.0
        self.prev_t: Optional[float] = None
        self.state = "idle"
        self.amp = 200.0          # recent half swing size (mg)
        self.cycle_lo = math.inf
        self.cycle_hi = -math.inf
        self.last_t: Optional[float] = None
        self.blind_until = -1.0
        self._blind_seen = False
        self.signal: deque = deque(maxlen=200)

    def ignore_until(self, t: float) -> None:
        """Skip samples until time t (the clip is buzzing and shaking its own sensor)."""
        self.blind_until = max(self.blind_until, t)

    @property
    def threshold(self) -> float:
        return max(self.min_swing, 0.35 * self.amp)

    def update(self, t: float, amag_mg: float) -> Optional[Compression]:
        if self.base is None:
            self.base, self.fast, self.prev_t = amag_mg, amag_mg, t
        dt = min(0.1, max(0.0, t - self.prev_t))
        self.prev_t = t
        self.base += (amag_mg - self.base) * min(1.0, dt / 1.2)   # slow: gravity + drift
        self.fast = 0.5 * self.fast + 0.5 * amag_mg               # light noise filter
        x = self.fast - self.base
        if t < self.blind_until:
            self.signal.append(0.0)
            self._blind_seen = True
            self.state = "idle"
            self.cycle_lo, self.cycle_hi = math.inf, -math.inf
            return None
        self.signal.append(x)
        # let the expected swing size shrink again after a pause, so lighter pushes still count
        if self.last_t is None or t - self.last_t > 1.2:
            self.amp = max(150.0, self.amp * 0.98)
        self.cycle_lo, self.cycle_hi = min(self.cycle_lo, x), max(self.cycle_hi, x)
        h = self.threshold
        if self.state == "idle":
            self.state = "low" if x < -h else ("high" if x > h else "idle")
            return None
        if self.state == "high":
            if x < -h:
                self.state = "low"
            return None
        # state == "low": waiting for the upswing that completes a compression
        if x <= h:
            return None
        self.state = "high"
        if self.last_t is not None and t - self.last_t < self.refractory:
            return None
        swing = self.cycle_hi - self.cycle_lo
        self.amp = min(1500.0, max(80.0, 0.7 * self.amp + 0.3 * swing / 2))
        interval = None if self.last_t is None or t - self.last_t > 2.0 else t - self.last_t
        depth = None
        if interval:
            f = 1.0 / interval
            accel = (swing / 2) / 1000.0 * 9.81 / 0.95            # m/s^2, undo the light filter
            depth = min(12.0, 2 * accel / (2 * math.pi * f) ** 2 * 100)
        comp = Compression(t, interval, depth, self._blind_seen)
        self._blind_seen = False
        self.last_t = t
        self.cycle_lo, self.cycle_hi = x, x
        return comp


@dataclass
class Cue:
    text: str
    buzz: int = 0        # 0 none, 1 good, 2 warning, 3 long
    force: bool = False


@dataclass
class CprDrill:
    """A timed practice round. Starts on the first push."""

    seconds: float = 30.0
    low: float = 100.0
    high: float = 120.0
    min_depth_cm: float = 3.0       # "push harder" below this ESTIMATE (real target is 5 cm / 2 in)
    depth_coaching: bool = True
    detector: CompressionDetector = field(default_factory=CompressionDetector)

    def __post_init__(self):
        self.reset()

    def reset(self) -> None:
        self.detector.reset()
        self.state = "ready"          # ready -> running -> done
        self.start_t: Optional[float] = None
        self.count = 0
        self.intervals: deque = deque(maxlen=6)
        self.depths: deque = deque(maxlen=6)
        self.all_depths: list = []
        self.rates: list = []         # rate at each compression (once known)
        self.marks: list = []         # per compression: "good" / "slow" / "fast" / "" (not known yet)
        self.pace = ""                # current: good / slow / fast / ""
        self._off_streak = 0
        self._last_cue_t = -99.0
        self._last_pace_cue = ""
        self._said_10s = False
        self._pause_warned = False
        self.longest_pause = 0.0
        self.last_t: Optional[float] = None
        self.now = 0.0
        self.summary: Optional[dict] = None

    # ---- read-outs for the screen ----
    @property
    def rate(self) -> Optional[float]:
        if len(self.intervals) < 2:
            return None
        return 60.0 / median(list(self.intervals)[-4:])

    @property
    def depth_cm(self) -> Optional[float]:
        return median(self.depths) if self.depths else None

    @property
    def elapsed(self) -> float:
        return 0.0 if self.start_t is None else max(0.0, self.now - self.start_t)

    @property
    def remaining(self) -> float:
        return max(0.0, self.seconds - self.elapsed) if self.state != "ready" else self.seconds

    def blind(self, until: float) -> None:
        self.detector.ignore_until(until)

    # ---- main update: one clip sample ----
    def update(self, t: float, amag_mg: float) -> list[Cue]:
        self.now = t
        cues: list[Cue] = []
        if self.state == "done":
            return cues
        comp = self.detector.update(t, amag_mg)
        if comp:
            cues += self._on_compression(comp)
        if self.state == "running":
            gap = t - (self.last_t or t)
            if gap > 2.0 and not self._pause_warned:
                self._pause_warned = True
                self.pace = ""
                self.intervals.clear()
                cues.append(self._cue("Keep pushing", 2))
            if self.elapsed >= self.seconds - 10 and not self._said_10s:
                self._said_10s = True
                cues.append(Cue("Ten seconds left", force=True))
            if self.elapsed >= self.seconds:
                cues += self._finish()
        return cues

    def _on_compression(self, c: Compression) -> list[Cue]:
        cues: list[Cue] = []
        if self.state == "ready":
            self.state, self.start_t = "running", c.t
            cues.append(Cue("Go. Push hard and fast.", force=True))
        if self.last_t is not None:
            self.longest_pause = max(self.longest_pause, c.t - self.last_t) if c.t - self.last_t > 1.0 else self.longest_pause
        self._pause_warned = False
        self.last_t = c.t
        self.count += 1
        if c.interval:
            typical = median(self.intervals) if self.intervals else None
            if c.after_blind and typical and c.interval > 1.5 * typical:
                missed = max(0, round(c.interval / typical) - 1)   # pushes hidden by the buzz
                self.count += missed
                self.marks += [self.marks[-1] if self.marks else ""] * missed
            else:
                self.intervals.append(c.interval)
        if c.depth_cm is not None and not c.after_blind:
            self.depths.append(c.depth_cm)
            self.all_depths.append(c.depth_cm)
        rate = self.rate
        if rate is None:
            self.marks.append("")
            return cues
        self.rates.append(rate)
        pace = "slow" if rate < self.low else ("fast" if rate > self.high else "good")
        self.marks.append(pace)
        self.pace = pace
        self._off_streak = self._off_streak + 1 if pace != "good" else 0
        since = c.t - self._last_cue_t
        if pace != "good" and self._off_streak >= 3 and since > 3.5:
            cues.append(self._cue("Faster" if pace == "slow" else "Slower", 2))
            self._last_pace_cue = pace
        elif pace == "good" and self._last_pace_cue in ("slow", "fast") and since > 1.5:
            cues.append(self._cue("Good. Keep that pace.", 0))
            self._last_pace_cue = "good"
        elif pace == "good" and since > 9.0:
            cues.append(self._cue("Good pace", 0))
            self._last_pace_cue = "good"
        elif (self.depth_coaching and len(self.depths) >= 5 and self.depth_cm is not None
              and self.depth_cm < self.min_depth_cm and since > 6.0):
            cues.append(self._cue("Push harder", 2))
        return cues

    def _cue(self, text: str, buzz: int) -> Cue:
        self._last_cue_t = self.now
        return Cue(text, buzz)

    def _finish(self) -> list[Cue]:
        self.state = "done"
        known = [m for m in self.marks if m]
        good = sum(m == "good" for m in known)
        pct = int(round(100 * good / len(known))) if known else 0
        avg_rate = median(self.rates) if self.rates else 0.0
        depth = median(self.all_depths) if self.all_depths else None
        slow = sum(m == "slow" for m in known)
        fast = sum(m == "fast" for m in known)
        if pct >= 80:
            verdict = "Great rhythm. That pace keeps blood moving."
        elif slow >= fast:
            verdict = "A little slow. Think of the beat of Stayin' Alive."
        else:
            verdict = "A little fast. Let the chest come all the way back up."
        self.summary = {
            "count": self.count, "avg_rate": avg_rate, "pct": pct, "depth_cm": depth,
            "longest_pause": self.longest_pause, "marks": list(self.marks), "verdict": verdict,
            "seconds": self.seconds,
        }
        line = f"Time. {self.count} compressions. {pct} percent at the right speed."
        return [Cue(line, 3, force=True)]
