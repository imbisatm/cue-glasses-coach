"""Settings saved in config.json next to bridge.py (edit it in Notepad if needed)."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.json"

DEFAULT_CONFIG = {
    "region": None,
    "monitor": 1,
    "fps": 15,
    "process_width": 640,
    "rep_threshold": 6.0,
    "tempo_down": 1.2,
    "tempo_up": 0.9,
    "claw_flat_ratio": 1.25,
    "voice_rate": 185,
    "audio_device": "default",
    "use_clip": False,
    "clip_type": "usb",  # "usb" = Arduino on a cable (MLH lab parts), "ble" = ESP32 Bluetooth
    "clip_port": "",  # e.g. "COM5"; leave empty to find it automatically
    "clip_rep_threshold": 20.0,
    "rhythm_period_ms": 3500,
    # Vision model. AMD Radeon Cloud: the endpoint URL it gives you + your --api-key.
    # Backup (Hugging Face): url "https://router.huggingface.co/v1", your HF token as key,
    # model "Qwen/Qwen2.5-VL-7B-Instruct".
    "vision_url": "",
    "vision_key": "cue-k7m2q9x4w1",
    "vision_model": "cue-vision",
}


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text()))
        except Exception as exc:
            print(f"config.json could not be read ({exc}); using defaults")
    return cfg


def save_config(cfg: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2))
