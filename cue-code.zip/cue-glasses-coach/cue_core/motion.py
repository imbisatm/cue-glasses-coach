"""Motion engine: turns camera movement into reps, tempo and depth.

How it works (in plain words):
1. VerticalMotionTracker compares each video frame with the one before and
   measures how far the whole picture shifted up or down (phase correlation).
   Adding those shifts up gives a "height" signal: when you squat, your view
   moves down and comes back up.
2. RepCounter watches that height signal. A rep starts when the signal moves
   far enough from where you were standing still, and ends when it comes most
   of the way back. It records how long the "down" and "up" halves took.
3. dtw_distance and target_curve let us compare a rep's shape with an ideal
   rep (used later for the Cue Clip's motion sensor too).
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Optional

import numpy as np

try:  # OpenCV is only needed for the camera tracker, not for the math below.
    import cv2
except ImportError:  # pragma: no cover
    cv2 = None


# ---------------------------------------------------------------------------
# 1. Camera motion -> height signal
# ---------------------------------------------------------------------------
class VerticalMotionTracker:
    """Estimates how far the camera view moved up/down between frames."""

    def __init__(self, width: int = 160, min_response: float = 0.05):
        if cv2 is None:
            raise RuntimeError("OpenCV is required for VerticalMotionTracker")
        self.width = width
        self.min_response = min_response  # below this the match is unreliable
        self._prev = None
        self._window = None
        self.position = 0.0  # running total of vertical shift (pixels)
        self.last_confidence = 0.0

    def reset(self) -> None:
        self._prev = None
        self.position = 0.0

    def update(self, frame_bgr: np.ndarray) -> float:
        """Feed one frame, get back the updated height signal."""
        h, w = frame_bgr.shape[:2]
        height = max(16, int(round(h * self.width / w)))
        gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        small = cv2.resize(gray, (self.width, height), interpolation=cv2.INTER_AREA)
        small = np.float32(small)

        if self._prev is None or self._prev.shape != small.shape:
            self._prev = small
            self._window = cv2.createHanningWindow((self.width, height), cv2.CV_32F)
            return self.position

        (dx, dy), response = cv2.phaseCorrelate(self._prev, small, self._window)
        self._prev = small
        self.last_confidence = float(response)
        # Ignore unreliable matches and absurd jumps (e.g. a video glitch).
        if response >= self.min_response and abs(dy) < height * 0.4:
            self.position += float(dy)
        return self.position


# ---------------------------------------------------------------------------
# 2. Height signal -> reps
# ---------------------------------------------------------------------------
@dataclass
class RepEvent:
    """One finished rep.

    Times are measured between 10% and 90% of the rep's depth, which ignores
    the slow, noisy start and the flat bottom. Use the same measurement for
    targets (or calibrate targets from your own good reps).
    """

    number: int
    start: float  # seconds: left the 10% band
    bottom: float  # middle of the time spent past 90% depth
    end: float  # back inside the 10% band
    depth: float  # size of the movement (signal units)
    down_time: float  # 10% -> 90% on the way down
    up_time: float  # 90% -> 10% on the way back
    partial: bool = False  # started before the counter re-learned its rest: timing not trustworthy

    @property
    def duration(self) -> float:
        return self.end - self.start


class RepCounter:
    """Counts reps from a 1-D signal, without needing to know which way is "down".

    threshold    how far (signal units) you must move away from rest to start a rep
    return_frac  rep ends when you're back within this fraction of the deepest point
    smoothing    0..1, higher = smoother but laggier signal
    """

    def __init__(
        self,
        threshold: float = 6.0,
        return_frac: float = 0.3,
        smoothing: float = 0.35,
        min_rep: float = 0.5,
        max_rep: float = 10.0,
        rest_follow: float = 0.02,
    ):
        self.threshold = threshold
        self.return_frac = return_frac
        self.smoothing = smoothing
        self.min_rep = min_rep
        self.max_rep = max_rep
        self.rest_follow = rest_follow
        self.reset()

    # States: resting -> out (moving away) -> returning (coming back) -> resting
    REST, OUT, RETURNING = "rest", "out", "returning"

    def reset(self) -> None:
        self.count = 0
        self._smooth: Optional[float] = None
        self._baseline: Optional[float] = None
        self.state = self.REST
        self._direction = 0
        self._extreme = 0.0
        self._t_extreme = 0.0
        self._t_start = 0.0
        self._t_last_rest = 0.0
        self._best_return = 0.0  # closest point to the start seen while returning
        self._t_best = 0.0
        self._t_prev_end = -1e9
        self._history: deque = deque(maxlen=400)  # recent (time, deviation)
        self.reps: list[RepEvent] = []

    def rebase(self, level: Optional[float] = None) -> None:
        """Restart from a new resting level (used when the clip re-learns its reference). Keeps the count.
        level=None: rest = wherever the signal is now. level=0: rest = the reference itself, so a rep
        that is already under way still gets counted."""
        self._smooth = None
        self._baseline = level
        self.state = self.REST
        self._history.clear()
        self._restart_clock = True

    @property
    def smoothed(self) -> float:
        return 0.0 if self._smooth is None else self._smooth

    @property
    def deviation(self) -> float:
        if self._smooth is None or self._baseline is None:
            return 0.0
        return self._smooth - self._baseline

    def _finish(self) -> Optional[RepEvent]:
        """Close the rep at its top point and re-anchor the resting level there."""
        self.state = self.REST
        d, ext = self._direction, abs(self._extreme)
        seg = [(th, d * dh) for th, dh in self._history if self._t_prev_end <= th <= self._t_best]
        end_level = d * self._best_return + 0.1 * ext

        t90 = [th for th, a in seg if a >= 0.9 * ext]
        t_start, t_end = self._t_start, self._t_best
        t90_first = t90[0] if t90 else self._t_extreme
        t90_last = t90[-1] if t90 else self._t_extreme
        before = [th for th, a in seg if th <= t90_first and a <= 0.1 * ext]
        after = [th for th, a in seg if th >= t90_last and a <= end_level]
        if before:
            t_start = before[-1]
        if after:
            t_end = after[0]

        self._baseline += self._best_return
        self._t_last_rest = self._t_best
        self._t_prev_end = self._t_best
        duration = t_end - t_start
        if self.min_rep <= duration <= self.max_rep:
            self.count += 1
            rep = RepEvent(
                number=self.count,
                start=t_start,
                bottom=(t90_first + t90_last) / 2,
                end=t_end,
                depth=ext,
                down_time=max(0.0, t90_first - t_start),
                up_time=max(0.0, t_end - t90_last),
                partial=getattr(self, "_partial_next", False),
            )
            self._partial_next = False
            self.reps.append(rep)
            return rep
        return None

    def update(self, t: float, value: float) -> Optional[RepEvent]:
        a = self.smoothing
        self._smooth = value if self._smooth is None else a * self._smooth + (1 - a) * value
        if self._baseline is None:
            self._baseline = self._smooth
            self._t_last_rest = t
        if getattr(self, "_restart_clock", False):
            self._restart_clock = False
            self._t_last_rest = t
            self._t_prev_end = t
            self._partial_next = abs(self._smooth - self._baseline) > self.threshold  # rep already under way
        dev = self._smooth - self._baseline
        self._history.append((t, dev))
        d = self._direction

        if self.state == self.REST:
            if abs(dev) < self.threshold * 0.5:
                self._t_last_rest = t
                # Slowly follow the signal while resting, to cancel drift.
                self._baseline += self.rest_follow * dev
            if abs(dev) > self.threshold:
                self.state = self.OUT
                self._direction = 1 if dev > 0 else -1
                self._extreme = dev
                self._t_extreme = t
                self._t_start = self._t_last_rest
            return None

        if t - self._t_start > self.max_rep:  # too long to be a rep: start over
            self.state = self.REST
            self._baseline = self._smooth
            self._t_last_rest = t
            return None

        if self.state == self.OUT:
            if d * dev > d * self._extreme:
                self._extreme = dev
                self._t_extreme = t
            if abs(dev) <= abs(self._extreme) * self.return_frac:
                self.state = self.RETURNING
                self._best_return = dev
                self._t_best = t
            return None

        # RETURNING: wait until the movement stops or the next rep begins.
        if d * dev < d * self._best_return:
            self._best_return = dev
            self._t_best = t
        moving_away_again = d * (dev - self._best_return) > self.threshold * 0.4
        stopped = t - self._t_best > 0.3
        if moving_away_again or stopped:
            return self._finish()
        return None


class TiltTracker:
    """Turns the clip's tilt (pitch, roll) into ONE number: degrees turned away from a reference pose.

    Why: depending on how the case is strapped on, a curl shows up as pitch, roll or a mix,
    and roll can jump from +180 to -180. Here we rebuild the clip's "down" direction as an arrow
    (unit vector) and measure the angle between that arrow now and a reference arrow:

        u    = (-sin p,  cos p * sin r,  cos p * cos r)     p = pitch, r = roll
        tilt = arccos(u . u_ref)                             0 = at the reference pose

    A curl swings the arrow along an arc. Counting works if the reference sits at an end of that arc.
    The reference is re-learned when:
      1. the clip is held still (1.2 s while the counter rests, or 3 s at any time), or
      2. the arrow is clearly swinging (> 30 degrees in the last 3 s) but the reference is not at an
         end of that swing (it's off to the side or in the middle), so jump to the swing's nearest end.
    """

    def __init__(self, still_deg: float = 5.0, still_time: float = 1.2, long_still_time: float = 3.0,
                 arc_window: float = 3.0, min_arc: float = 30.0):
        self.still_deg = still_deg
        self.still_time = still_time
        self.long_still_time = long_still_time
        self.arc_window = arc_window
        self.min_arc = min_arc
        self.reset()

    def reset(self) -> None:
        self.ref: Optional[np.ndarray] = None
        self.rest_pose: Optional[np.ndarray] = None  # where the clip was last held still (~1 s)
        self._recent: deque = deque()
        self._last_check = -1e9

    def _still_mean(self, t: float, need: float) -> Optional[np.ndarray]:
        """Average arrow if the clip has been still for `need` seconds, else None."""
        if not self._recent or t - self._recent[0][0] < need * 0.9:
            return None
        window = np.array([v for (tv, v) in self._recent if t - tv <= need])
        if len(window) < 5:
            return None
        mean = window.mean(axis=0)
        mean /= np.linalg.norm(mean) or 1.0
        return mean if self._angles(window, mean).max() < self.still_deg else None

    @staticmethod
    def unit(pitch: float, roll: float) -> np.ndarray:
        p, r = np.radians(pitch), np.radians(roll)
        return np.array([-np.sin(p), np.cos(p) * np.sin(r), np.cos(p) * np.cos(r)])

    @staticmethod
    def angle(a: np.ndarray, b: np.ndarray) -> float:
        return float(np.degrees(np.arccos(np.clip(np.dot(a, b), -1.0, 1.0))))

    @staticmethod
    def _angles(vs: np.ndarray, b: np.ndarray) -> np.ndarray:
        return np.degrees(np.arccos(np.clip(vs @ b, -1.0, 1.0)))

    def update(self, t: float, pitch: float, roll: float, resting: bool = True) -> tuple[float, bool]:
        """Returns (degrees from the reference, True if the reference was just re-learned)."""
        u = self.unit(pitch, roll)
        if self.ref is None:
            self.ref = u
        self._recent.append((t, u))
        keep = max(self.long_still_time, self.arc_window)
        while self._recent and t - self._recent[0][0] > keep:
            self._recent.popleft()
        relearned = False

        # 1. Held still: remember the pose; it becomes the reference if the counter is resting (or after 3 s).
        short = self._still_mean(t, 1.0)
        if short is not None:
            self.rest_pose = short
        mean = self._still_mean(t, self.still_time if resting else self.long_still_time)
        if mean is not None and self.angle(mean, self.ref) > self.still_deg:
            self.ref = mean
            relearned = True

        # 2. Swinging, but the tilt number doesn't follow: move the reference to an end of the arc.
        if not relearned and t - self._last_check >= 0.25:
            self._last_check = t
            vs = np.array([v for (tv, v) in self._recent if t - tv <= self.arc_window])
            if len(vs) >= 20:
                mean = vs.mean(axis=0)
                mean /= np.linalg.norm(mean) or 1.0
                a = vs[int(np.argmax(self._angles(vs, mean)))]   # one end of the arc
                b = vs[int(np.argmax(self._angles(vs, a)))]      # the other end
                arc = self.angle(a, b)
                # Good reference = at (or beyond) one end of the arc: then its distances to the two
                # ends differ by about the whole arc. Off to the side or in the middle, they don't.
                if arc > self.min_arc and abs(self.angle(self.ref, a) - self.angle(self.ref, b)) < 0.8 * arc:
                    # Prefer the end nearest where the clip was last held still (the bottom of a curl).
                    near = self.rest_pose if self.rest_pose is not None else u
                    self.ref = a if self.angle(near, a) <= self.angle(near, b) else b
                    relearned = True
        return self.angle(u, self.ref), relearned


# ---------------------------------------------------------------------------
# 3. Tempo feedback and curve comparison
# ---------------------------------------------------------------------------
@dataclass
class TempoTarget:
    # Measured 10%->90% (see RepEvent). A smooth rep that really takes
    # 2 s down / 1.5 s up measures about 1.2 s / 0.9 s.
    down: float = 1.2
    up: float = 0.9
    tolerance: float = 0.4  # fraction: 0.4 means +/-40% still counts as good


# Default clip tempo for curls (10%->90% times): lift ~1 s, lower ~1.5-2 s.
CLIP_TEMPO = TempoTarget(down=0.6, up=1.0)


def target_from_reps(reps: list[RepEvent], tolerance: float = 0.4) -> TempoTarget:
    """Calibrate: use the average of a few good reps as the target."""
    if not reps:
        return TempoTarget()
    return TempoTarget(
        down=float(np.mean([r.down_time for r in reps])),
        up=float(np.mean([r.up_time for r in reps])),
        tolerance=tolerance,
    )


def tempo_feedback(rep: RepEvent, target: TempoTarget, away: str = "down", back: str = "up") -> tuple[bool, str]:
    """Returns (is_good, short spoken cue).

    away/back name the two halves of the rep for the spoken cue: for squats seen from the
    glasses you move "down" then "up"; for curls measured by the clip you lift "up" then lower "down".
    """
    if rep.partial:  # we only saw part of this rep: count it, don't judge it
        return True, ""
    lo = 1 - target.tolerance
    if rep.down_time < target.down * lo:
        return False, f"Slower on the way {away}"
    if rep.up_time < target.up * lo * 0.6:
        return False, f"Control the way {back}"
    if rep.down_time + rep.up_time > (target.down + target.up) * (1 + target.tolerance) * 2:
        return False, "Keep a steady pace"
    return True, ""


def target_curve(down: float, up: float, rate: float = 15.0) -> np.ndarray:
    """Ideal rep shape: a smooth dip that takes `down` s, then rises over `up` s."""
    n_down = max(2, int(round(down * rate)))
    n_up = max(2, int(round(up * rate)))
    going_down = (1 - np.cos(np.linspace(0, np.pi, n_down))) / 2
    going_up = (1 + np.cos(np.linspace(0, np.pi, n_up))) / 2
    return np.concatenate([going_down, going_up[1:]])


def _normalize(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    span = np.ptp(x)
    return (x - x.min()) / span if span > 1e-9 else np.zeros_like(x)


def dtw_distance(a: np.ndarray, b: np.ndarray, normalize: bool = True) -> float:
    """Dynamic time warping: lines up two curves even if one is slower,
    then returns the average gap between them (0 = identical shape).

    cost[i][j] = |a_i - b_j| + min(cost of the 3 neighbouring alignments)
    """
    a = _normalize(a) if normalize else np.asarray(a, dtype=float)
    b = _normalize(b) if normalize else np.asarray(b, dtype=float)
    n, m = len(a), len(b)
    if n == 0 or m == 0:
        return float("inf")
    cost = np.full((n + 1, m + 1), np.inf)
    steps = np.zeros((n + 1, m + 1))
    cost[0, 0] = 0.0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d = abs(a[i - 1] - b[j - 1])
            options = (cost[i - 1, j], cost[i, j - 1], cost[i - 1, j - 1])
            k = int(np.argmin(options))
            prev = (i - 1, j) if k == 0 else (i, j - 1) if k == 1 else (i - 1, j - 1)
            cost[i, j] = d + options[k]
            steps[i, j] = steps[prev] + 1
    return float(cost[n, m] / steps[n, m])
