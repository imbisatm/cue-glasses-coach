"""Gets video frames from either the WhatsApp call window or a webcam.

ScreenSource: grabs a rectangle of your screen (the glasses video inside the
WhatsApp call). You pick the rectangle once with your mouse; it's saved.
WebcamSource: uses the laptop camera, handy for testing without the glasses.
"""

from __future__ import annotations

import sys

import numpy as np


def make_dpi_aware() -> None:
    """On Windows, make screen coordinates match real pixels (fixes 125%/150% scaling)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


class ScreenSource:
    def __init__(self, region: dict | None = None, monitor: int = 1):
        import mss

        make_dpi_aware()
        self._sct = mss.mss()
        self.monitor = monitor
        self.region = region

    def select_region(self) -> dict | None:
        """Shows a screenshot; drag a box around the glasses video, then press ENTER."""
        import cv2

        mon = self._sct.monitors[min(self.monitor, len(self._sct.monitors) - 1)]
        shot = np.array(self._sct.grab(mon))[:, :, :3]
        scale = min(1.0, 1400 / shot.shape[1], 800 / shot.shape[0])
        view = cv2.resize(shot, None, fx=scale, fy=scale) if scale < 1 else shot.copy()
        title = "Drag a box around the GLASSES VIDEO, then press ENTER (C = cancel)"
        cv2.namedWindow(title, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(title, view.shape[1], view.shape[0])
        cv2.moveWindow(title, 0, 0)
        try:  # keep the picker on top of WhatsApp and the Cue window
            cv2.setWindowProperty(title, cv2.WND_PROP_TOPMOST, 1)
        except Exception:
            pass
        x, y, w, h = cv2.selectROI(title, view, showCrosshair=False, fromCenter=False)
        cv2.destroyWindow(title)
        if w < 20 or h < 20:
            return None
        self.region = {
            "left": int(mon["left"] + x / scale),
            "top": int(mon["top"] + y / scale),
            "width": int(w / scale),
            "height": int(h / scale),
        }
        return self.region

    def read(self) -> np.ndarray | None:
        if not self.region:
            return None
        img = np.array(self._sct.grab(self.region))
        return np.ascontiguousarray(img[:, :, :3])

    def close(self) -> None:
        self._sct.close()


class WebcamSource:
    def __init__(self, index: int = 0):
        import cv2

        self._cap = cv2.VideoCapture(index)
        if not self._cap.isOpened():
            raise RuntimeError(f"Could not open webcam {index}")

    def read(self) -> np.ndarray | None:
        ok, frame = self._cap.read()
        return frame if ok else None

    def close(self) -> None:
        self._cap.release()
