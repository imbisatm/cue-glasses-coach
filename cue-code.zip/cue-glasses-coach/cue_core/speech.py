"""Speaks short coaching cues without freezing the video loop.

- Runs text-to-speech (Windows built-in voices via pyttsx3) in a background thread.
- Never piles up: if Cue is still talking, only the newest cue waits its turn.
- Cooldown per cue, so "Curl your fingertips" isn't repeated every frame.
- Voice routing ("audio_device" in config.json):
    "default" / "auto"  if VB-Audio Virtual Cable is installed, speak into the cable (WhatsApp's
                        microphone = "CABLE Output", so the glasses hear Cue) AND the laptop
                        speakers (so people nearby hear it). Otherwise just the speakers.
    "speakers"          laptop speakers only
    any other text      that output device only (e.g. "CABLE Input")
"""

from __future__ import annotations

import os
import queue
import tempfile
import threading
import time
import wave


class Speaker:
    def __init__(self, rate: int = 185, device: str = "default", cooldown: float = 3.0, also_speakers: bool = True):
        self.rate = rate
        self.device = device
        self.also_speakers = also_speakers
        self.cooldown = cooldown
        self.route = "laptop speakers"
        self._targets = self._pick_targets()
        self._last_said: dict[str, float] = {}
        self._last_any = 0.0
        self._queue: "queue.Queue[str]" = queue.Queue(maxsize=3)
        self.last_text = ""
        self.last_time = 0.0  # when the current/last line started (for on-screen captions)
        self.spoken = 0       # lines finished
        self.failed = 0       # lines that could not be spoken
        self._busy_since = 0.0
        self._gen = 0         # bumps when a stuck voice thread is replaced
        self._start_thread()

    def _start_thread(self) -> None:
        self._busy_since = 0.0
        threading.Thread(target=self._run, args=(self._gen,), daemon=True).start()

    @property
    def stuck(self) -> bool:
        return bool(self._busy_since) and time.monotonic() - self._busy_since > 20.0

    def watchdog(self) -> None:
        """If one line has been 'speaking' for 20 s the voice engine hung: start a fresh one."""
        if self.stuck:
            print("[Cue] The voice got stuck. Restarting it.")
            self._gen += 1
            self._start_thread()

    def say(self, text: str, key: str | None = None, cooldown: float | None = None, force: bool = False) -> bool:
        """Queue a cue. Returns False if skipped (cooldown, or Cue is busy talking).

        force=True  important messages (step instructions, rep counts): always queued
        force=False nice-to-have cues: skipped if something is already waiting
        """
        key = key or text
        now = time.monotonic()
        self.watchdog()
        wait = self.cooldown if cooldown is None else cooldown
        if not force and now - self._last_said.get(key, -1e9) < wait:
            return False
        if not force and not self._queue.empty():
            return False
        if force and self._queue.full():
            try:  # make room by dropping the oldest waiting message
                self._queue.get_nowait()
            except queue.Empty:
                pass
        try:
            self._queue.put_nowait(text)
        except queue.Full:
            return False
        self._last_said[key] = now
        return True

    # -- background thread -------------------------------------------------
    def _run(self, gen: int = 0) -> None:
        # Voice engines, best first. Each turns one line into a wav file that we play on every output.
        # After a stuck voice gets restarted (gen > 0), skip straight to the PowerShell voice.
        makers = [_SapiToFile, _PowerShellToFile, _Pyttsx3ToFile] if gen == 0 else [_PowerShellToFile, _Pyttsx3ToFile]
        engines = []
        for make in makers:
            eng = make.create(self.rate)
            if eng is not None:
                engines.append(eng)
                if len(engines) == 1:
                    print(f"[Cue] Voice engine: {eng.name}")
        if not engines:
            print("[Cue] No text-to-speech voice found on this computer.")
            return
        tmp = os.path.join(tempfile.gettempdir(), f"cue_tts_{gen}.wav")
        targets = self._targets or [None]
        while True:
            text = self._queue.get()
            if gen != self._gen:  # a newer voice thread took over
                self._put_back(text)
                return
            self.last_text = text
            self.last_time = self._busy_since = time.monotonic()
            done = False
            while engines and not done:
                eng = engines[0]
                try:
                    try:
                        os.remove(tmp)
                    except OSError:
                        pass
                    eng.to_wav(text, tmp)
                    if not _has_sounddevice():
                        raise RuntimeError("sounddevice is not installed")
                    self._play_file(tmp, targets)
                    done = True
                except Exception as exc:  # this engine failed: use the next one from now on
                    print(f"[Cue] Voice engine '{eng.name}' failed: {str(exc)[:160]}")
                    engines.pop(0)
                    if engines:
                        print(f"[Cue] Switching to: {engines[0].name}")
            if done:
                self.spoken += 1
                print(f"[Cue] {time.strftime('%H:%M:%S')}  Spoken ({self.route}): \"{text}\"")
            else:
                self.failed += 1
                print(f"[Cue] Could not say: \"{text}\"")
            if gen == self._gen:
                self._busy_since = 0.0
            else:
                return
            if not engines:
                print("[Cue] Every voice engine failed. Close Cue and send the black window text to Claude.")
                return

    def _put_back(self, text: str) -> None:
        try:
            self._queue.put_nowait(text)
        except queue.Full:
            pass

    def _pick_targets(self) -> list:
        """Output devices to play on. Empty list = let Windows speak on the default speakers."""
        want = (self.device or "default").strip().lower()
        if want == "speakers":
            return []
        import importlib.util

        if importlib.util.find_spec("sounddevice") is None:
            return []
        if want in ("default", "auto", ""):
            cable = find_output_device("CABLE Input", quiet=True)
            if cable is None:
                return []
            targets = [cable]
            self.route = "glasses (VB-Cable)"
            if self.also_speakers:
                targets.append(find_speakers())
                self.route = "glasses + laptop speakers"
            return targets
        dev = find_output_device(self.device)
        self.route = self.device
        return [dev] if dev is not None else []

    def _play_file(self, path: str, targets: list | None = None) -> None:
        import numpy as np

        with wave.open(path, "rb") as wf:
            frames = wf.readframes(wf.getnframes())
            rate = wf.getframerate()
            channels = wf.getnchannels()
            width = wf.getsampwidth()
        dtype = {1: np.int8, 2: np.int16, 4: np.int32}[width]
        data = np.frombuffer(frames, dtype=dtype).reshape(-1, channels)
        devices = targets if targets is not None else self._targets
        players = [threading.Thread(target=_play_on, args=(dev, data, rate), daemon=True) for dev in devices]
        for p in players:
            p.start()
        for p in players:
            p.join(timeout=15)


def _play_on(device, data, rate) -> None:
    """Plays one clip on one output device (several of these run at the same time)."""
    import sounddevice as sd

    try:
        with sd.OutputStream(samplerate=rate, channels=data.shape[1], dtype=data.dtype.name, device=device) as stream:
            stream.write(data)
    except Exception as exc:
        print(f"[Cue] Could not play the voice on device {device}: {exc}")


def find_speakers():
    """The real laptop speakers. Usually Windows' default output (None), unless installing
    VB-Cable made the cable the default - then look for a device called Speakers/Headphones."""
    import sounddevice as sd

    try:
        default_name = sd.query_devices(kind="output")["name"].lower()
    except Exception:
        return None
    if "cable" not in default_name:
        return None
    for i, dev in enumerate(sd.query_devices()):
        name = dev["name"].lower()
        if dev["max_output_channels"] > 0 and "cable" not in name and ("speaker" in name or "headphone" in name):
            return i
    return None


def find_output_device(name_part: str, quiet: bool = False):
    """Returns the index of the first output device whose name contains name_part."""
    import sounddevice as sd

    for i, dev in enumerate(sd.query_devices()):
        if dev["max_output_channels"] > 0 and name_part.lower() in dev["name"].lower():
            return i
    if not quiet:
        print(f"[speech] output device '{name_part}' not found, using default speakers")
    return None


def list_output_devices() -> list[str]:
    import sounddevice as sd

    return [d["name"] for d in sd.query_devices() if d["max_output_channels"] > 0]



def _has_sounddevice() -> bool:
    import importlib.util

    return importlib.util.find_spec("sounddevice") is not None


class _SapiToFile:
    """Talks to the Windows speech engine (SAPI) directly: text -> wav file, no event loop.
    The same calls pyttsx3 makes, minus the loop that can hang after the first line."""

    name = "Windows voice (direct)"

    def __init__(self, rate_wpm: int):
        import math

        import comtypes

        try:
            comtypes.CoInitialize()   # this runs in a background thread
        except OSError:
            pass
        import comtypes.client

        self._client = comtypes.client
        self.voice = comtypes.client.CreateObject("SAPI.SpVoice")
        try:
            from comtypes.gen import SpeechLib
        except ImportError:
            comtypes.client.CreateObject("SAPI.SpFileStream")
            from comtypes.gen import SpeechLib
        self._lib = SpeechLib
        try:
            self.voice.Rate = max(-10, min(10, int(math.log(max(80, rate_wpm) / 156.63, 1.11))))
        except Exception:
            pass

    @classmethod
    def create(cls, rate_wpm: int):
        if os.name != "nt":
            return None
        try:
            return cls(rate_wpm)
        except Exception as exc:
            print(f"[Cue] Using the backup voice engine ({exc})")
            return None

    def to_wav(self, text: str, path: str) -> None:
        stream = self._client.CreateObject("SAPI.SpFileStream")
        stream.Open(path, self._lib.SSFMCreateForWrite)
        old = self.voice.AudioOutputStream
        try:
            self.voice.AudioOutputStream = stream
            self.voice.Speak(str(text), 0)   # 0 = wait until done
        finally:
            self.voice.AudioOutputStream = old
            stream.Close()

    def speak(self, text: str) -> None:
        self.voice.Speak(str(text), 0)


class _PowerShellToFile:
    """Backup: Windows' built-in .NET voice in a separate PowerShell process (can't hang Cue)."""

    name = "Windows voice (PowerShell)"

    def __init__(self, rate_wpm: int):
        self.rate = max(-10, min(10, int(round((rate_wpm - 175) / 15))))

    @classmethod
    def create(cls, rate_wpm: int):
        if os.name != "nt":
            return None
        return cls(rate_wpm)

    def to_wav(self, text: str, path: str) -> None:
        import subprocess

        target = path.replace("'", "''")
        script = ("Add-Type -AssemblyName System.Speech; "
                  "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  f"$s.Rate = {self.rate}; $s.SetOutputToWaveFile('{target}'); "
                  "$t = [Console]::In.ReadToEnd(); $s.Speak($t); $s.Dispose()")
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
                           input=text, text=True, capture_output=True, timeout=20,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0 or not os.path.exists(path) or os.path.getsize(path) < 200:
            raise RuntimeError((r.stderr or "").strip()[:200] or "PowerShell voice made no sound file")


class _Pyttsx3ToFile:
    """Last resort: pyttsx3 (the old way)."""

    name = "pyttsx3"

    def __init__(self, rate_wpm: int):
        import pyttsx3

        self.engine = pyttsx3.init()
        self.engine.setProperty("rate", rate_wpm)

    @classmethod
    def create(cls, rate_wpm: int):
        try:
            return cls(rate_wpm)
        except Exception:
            return None

    def to_wav(self, text: str, path: str) -> None:
        self.engine.save_to_file(text, path)
        self.engine.runAndWait()
        if not os.path.exists(path):
            raise RuntimeError("pyttsx3 made no sound file")
