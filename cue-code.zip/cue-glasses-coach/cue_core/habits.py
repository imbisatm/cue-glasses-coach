"""All-day habit coach: what the glasses see, turned into a healthier day.

Every few seconds one frame goes to the vision model with ONE question: which of these
things are happening right now (SIGNS), and is the wearer outdoors / in daylight / in the dark?
The rules below then decide, using the time of day, whether that's worth logging,
praising or nudging. Adding a habit = add a sign and a rule.

The clock can run on real time or a demo clock (Morning / Afternoon / Night),
so a demo at 9 AM can show what Cue says at 11 PM.

Advice is general wellness, not medical advice.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

# What the model is asked to look for. id -> description the model reads.
SIGNS = {
    "drinking_water": "holding up or drinking from a water bottle or a glass of water",
    "coffee": "a cup of coffee or tea with caffeine in hand",
    "energy_drink": "an energy drink can in hand",
    "alcohol": "an alcoholic drink (beer, wine, liquor, cocktail) in hand",
    "phone_scrolling": "looking at a phone screen showing social media, short videos or a scrolling feed",
    "screen": "looking at any phone, laptop, tablet or TV screen",
    "fruit_veg": "holding or eating fruit or vegetables",
    "junk_food": "holding or eating chips, candy, cookies or fast food",
    "soda": "a can or bottle of soda or another sugary drink in hand",
    "eating": "eating any food",
    "brushing_teeth": "brushing teeth",
    "sunscreen": "applying sunscreen or lotion to skin",
    "pills": "holding or taking vitamins, supplements or pills",
    "stairs": "walking up or down stairs",
    "book": "reading a paper book",
    "desk": "sitting at a desk in front of a laptop or computer",
    "vape": "a vape or e-cigarette in hand or being used",
    "cigarette": "a cigarette in hand or being smoked",
    "nicotine_pouch": "a nicotine pouch tin (like Zyn) or nicotine pouches in hand",
    "betting": "a phone or screen showing a sports betting, casino or gambling app",
}

# The Today checklist, by time of day. (id, name)
CHECKLIST = [
    ("Morning", [("sun", "Morning sunlight"), ("teeth_am", "Brush teeth"), ("sunscreen", "Sunscreen"), ("vitamins", "Vitamins")]),
    ("Day", [("water", "Water"), ("caffeine", "Caffeine before 2 PM"), ("veg", "Fruit and veg"), ("move", "Move")]),
    ("Night", [("screens", "No screens after 10"), ("no_late", "No late drinks"), ("teeth_pm", "Brush teeth"), ("wind_down", "Read to wind down")]),
    ("Break", [("nicotine", "Vape and nicotine"), ("scroll", "Doomscrolling"), ("sugar", "Sugary drinks"), ("betting", "Betting apps")]),
]
BREAK = "Break"   # the bad-habit column

DEMO_HOURS = {"morning": 8.0, "afternoon": 15.0, "night": 23.0}
CLOCK_MODES = ["live", "morning", "afternoon", "night"]


@dataclass
class Nudge:
    text: str
    warn: bool = False       # orange caption + warning buzz
    habit: str = ""


@dataclass
class Clock:
    mode: str = "live"

    def hour(self) -> float:
        if self.mode in DEMO_HOURS:
            return DEMO_HOURS[self.mode]
        lt = time.localtime()
        return lt.tm_hour + lt.tm_min / 60

    def label(self) -> str:
        h = self.hour()
        hh, mm = int(h), int(round((h - int(h)) * 60)) % 60
        ampm = "AM" if hh < 12 else "PM"
        return f"{(hh % 12) or 12}:{mm:02d} {ampm}"

    def cycle(self) -> str:
        self.mode = CLOCK_MODES[(CLOCK_MODES.index(self.mode) + 1) % len(CLOCK_MODES)]
        return self.mode


def build_prompt() -> str:
    lines = "\n".join(f"- {k}: {v}" for k, v in SIGNS.items())
    return (
        "This photo is from smart glasses, showing what the wearer sees right now.\n"
        "Which of these are clearly happening? Only list what you can actually see.\n"
        "Count an item if the wearer is holding it or it is right in front of them.\n"
        f"{lines}\n"
        'Reply with JSON only: {"seen": [ids from the list], "outdoors": true/false, '
        '"sunlight": true/false (daylight or sun visible), "dark": true/false (dim room), '
        '"note": "max 8 words: what the wearer is doing"}'
    )


# Other words a model might use for a sign id.
ALIASES = {
    "water": "drinking_water", "water_bottle": "drinking_water", "drinking": "drinking_water",
    "tea": "coffee", "energy": "energy_drink", "beer": "alcohol", "wine": "alcohol",
    "scrolling": "phone_scrolling", "social_media": "phone_scrolling", "doomscrolling": "phone_scrolling",
    "phone": "screen", "laptop": "screen", "tv": "screen",
    "fruit": "fruit_veg", "vegetables": "fruit_veg", "junk": "junk_food", "snack": "junk_food",
    "sugary_drink": "soda", "toothbrush": "brushing_teeth", "vitamins": "pills", "supplements": "pills",
    "vaping": "vape", "e_cigarette": "vape", "smoking": "cigarette", "zyn": "nicotine_pouch",
    "nicotine": "nicotine_pouch", "gambling": "betting", "casino": "betting", "reading": "book",
}

# If the model writes it in the note but forgets the list ("holding a water bottle"), still count it.
NOTE_WORDS = [
    (r"water", "drinking_water"), (r"vap(e|es|ing)|e-?cig", "vape"), (r"cigarettes?|smoking", "cigarette"),
    (r"zyn|nicotine", "nicotine_pouch"), (r"coffee|espresso|latte", "coffee"),
    (r"energy drink|red bull|monster|celsius", "energy_drink"), (r"beer|wine|liquor|vodka|whiskey|alcohol", "alcohol"),
    (r"soda|coke|pepsi|sprite|fanta|dr pepper", "soda"), (r"chips|candy|cookies?|fries|burger|chocolate", "junk_food"),
    (r"apples?|bananas?|fruit|vegetables?|carrots?|salad|grapes", "fruit_veg"),
    (r"scrolling|instagram|tiktok|reels|youtube shorts", "phone_scrolling"),
    (r"betting|gambling|casino|sportsbook", "betting"), (r"toothbrush|brushing (his |her |their )?teeth", "brushing_teeth"),
    (r"vitamins?|pills?|supplements?", "pills"), (r"sunscreen", "sunscreen"), (r"stairs", "stairs"),
    (r"(paper )?book", "book"), (r"laptop|computer|phone|screen|tv|television", "screen"),
]


def _sign_id(word: str) -> str:
    w = re.sub(r"[\s\-]+", "_", str(word).strip().lower())
    return w if w in SIGNS else ALIASES.get(w, "")


def signs_in_note(note: str) -> list:
    text = (note or "").lower()
    if not text or re.search(r"\b(no|not|without|isn't|aren't)\b", text):
        return []
    return [sid for pat, sid in NOTE_WORDS if re.search(r"\b(" + pat + r")\b", text)]


def parse_observation(data: dict) -> dict:
    seen = data.get("seen") or []
    if isinstance(seen, str):
        seen = [seen]
    ids = [i for i in (_sign_id(x) for x in seen) if i]
    for extra in signs_in_note(str(data.get("note") or "")):
        if extra not in ids:
            ids.append(extra)
    return {
        "seen": ids,
        "outdoors": bool(data.get("outdoors")),
        "sunlight": bool(data.get("sunlight")),
        "dark": bool(data.get("dark")),
        "note": str(data.get("note") or "")[:80],
    }


@dataclass
class DayStats:
    date: str = ""
    water_ml: int = 0
    sun_s: float = 0.0
    outside_s: float = 0.0
    caffeine: int = 0
    caffeine_late: int = 0
    alcohol_late: int = 0
    night_screen: int = 0
    scroll_nudges: int = 0
    veg: int = 0
    junk: int = 0
    teeth_am: bool = False
    teeth_pm: bool = False
    sunscreen: bool = False
    vitamins: bool = False
    stairs: int = 0
    book: bool = False
    reps: int = 0
    late_meal: int = 0
    nicotine: int = 0
    nicotine_last: str = ""
    scroll_s: float = 0.0
    soda: int = 0
    betting: int = 0
    log: list = field(default_factory=list)   # [(clock label, text)] newest last


class HabitCoach:
    WATER_GOAL = 2000
    SUN_GOAL = 600          # seconds of morning light
    CAFFEINE_CUTOFF = 14.0  # 2 PM
    BEDTIME = 22.0
    CONFIRM = 1             # frames in a row before a bad-habit warning (1 = speak right away)

    def __init__(self, save_path: Optional[Path] = None, log: Optional[Callable] = None):
        self.clock = Clock()
        self.save_path = save_path
        self._log = log or (lambda *a: None)
        self.stats = DayStats(date=time.strftime("%Y-%m-%d"))
        self._load()
        self._streak: dict = {}          # sign -> consecutive frames seen
        self._last: dict = {}            # habit -> last time it spoke (monotonic)
        self._last_water = time.monotonic()
        self._said_once: set = set()
        self.last_seen: list = []
        self.last_note = ""
        self.last_obs_time = 0.0

    # ---- persistence: today's progress survives a restart ----
    def _load(self) -> None:
        if not self.save_path or not self.save_path.exists():
            return
        try:
            data = json.loads(self.save_path.read_text())
            if data.get("date") == self.stats.date:
                known = {k: v for k, v in data.items() if k in DayStats.__dataclass_fields__}
                self.stats = DayStats(**known)
        except Exception:
            pass

    def save(self) -> None:
        if self.save_path:
            try:
                self.save_path.write_text(json.dumps(self.stats.__dict__))
            except Exception:
                pass

    def reset_day(self) -> None:
        self.stats = DayStats(date=time.strftime("%Y-%m-%d"))
        self._said_once.clear()
        self.save()

    def set_clock(self, mode: str) -> None:
        """Demo clock. Clearing cooldowns lets the same coffee get a new verdict right away."""
        self.clock.mode = mode if mode in CLOCK_MODES else "live"
        self._last.clear()
        self._streak.clear()

    def cycle_clock(self) -> str:
        self.set_clock(CLOCK_MODES[(CLOCK_MODES.index(self.clock.mode) + 1) % len(CLOCK_MODES)])
        return self.clock.mode

    # ---- helpers ----
    def _ready(self, key: str, cooldown: float) -> bool:
        now = time.monotonic()
        if now - self._last.get(key, -1e9) < cooldown:
            return False
        self._last[key] = now
        return True

    def _note(self, text: str) -> None:
        self.stats.log.append((self.clock.label(), text))
        self.stats.log = self.stats.log[-30:]
        self._log("habits", "log", text, self.clock.mode)

    @property
    def night(self) -> bool:
        h = self.clock.hour()
        return h >= self.BEDTIME or h < 5

    @property
    def morning(self) -> bool:
        return 5 <= self.clock.hour() < 11

    # ---- main input: one model answer ----
    def observe(self, obs: dict, dt: float = 3.0) -> list[Nudge]:
        dt = max(0.0, min(dt, 10.0))
        s, out = self.stats, []
        seen = set(obs.get("seen", []))
        self.last_seen, self.last_note = sorted(seen), obs.get("note", "")
        self.last_obs_time = time.monotonic()
        for k in list(self._streak):
            if k not in seen:
                self._streak[k] = 0
        for k in seen:
            self._streak[k] = self._streak.get(k, 0) + 1
        h = self.clock.hour()
        late_caffeine = h >= self.CAFFEINE_CUTOFF or h < 5

        def say(key, text, warn=False, cooldown=25.0):
            if self._ready(key, cooldown):
                out.append(Nudge(text, warn, key))
                return True
            return False

        # light and fresh air
        if obs.get("outdoors") and obs.get("sunlight") and 5 <= h < 19:
            before = s.sun_s
            s.outside_s += dt
            if self.morning:
                s.sun_s += dt
                if before == 0 and say("sun", "Morning light logged. It helps set your body clock."):
                    self._note("Morning light started")
                elif before < self.SUN_GOAL <= s.sun_s and say("sun_done", "Ten minutes of morning light. Done.", cooldown=0):
                    self._note("Morning light goal")
            elif say("outside", "Nice, some time outside.", cooldown=300):
                self._note("Time outside")

        # drinks
        if "drinking_water" in seen and self._ready("water_log", 30):
            s.water_ml += 250
            self._last_water = time.monotonic()
            litres = s.water_ml / 1000
            if s.water_ml >= self.WATER_GOAL and s.water_ml - 250 < self.WATER_GOAL:
                out.append(Nudge("That's your two liters for today. Nice work.", habit="water"))
            else:
                out.append(Nudge(f"Water logged. {litres:.2g} of 2 liters.", habit="water"))
            self._note("Water +250 ml")
        for drink, word in (("energy_drink", "the energy drink"), ("coffee", "the coffee")):
            if drink in seen and self._ready("caffeine_late" if late_caffeine else "caffeine", 25):
                if late_caffeine:
                    s.caffeine_late += 1
                    out.append(Nudge(f"Put {word} back. Caffeine this late can cut into your deep sleep.", True, "caffeine"))
                    self._note(f"Late caffeine ({drink.replace('_', ' ')})")
                else:
                    s.caffeine += 1
                    out.append(Nudge("Caffeine logged. Last call is 2 PM.", habit="caffeine"))
                    self._note("Caffeine before 2 PM")
                break
        if "alcohol" in seen and self._ready("alcohol", 60):
            if h >= 18 or h < 5:
                s.alcohol_late += 1
                out.append(Nudge("Heads up: alcohol close to bed makes your sleep lighter.", True, "alcohol"))
                self._note("Alcohol in the evening")

        # screens
        if self._streak.get("phone_scrolling", 0) >= self.CONFIRM:
            if self.night or obs.get("dark"):
                if say("scroll", "Phone down. A bright screen this late pushes back your sleep.", True):
                    s.night_screen += 1
                    self._note("Screen at night")
            elif say("scroll", "Stop scrolling. Go for a walk instead.", True, cooldown=40):
                s.scroll_nudges += 1
                self._note("Scrolling nudge")
        elif self.night and self._streak.get("screen", 0) >= self.CONFIRM:
            if say("screen_night", "It's late. Time to put the screen away.", True, cooldown=40):
                s.night_screen += 1
                self._note("Screen at night")

        # bad habits: nicotine, scrolling time, sugary drinks, betting
        if "phone_scrolling" in seen:
            s.scroll_s += dt
        nic = next((k for k in ("vape", "cigarette", "nicotine_pouch") if self._streak.get(k, 0) >= self.CONFIRM), None)
        if nic and self._ready("nicotine", 60):
            s.nicotine += 1
            s.nicotine_last = self.clock.label()
            if s.nicotine == 1:
                text = "Craving? Try ten slow breaths first. Cravings usually pass in a few minutes."
            else:
                text = f"That's {s.nicotine} today. Try a glass of water or a short walk first."
            if "quitline" not in self._said_once:
                self._said_once.add("quitline")
                text += " Free help to quit: 1-800-QUIT-NOW."
            out.append(Nudge(text, True, "nicotine"))
            self._note(f"Nicotine ({nic.replace('_', ' ')})")
        if "soda" in seen and self._ready("soda", 30):
            s.soda += 1
            out.append(Nudge("Sugary drink. Water or sparkling water is the easy swap.", habit="sugar"))
            self._note("Sugary drink")
        if self._streak.get("betting", 0) >= self.CONFIRM and self._ready("betting", 60):
            s.betting += 1
            out.append(Nudge("Betting app open. Take a minute before you place that bet.", True, "betting"))
            self._note("Betting app")

        # food
        if "fruit_veg" in seen and self._ready("veg", 30):
            s.veg += 1
            out.append(Nudge("Nice. A serving of fruit or veg logged.", habit="veg"))
            self._note("Fruit or veg")
        elif "junk_food" in seen and self._ready("junk", 30):
            s.junk += 1
            out.append(Nudge("Try swapping that for fruit or nuts next time.", habit="junk"))
            self._note("Junk food")
        if ("eating" in seen or "junk_food" in seen) and (h >= 21 or h < 5) and self._ready("late_meal", 120):
            s.late_meal += 1
            out.append(Nudge("Late meal. Try to finish eating a few hours before bed.", True, "late_meal"))
            self._note("Late meal")

        # routines
        if "brushing_teeth" in seen and self._ready("teeth", 60):
            if h < 12:
                s.teeth_am = True
            else:
                s.teeth_pm = True
            out.append(Nudge("Brushing logged. Two full minutes.", habit="teeth"))
            self._note("Brushed teeth")
        if "sunscreen" in seen and self._ready("sunscreen", 120):
            s.sunscreen = True
            out.append(Nudge("Sunscreen on. Nice.", habit="sunscreen"))
            self._note("Sunscreen")
        if "pills" in seen and self._ready("vitamins", 120):
            s.vitamins = True
            out.append(Nudge("Vitamins logged.", habit="vitamins"))
            self._note("Vitamins")
        if "stairs" in seen and self._ready("stairs", 60):
            s.stairs += 1
            out.append(Nudge("Took the stairs. Your heart likes that.", habit="stairs"))
            self._note("Stairs")
        if "book" in seen and self._ready("book", 300):
            s.book = True
            text = "Reading before bed. Good wind-down." if (h >= 20 or h < 5) else "Reading logged."
            out.append(Nudge(text, habit="book"))
            self._note("Reading")
        if out:
            self.save()
        return out

    # ---- reminders that come from the clock, not the camera ----
    def tick(self) -> list[Nudge]:
        out, h, s = [], self.clock.hour(), self.stats
        if 10 <= h < 11 and s.sun_s == 0 and "sun_remind" not in self._said_once:
            self._said_once.add("sun_remind")
            out.append(Nudge("Get outside for ten minutes of morning light.", habit="sun"))
        if 9 <= h < 21 and time.monotonic() - self._last_water > 7200 and self._ready("water_remind", 7200):
            out.append(Nudge("Time for some water.", habit="water"))
        if self.BEDTIME <= h < self.BEDTIME + 0.5 and "bedtime" not in self._said_once:
            self._said_once.add("bedtime")
            out.append(Nudge("It's ten. Start winding down: screens off, lights low.", habit="screens"))
        return out

    def add_reps(self, n: int = 1) -> None:
        self.stats.reps += n
        self.save()

    # ---- the day at a glance ----
    def score(self) -> int:
        s = self.stats
        water = min(1.0, s.water_ml / self.WATER_GOAL) * 20
        sun = min(1.0, s.sun_s / self.SUN_GOAL) * 15
        caffeine = 0 if s.caffeine_late else 15
        night = max(0, 15 - 5 * (s.night_screen + s.alcohol_late))
        move = min(1.0, s.reps / 30 + s.outside_s / 1200 + s.stairs * 0.2) * 20
        food = max(0, min(15, 5 + s.veg * 5 - s.junk * 3))
        slips = min(24, 8 * s.nicotine) + min(10, 5 * s.betting) + min(9, 3 * s.soda) + min(6, 2 * s.scroll_nudges)
        return max(0, int(round(water + sun + caffeine + night + move + food - slips)))

    def status(self, hid: str) -> tuple[str, str]:
        """(state, detail) for the Today checklist. state: done / warn / todo."""
        s = self.stats
        if hid == "sun":
            got = f"{int(s.sun_s)} s" if 0 < s.sun_s < 60 else f"{int(s.sun_s // 60)}"
            return ("done" if s.sun_s >= self.SUN_GOAL else "todo"), f"{got} of 10 min"
        if hid == "teeth_am":
            return ("done" if s.teeth_am else "todo"), ""
        if hid == "teeth_pm":
            return ("done" if s.teeth_pm else "todo"), ""
        if hid == "sunscreen":
            return ("done" if s.sunscreen else "todo"), ""
        if hid == "vitamins":
            return ("done" if s.vitamins else "todo"), ""
        if hid == "water":
            return ("done" if s.water_ml >= self.WATER_GOAL else "todo"), f"{s.water_ml / 1000:.2g} of 2 L"
        if hid == "caffeine":
            if s.caffeine_late:
                return "warn", f"{s.caffeine_late} late"
            return ("done" if s.caffeine else "todo"), (f"{s.caffeine} cup" + ("s" if s.caffeine != 1 else "")) if s.caffeine else ""
        if hid == "veg":
            return ("done" if s.veg >= 3 else "todo"), f"{s.veg} of 3" + (f", {s.junk} junk" if s.junk else "")
        if hid == "move":
            mins = int(s.outside_s // 60)
            bits = [f"{s.reps} reps"] if s.reps else []
            if mins:
                bits.append(f"{mins} min out")
            if s.stairs:
                bits.append(f"{s.stairs} stairs")
            return ("done" if (s.reps >= 20 or mins >= 20) else "todo"), ", ".join(bits)
        if hid == "screens":
            return ("warn", f"{s.night_screen} nudge" + ("s" if s.night_screen > 1 else "")) if s.night_screen else ("todo", "")
        if hid == "no_late":
            n = s.caffeine_late + s.alcohol_late
            return ("warn", f"{n} slip" + ("s" if n > 1 else "")) if n else ("todo", "")
        if hid == "wind_down":
            return ("done" if s.book else "todo"), ""
        if hid == "nicotine":
            return ("warn", f"{s.nicotine} today, last {s.nicotine_last}") if s.nicotine else ("done", "Free today")
        if hid == "scroll":
            mins = int(s.scroll_s // 60)
            n = s.scroll_nudges + s.night_screen
            if n:
                return "warn", f"{n} nudge" + ("s" if n > 1 else "") + (f", {mins} min" if mins else "")
            return "done", "None today"
        if hid == "sugar":
            return ("warn", f"{s.soda} today") if s.soda else ("done", "None today")
        if hid == "betting":
            return ("warn", f"{s.betting} today") if s.betting else ("done", "None today")
        return "todo", ""
