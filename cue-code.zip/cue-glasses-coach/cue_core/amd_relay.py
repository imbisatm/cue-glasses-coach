"""Reach the vision model on the AMD notebook through the notebook itself.

The AMD machine can't open a public address (its internet goes through a filter), but your
laptop CAN reach its Jupyter notebook. So Cue starts its own small Python session (a "kernel")
inside the notebook and, for every frame, asks that session to call the model at localhost:8000
on the AMD GPU and send the answer back. Same answers as a direct connection, plus a little delay.

Needs: the notebook's web address (any page of it) and its key (token).
"""

from __future__ import annotations

import datetime
import json
import threading
import time
import uuid
from urllib.parse import urlsplit

from cue_core.vision import VisionClient

SETUP = r'''
import json, urllib.request, urllib.error
def _cue_call(path, body=None, key=%(key)r):
    req = urllib.request.Request("http://localhost:%(port)d/v1" + path,
                                 data=None if body is None else body.encode(),
                                 headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
    try:
        return urllib.request.urlopen(req, timeout=90).read().decode()
    except urllib.error.HTTPError as e:
        return json.dumps({"error": "%%s %%s" %% (e.code, e.read().decode()[:300])})
    except Exception as e:
        return json.dumps({"error": str(e)[:300]})
print("ready")
'''


def notebook_base(address: str) -> str:
    """https://host/instances/<id>/lab/tree/x.ipynb -> https://host/instances/<id>/"""
    address = address.strip().split("?")[0].split("#")[0]
    if "://" not in address:
        address = "https://" + address
    parts = urlsplit(address)
    path = parts.path
    for marker in ("/lab", "/tree", "/notebooks", "/api/", "/edit", "/terminals"):
        i = path.find(marker)
        if i != -1:
            path = path[:i]
            break
    return f"{parts.scheme}://{parts.netloc}{path.rstrip('/')}/"


class NotebookRelayClient(VisionClient):
    """Drop-in VisionClient that talks to the model through the AMD Jupyter notebook."""

    def __init__(self, notebook_address: str, jupyter_token: str, api_key: str = "", model: str = "cue-vision",
                 timeout: float = 60.0, port: int = 8000, cookie: str = ""):
        import requests

        self.base_url = notebook_base(notebook_address)   # shown in tests / debug
        self.model = model
        self.timeout = timeout
        self.api_key = api_key
        self.port = port
        self.token = jupyter_token.strip()
        self.http = requests.Session()
        self.http.headers["Authorization"] = f"token {self.token}"
        # the AMD site's own login: the browser's cookie header for jupyter.anruicloud.com
        self.cookie = cookie.strip().removeprefix("cookie:").removeprefix("Cookie:").strip()
        if self.cookie:
            self.http.headers["Cookie"] = self.cookie
        self.http.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Cue"
        self.last_latency = 0.0
        self._ws = None
        self._kernel = None
        self._session = uuid.uuid4().hex
        self._lock = threading.Lock()

    # ---- notebook plumbing ----
    def check_access(self) -> str:
        r = self.http.get(self.base_url + "api/status", timeout=20)
        if r.status_code != 200 or "json" not in r.headers.get("Content-Type", ""):
            raise RuntimeError(f"notebook said {r.status_code}: {r.text[:200]}")
        return r.text

    def _connect(self) -> None:
        import websocket  # pip install websocket-client

        if self._kernel is None:
            r = self.http.post(self.base_url + "api/kernels", json={}, timeout=30)  # default kernel
            if r.status_code >= 400:
                raise RuntimeError(f"could not start a notebook session ({r.status_code}): {r.text[:200]}")
            self._kernel = r.json()["id"]
        ws_base = self.base_url.replace("https://", "wss://", 1).replace("http://", "ws://", 1)
        url = f"{ws_base}api/kernels/{self._kernel}/channels?session_id={self._session}&token={self.token}"
        origin = self.base_url.split("/instances/")[0] if "/instances/" in self.base_url else self.base_url.rstrip("/")
        self._ws = websocket.create_connection(url, timeout=self.timeout, origin=origin, cookie=self.cookie or None,
                                               header=[f"Authorization: token {self.token}"])
        out = self._run(SETUP % {"key": self.api_key, "port": self.port})
        if "ready" not in out:
            raise RuntimeError(f"notebook session did not start: {out[:200]}")

    def _run(self, code: str) -> str:
        msg_id = uuid.uuid4().hex
        msg = {
            "header": {"msg_id": msg_id, "username": "cue", "session": self._session, "msg_type": "execute_request",
                       "version": "5.3", "date": datetime.datetime.now(datetime.timezone.utc).isoformat()},
            "parent_header": {}, "metadata": {}, "channel": "shell", "buffers": [],
            "content": {"code": code, "silent": False, "store_history": False, "user_expressions": {},
                        "allow_stdin": False, "stop_on_error": True},
        }
        self._ws.send(json.dumps(msg))
        out, deadline = [], time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            m = json.loads(self._ws.recv())
            if m.get("parent_header", {}).get("msg_id") != msg_id:
                continue
            kind = m.get("msg_type") or m.get("header", {}).get("msg_type")
            if kind == "stream":
                out.append(m["content"].get("text", ""))
            elif kind == "error":
                raise RuntimeError(f"notebook error: {m['content'].get('ename')}: {m['content'].get('evalue')}")
            elif kind == "status" and m["content"].get("execution_state") == "idle":
                return "".join(out)
        raise TimeoutError("notebook took too long to answer")

    def _call(self, path: str, body: dict | None = None) -> dict:
        arg = "None" if body is None else repr(json.dumps(body))
        code = f"print(_cue_call({path!r}, {arg}))"
        with self._lock:
            for attempt in (1, 2):
                try:
                    if self._ws is None:
                        self._connect()
                    text = self._run(code)
                    break
                except Exception:
                    # session dropped (idle timeout, network blip): start fresh once
                    try:
                        self._ws and self._ws.close()
                    except Exception:
                        pass
                    self._ws = None
                    if attempt == 2:
                        self._kernel = None
                        raise
        data = json.loads(text.strip().splitlines()[-1])
        if "error" in data and "choices" not in data and "data" not in data:
            raise RuntimeError(f"Vision model error (AMD): {data['error']}")
        return data

    # ---- same interface as VisionClient ----
    def list_models(self) -> list[str]:
        return [m["id"] for m in self._call("/models").get("data", [])]

    def chat(self, content, max_tokens: int = 200, system: str | None = None) -> str:
        messages = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": content}]
        body = {"model": self.model, "messages": messages, "max_tokens": max_tokens, "temperature": 0}
        start = time.monotonic()
        data = self._call("/chat/completions", body)
        self.last_latency = time.monotonic() - start
        return data["choices"][0]["message"]["content"].strip()
