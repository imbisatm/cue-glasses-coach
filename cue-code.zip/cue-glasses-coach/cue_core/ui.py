"""Cue's app screen.

Design idea: a camera viewfinder with live captions.
- The glasses video is the hero, framed by viewfinder corner marks.
- Whatever Cue says appears as a caption over the video (what the wearer hears).
- The right rail is quiet instrumentation: thin type, hairline dividers, no boxes.
- Colour only means state: blue = live / on track, orange = fix this now.

bridge.py builds a `state` dict every frame and calls CueUI.render(state) -> BGR image.
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from cue_core.catalog import CATEGORIES

W, H = 1280, 720

GROUND = (20, 21, 23)       # app background
LENS = (11, 12, 13)         # behind the video
INK = (236, 235, 231)       # primary text
SMOKE = (138, 141, 146)     # secondary text
ASH = (78, 81, 86)          # inactive / tertiary
RULE = (38, 40, 43)         # hairlines
HOVER_BG = (29, 31, 34)     # row under the mouse
SIGNAL = (142, 184, 255)    # live / on track
FIX = (255, 122, 80)        # needs fixing now

FONT_DIR = Path(__file__).resolve().parent.parent / "fonts"
FONTS = {
    "light": ["Barlow_300Light.ttf", "C:/Windows/Fonts/segoeuil.ttf"],
    "regular": ["Barlow_400Regular.ttf", "C:/Windows/Fonts/segoeui.ttf"],
    "medium": ["Barlow_500Medium.ttf", "C:/Windows/Fonts/seguisb.ttf"],
    "semibold": ["Barlow_600SemiBold.ttf", "C:/Windows/Fonts/seguisb.ttf"],
    "num": ["BarlowCondensed_200ExtraLight.ttf", "C:/Windows/Fonts/segoeuil.ttf"],
    "numlight": ["BarlowCondensed_300Light.ttf", "C:/Windows/Fonts/segoeuil.ttf"],
}
FALLBACK = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "DejaVuSans.ttf"]

TOP = 56                         # top bar height
VF = (24, 72, 840, 624)          # viewfinder x, y, w, h
RX, RW = 896, 360                # right rail


class CueUI:
    def __init__(self):
        self._fonts: dict = {}
        self.hits: list = []   # clickable areas from the last render: (x0, y0, x1, y1, id)

    # ---------- small helpers ----------
    def f(self, size: int, kind: str = "regular"):
        key = (size, kind)
        if key not in self._fonts:
            font = None
            for name in FONTS[kind] + FALLBACK:
                path = Path(name) if Path(name).is_absolute() else FONT_DIR / name
                try:
                    font = ImageFont.truetype(str(path) if path.exists() else name, size)
                    break
                except OSError:
                    continue
            if font is None:
                font = ImageFont.load_default()
            self._fonts[key] = font
        return self._fonts[key]

    @staticmethod
    def _fit(d, text: str, font, max_w: int) -> str:
        if d.textlength(text, font=font) <= max_w:
            return text
        while text and d.textlength(text + "...", font=font) > max_w:
            text = text[:-1]
        return text.rstrip() + "..."

    def _wrap(self, d, text: str, font, max_w: int, max_lines: int = 2) -> list:
        lines, cur = [], ""
        for word in text.split():
            trial = f"{cur} {word}".strip()
            if d.textlength(trial, font=font) <= max_w or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = self._fit(d, lines[-1] + " ...", font, max_w)
        return lines

    def _rule(self, d, y, x0=RX, x1=RX + RW):
        d.line([(x0, y), (x1, y)], fill=RULE, width=1)

    def _row(self, d, y, label, value, value_font, value_color=INK):
        d.text((RX, y), label, font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        d.text((RX + RW, y), value, font=value_font, fill=value_color, anchor="rs")

    # ---------- main ----------
    def render(self, s: dict) -> np.ndarray:
        img = Image.new("RGB", (W, H), GROUND)
        d = ImageDraw.Draw(img)
        self.hits = []
        self._hover = s.get("hover")
        self._top_bar(d, s)
        mode = s.get("mode", "home")
        if mode == "home":
            self._home(img, d, s)
            return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)
        self._viewfinder(img, d, s)
        if mode == "gym":
            self._gym(d, s.get("gym", {}))
            if s.get("gym", {}).get("summary"):
                self._set_summary(img, d, s["gym"]["summary"], s.get("gym", {}).get("goal", 10), s.get("summary_age", 9))
        elif mode == "coach":
            self._coach(d, s.get("day", {}))
        elif mode == "kitchen":
            self._kitchen(d, s.get("kitchen", {}))
            if s.get("kitchen", {}).get("summary"):
                self._recipe_summary(img, d, s["kitchen"]["summary"], s.get("summary_age", 9))
        else:
            self._welcome(d)
        foot = s.get("debug_text") if s.get("debug") else f"Voice to {s.get('voice_route', 'laptop speakers')}"
        d.text((RX, 706), self._fit(d, foot, self.f(13), RW), font=self.f(13), fill=ASH, anchor="ls")
        return cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR)

    def _top_bar(self, d, s):
        d.text((24, 37), "Cue", font=self.f(26, "semibold"), fill=INK, anchor="ls")
        if s.get("version"):
            d.text((24, 52), f"update {s['version']}", font=self.f(10), fill=ASH, anchor="ls")
        x = 112
        tabs = [("home", "Today")]
        if s.get("skill_name"):
            tabs.append(("session", s["skill_name"]))
        for key, label in tabs:
            active = (s.get("mode") == "home") == (key == "home")
            font = self.f(16, "medium")
            d.text((x, 36), label, font=font, fill=INK if active else SMOKE, anchor="ls")
            tw = int(d.textlength(label, font=font))
            if active:
                d.line([(x, TOP - 1), (x + tw, TOP - 1)], fill=SIGNAL, width=2)
            self.hits.append((x - 10, 0, x + tw + 10, TOP, "tab:" + key))
            x += tw + 30
        lights = [("Glasses", "ok" if s.get("glasses_live") else "bad")]
        clip = s.get("clip")
        if clip is not None:
            lights.append(("Clip", "ok" if clip.get("connected") else "bad"))
        amd = s.get("amd", "off")
        lights.append((s.get("vision_label", "Vision"), {"ready": "ok", "thinking": "ok", "off": "off"}.get(amd, "bad")))
        x = W - 24
        for label, st in reversed(lights):
            font = self.f(14, "medium")
            tw = int(d.textlength(label, font=font))
            d.text((x, 36), label, font=font, fill=INK if st == "ok" else SMOKE, anchor="rs")
            col = {"ok": SIGNAL, "bad": FIX, "off": ASH}[st]
            cx = x - tw - 11
            d.ellipse([cx - 3, 28, cx + 3, 34], fill=col)
            x = cx - 22
        d.line([(0, TOP), (W, TOP)], fill=RULE, width=1)

    def _viewfinder(self, img, d, s):
        vx, vy, vw, vh = VF
        d.rectangle([vx, vy, vx + vw, vy + vh], fill=LENS)
        frame = s.get("frame")
        if frame is None:
            d.text((vx + vw // 2, vy + vh // 2 - 6), "Waiting for the glasses", font=self.f(24, "medium"), fill=INK, anchor="ms")
            d.text((vx + vw // 2, vy + vh // 2 + 24), "Start the call, then press C and drag around the video.",
                   font=self.f(16), fill=SMOKE, anchor="ms")
            self._brackets(d, vx + 40, vy + 40, vw - 80, vh - 80, ASH, 2)
            return
        fh, fw = frame.shape[:2]
        scale = min(vw / fw, vh / fh)
        nw, nh = max(1, int(fw * scale)), max(1, int(fh * scale))
        small = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
        px, py = vx + (vw - nw) // 2, vy + (vh - nh) // 2
        img.paste(Image.fromarray(cv2.cvtColor(small, cv2.COLOR_BGR2RGB)), (px, py))
        warn = s.get("warn")
        self._brackets(d, px + 14, py + 14, nw - 28, nh - 28, FIX if warn else INK, 3 if warn else 2)
        for (x, y, text, bad) in s.get("labels", []):
            lx, ly = px + int(x * scale), py + int(y * scale) + 18
            font = self.f(15, "medium")
            tw = int(d.textlength(text, font=font))
            d.rectangle([lx - tw // 2 - 8, ly, lx + tw // 2 + 8, ly + 24], fill=FIX if bad else LENS)
            d.text((lx, ly + 17), text, font=font, fill=GROUND if bad else INK, anchor="ms")
        status = s.get("status")
        if status:
            font = self.f(15, "medium")
            text = self._fit(d, status, font, nw - 120)
            self._shade(img, px, py, nw, 40, 150)
            d.text((px + nw // 2, py + 26), text, font=font, fill=INK, anchor="ms")
        said, age = s.get("last_voice"), s.get("voice_age", 99.0)
        covered = (s.get("gym") or {}).get("summary") or (s.get("kitchen") or {}).get("summary")
        if said and age < 10.0 and not covered:
            font = self.f(26, "medium")
            lines = self._wrap(d, said, font, nw - 96, 3)
            band = 34 + 34 * len(lines)
            self._shade(img, px, py + nh - band, nw, band, 165)
            col = FIX if s.get("voice_warn") else INK
            for i, line in enumerate(lines):
                d.text((px + nw // 2, py + nh - band + 44 + i * 34), line, font=font, fill=col, anchor="ms")

    @staticmethod
    def _shade(img, x, y, w, h, alpha):
        x, y, w, h = int(x), int(y), int(w), int(h)
        if w <= 0 or h <= 0:
            return
        img.paste(Image.new("RGB", (w, h), (0, 0, 0)), (x, y), Image.new("L", (w, h), alpha))

    @staticmethod
    def _brackets(d, x, y, w, h, color, width):
        L = 26
        for cx, cy, dx, dy in ((x, y, 1, 1), (x + w, y, -1, 1), (x, y + h, 1, -1), (x + w, y + h, -1, -1)):
            d.line([(cx, cy + dy * L), (cx, cy), (cx + dx * L, cy)], fill=color, width=width)

    # ---------- rail: gym ----------
    def _gym(self, d, g):
        goal, reps = g.get("goal", 10), g.get("reps", 0)
        phase = g.get("phase", "Ready")
        d.text((RX, 100), f"Set {g.get('set_no', 1)}", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        d.text((RX + RW, 104), phase, font=self.f(26, "medium"), fill=SMOKE if phase == "Ready" else SIGNAL, anchor="rs")
        # rep count, with a short "pop" when a rep lands
        pop = max(0.0, 1.0 - g.get("pop", 9.0) / 0.35)
        size = int(150 * (1 + 0.12 * pop))
        num = str(reps)
        d.text((RX - 4, 252), num, font=self.f(size, "num"), fill=SIGNAL if pop > 0.05 else INK, anchor="ls")
        nw = d.textlength(num, font=self.f(size, "num"))
        d.text((RX + nw + 10, 252), f"/ {goal}", font=self.f(40, "numlight"), fill=ASH, anchor="ls")
        src = "Cue Clip" if g.get("source") == "clip" else "Glasses camera"
        d.text((RX + RW, 252), src, font=self.f(14), fill=ASH, anchor="rs")
        # one segment per rep in the set: blue = on tempo, orange = rushed
        hist = g.get("history", [])
        seg_gap = 6
        seg_w = (RW - seg_gap * (goal - 1)) / max(1, goal)
        for i in range(goal):
            x0 = RX + i * (seg_w + seg_gap)
            col = (SIGNAL if hist[i] else FIX) if i < len(hist) else RULE
            d.rectangle([x0, 272, x0 + seg_w, 279], fill=col)
        streak = g.get("streak", 0)
        if streak >= 2:
            d.text((RX, 304), f"{streak} in a row on tempo", font=self.f(15, "medium"), fill=SIGNAL, anchor="ls")
        elif hist and not hist[-1]:
            d.text((RX, 304), "Last one was rushed. Reset and go again.", font=self.f(15), fill=FIX, anchor="ls")
        self._rule(d, 322)
        last = g.get("last")
        verdict, vcol = ("", SMOKE)
        if last:
            verdict, vcol = ("On tempo", SIGNAL) if last.get("good") else (last.get("cue") or "Check your tempo", FIX)
        self._row(d, 352, "Last rep", verdict, self.f(15, "medium"), vcol)
        tgt = g.get("target", (1.0, 1.0))
        if last:
            rows = [(last.get("away_word", "down"), last.get("away", 0.0), tgt[0]),
                    (last.get("back_word", "up"), last.get("back", 0.0), tgt[1])]
            for i, (word, val, t) in enumerate(rows):
                yy = 390 + i * 66
                live = phase.lower() == word.lower()
                d.text((RX, yy), word.capitalize(), font=self.f(18, "medium"), fill=SIGNAL if live else INK, anchor="ls")
                d.text((RX + RW, yy + 2), f"{val:.1f} s", font=self.f(28, "numlight"), fill=INK, anchor="rs")
                full = max(2.5, t * 2.2)
                bx0, bx1, by = RX, RX + RW, yy + 14
                d.line([(bx0, by), (bx1, by)], fill=RULE, width=3)
                ok = val >= t * 0.6
                d.line([(bx0, by), (bx0 + (bx1 - bx0) * min(1.0, val / full), by)], fill=SIGNAL if ok else FIX, width=3)
                tx = bx0 + (bx1 - bx0) * min(1.0, t / full)
                d.line([(tx, by - 6), (tx, by + 6)], fill=INK, width=2)
                d.text((RX, by + 22), f"target {t:.1f} s", font=self.f(13), fill=ASH, anchor="ls")
        elif g.get("source") == "clip" and not g.get("clip_ok"):
            d.text((RX, 380), "Clip not connected", font=self.f(18, "semibold"), fill=FIX, anchor="ls")
            why = (g.get("clip_status") or "").replace("Arduino clip not found: ", "")
            tip = "Plug in the clip's USB cable and close the Arduino app. Cue keeps looking by itself."
            for j, line in enumerate(self._wrap(d, tip, self.f(15), RW, 2)):
                d.text((RX, 404 + j * 20), line, font=self.f(15), fill=INK, anchor="ls")
            for j, line in enumerate(self._wrap(d, why[:1].upper() + why[1:], self.f(13), RW, 2)):
                d.text((RX, 446 + j * 17), line, font=self.f(13), fill=SMOKE, anchor="ls")
            self._actions(d, RX, 500, [("B", "Check clip", "action:clip")], self._hover)
        else:
            d.text((RX, 392), "Hold still for a second, then start.", font=self.f(17), fill=SMOKE, anchor="ls")
            d.text((RX, 418), "Every rep is timed, both ways.", font=self.f(17), fill=SMOKE, anchor="ls")
        self._rule(d, 516)
        weight = g.get("weight")
        if weight:
            self._row(d, 550, "Weight", weight, self.f(32, "numlight"))
        else:
            self._row(d, 548, "Weight", "Hold it up to the glasses", self.f(16), ASH)
        self._rule(d, 570)
        d.text((RX, 596), "Motion", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        vals = g.get("chart") or []
        if len(vals) > 1:
            v = np.array(vals[-150:], dtype=float)
            thr = max(g.get("threshold", 1.0), 1e-3)
            span = max(np.abs(v).max(), thr * 2)
            y0, y1 = 610, 668
            mid = (y0 + y1) / 2
            ys = mid - v / span * (y1 - y0) / 2
            xs = np.linspace(RX, RX + RW, len(v))
            d.line(list(zip(xs.tolist(), ys.tolist())), fill=SIGNAL, width=2, joint="curve")

    # ---------- the one big moment: a finished set / recipe ----------
    def _overlay(self, img, d, age):
        vx, vy, vw, vh = VF
        alpha = int(min(1.0, age / 0.35) * 225)
        self._shade(img, vx, vy, vw + 1, vh + 1, alpha)
        return vx, vy, vw, vh, min(1.0, age / 0.35)

    def _stat(self, d, x, y, value, label):
        d.text((x, y), value, font=self.f(58, "numlight"), fill=INK, anchor="ls")
        d.text((x, y + 26), label, font=self.f(15, "medium"), fill=SMOKE, anchor="ls")

    def _actions(self, d, x, y, items, hover=None):
        """Clickable buttons: (key hint, label, click id). The first one is the main action."""
        for i, (key, label, hid) in enumerate(items):
            font, kfont = self.f(18, "semibold" if i == 0 else "medium"), self.f(12, "semibold")
            lw = int(d.textlength(label, font=font))
            kw = int(d.textlength(key, font=kfont)) + 14
            bw = 24 + lw + 12 + kw + 14
            hov = hover == hid
            if i == 0:
                d.rounded_rectangle([x, y - 30, x + bw, y + 12], radius=8, fill=SIGNAL if hov else (122, 164, 236))
                fg = GROUND
            else:
                d.rounded_rectangle([x, y - 30, x + bw, y + 12], radius=8, outline=SIGNAL if hov else ASH, width=1,
                                    fill=HOVER_BG if hov else None)
                fg = INK
            d.text((x + 24, y - 2), label, font=font, fill=fg, anchor="ls")
            kx = x + 24 + lw + 12
            d.rounded_rectangle([kx, y - 19, kx + kw, y + 1], radius=4, outline=fg, width=1)
            d.text((kx + kw / 2, y - 4), key, font=kfont, fill=fg, anchor="ms")
            self.hits.append((x, y - 30, x + bw, y + 12, hid))
            x += bw + 16

    def _set_summary(self, img, d, sm, goal, age):
        vx, vy, vw, vh, k = self._overlay(img, d, age)
        if k < 0.6:
            return
        x = vx + 56
        d.text((x, vy + 120), "Set complete", font=self.f(52, "semibold"), fill=INK, anchor="ls")
        pct = int(round(100 * sm["good"] / max(1, sm["reps"])))
        d.text((x, vy + 158), f"Set {sm['set_no']}, {sm['good']} of {sm['reps']} reps on tempo",
               font=self.f(19), fill=SMOKE, anchor="ls")
        stats = [(str(sm["reps"]), "Reps"), (f"{pct}%", "On tempo"),
                 (f"{sm['avg_away']:.1f}s", "Average up"), (f"{sm['avg_back']:.1f}s", "Average down")]
        if sm.get("weight"):
            stats.append((sm["weight"], "Weight"))
        col_w = (vw - 112) // len(stats)
        for i, (v, label) in enumerate(stats):
            self._stat(d, x + i * col_w, vy + 290, v, label)
        hist = sm.get("history", [])
        seg_gap = 8
        seg_w = (vw - 112 - seg_gap * (goal - 1)) / max(1, goal)
        for i in range(goal):
            x0 = x + i * (seg_w + seg_gap)
            col = (SIGNAL if hist[i] else FIX) if i < len(hist) else RULE
            d.rectangle([x0, vy + 372, x0 + seg_w, vy + 382], fill=col)
        verdict = ("Clean set. Add weight next time?" if pct >= 90 else
                   "Solid. Slow the rushed ones down." if pct >= 60 else
                   "Too fast overall. Count two seconds on each way.")
        d.text((x, vy + 430), verdict, font=self.f(22, "medium"), fill=SIGNAL if pct >= 60 else FIX, anchor="ls")
        self._actions(d, x, vy + vh - 50, [("Enter", "Next set", "action:next"), ("Esc", "Today", "tab:home")], self._hover)

    def _recipe_summary(self, img, d, sm, age):
        vx, vy, vw, vh, k = self._overlay(img, d, age)
        if k < 0.6:
            return
        x = vx + 56
        d.text((x, vy + 120), "Recipe done", font=self.f(52, "semibold"), fill=INK, anchor="ls")
        d.text((x, vy + 158), sm.get("name", ""), font=self.f(19), fill=SMOKE, anchor="ls")
        secs = sm.get("seconds", 0)
        took = f"{secs:.0f}s" if secs < 90 else f"{secs / 60:.1f}m"
        stats = [(took, "Time"), (str(sm.get("steps", 0)), "Steps checked"), (str(sm.get("warnings", 0)), "Grip fixes")]
        col_w = (vw - 112) // len(stats)
        for i, (v, label) in enumerate(stats):
            self._stat(d, x + i * col_w, vy + 290, v, label)
        w = sm.get("warnings", 0)
        verdict = "Perfect knife grip the whole time." if w == 0 else (
            "One grip slip. Keep those fingertips tucked." if w == 1 else f"{w} grip slips. Slow down when you cut.")
        d.text((x, vy + 380), verdict, font=self.f(22, "medium"), fill=SIGNAL if w == 0 else FIX, anchor="ls")
        self._actions(d, x, vy + vh - 50, [("Enter", "Cook again", "action:again"), ("Esc", "Today", "tab:home")], self._hover)

    # ---------- rail: kitchen ----------
    def _kitchen(self, d, k):
        steps = k.get("steps", [])
        idx, done_all = k.get("index", 0), k.get("finished", False)
        prog = "Done" if done_all else (f"Step {idx + 1} of {len(steps)}" if steps else "")
        self._row(d, 100, "Recipe", prog, self.f(15, "medium"), SIGNAL if done_all else SMOKE)
        d.text((RX, 140), self._fit(d, k.get("skill", "Kitchen"), self.f(30, "semibold"), RW),
               font=self.f(30, "semibold"), fill=INK, anchor="ls")
        y = 182
        nodes = []
        for i, text in enumerate(steps):
            done, cur = done_all or i < idx, (not done_all and i == idx)
            font = self.f(18, "medium" if cur else "regular")
            lines = self._wrap(d, text, font, RW - 34, 2)
            nodes.append((y, done, cur))
            for j, line in enumerate(lines):
                d.text((RX + 30, y + 6 + j * 24), line, font=font, fill=INK if cur else SMOKE, anchor="ls")
            y += 24 * len(lines) + 22
        for i, (ny, done, cur) in enumerate(nodes):
            cx, cy = RX + 7, ny
            if i + 1 < len(nodes):
                d.line([(cx, cy + 9), (cx, nodes[i + 1][0] - 9)], fill=SIGNAL if done else RULE, width=2)
            if done:
                d.ellipse([cx - 6, cy - 6, cx + 6, cy + 6], fill=SIGNAL)
            elif cur:
                d.ellipse([cx - 7, cy - 7, cx + 7, cy + 7], outline=SIGNAL, width=2)
                d.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], fill=SIGNAL)
            else:
                d.ellipse([cx - 6, cy - 6, cx + 6, cy + 6], outline=ASH, width=2)
        y = max(y, 330)
        self._rule(d, y)
        y += 40
        if k.get("claw_active"):
            state = k.get("claw")
            if state is None:
                self._row(d, y, "Grip", "No hands in view", self.f(17), ASH)
            elif state:
                self._row(d, y, "Grip", "Flat. Curl your fingertips", self.f(19, "medium"), FIX)
            else:
                self._row(d, y, "Grip", "Claw", self.f(19, "medium"), SIGNAL)
        else:
            self._row(d, y, "Grip", "Checked during cutting", self.f(16), ASH)
        y += 26
        self._rule(d, y)
        y += 40
        d.text((RX, y), "What the glasses see", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        reason = k.get("reason") or "Waiting for the next check."
        for j, line in enumerate(self._wrap(d, reason, self.f(17), RW, 3)):
            d.text((RX, y + 30 + j * 24), line, font=self.f(17), fill=INK if k.get("reason") else ASH, anchor="ls")

    # ---------- home: skill library ----------
    def _home(self, img, d, s):
        day = s.get("day") or {}
        hover = s.get("hover")
        d.text((24, 122), "Today", font=self.f(40, "semibold"), fill=INK, anchor="ls")
        d.text((24, 156), "Cue watches your day through your glasses and coaches you, morning to night.",
               font=self.f(18), fill=SMOKE, anchor="ls")
        x = self._clock_chips(d, 24, 186, day, hover)
        clock_txt = day.get("clock", "") + ("" if day.get("clock_mode", "live") == "live" else "  demo clock")
        d.text((x + 8, 204), clock_txt, font=self.f(14, "medium"), fill=ASH, anchor="ls")
        # primary action
        label, font = "Start all-day coach", self.f(17, "semibold")
        bw = int(d.textlength(label, font=font)) + 112
        hov = hover in ("action:coach", "coach")
        d.rounded_rectangle([24, 232, 24 + bw, 270], radius=7, fill=SIGNAL if hov else (122, 164, 236))
        d.text((44, 257), label, font=font, fill=GROUND, anchor="ls")
        d.rounded_rectangle([24 + bw - 66, 240, 24 + bw - 14, 262], radius=4, outline=GROUND, width=1)
        d.text((24 + bw - 40, 256), "Enter", font=self.f(12, "semibold"), fill=GROUND, anchor="ms")
        self.hits.append((24, 232, 24 + bw, 270, "action:coach"))
        # health score
        score = str(day.get("score", 0))
        d.text((700, 98), "Health score today", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        d.text((694, 214), score, font=self.f(120, "num"), fill=INK, anchor="ls")
        sw = d.textlength(score, font=self.f(120, "num"))
        d.text((700 + sw, 214), "/ 100", font=self.f(32, "numlight"), fill=ASH, anchor="ls")
        d.text((700, 244), "Water, light, caffeine, screens, food, movement and slips", font=self.f(13), fill=ASH, anchor="ls")
        label, font = "Start a new day", self.f(13, "medium")
        bw = int(d.textlength(label, font=font)) + 20
        hov = hover == "action:newday"
        d.rounded_rectangle([700, 256, 700 + bw, 280], radius=12, outline=SIGNAL if hov else ASH, width=1,
                            fill=HOVER_BG if hov else None)
        d.text((700 + bw / 2, 273), label, font=font, fill=INK if hov else SMOKE, anchor="ms")
        self.hits.append((700, 256, 700 + bw, 280, "action:newday"))
        # live glasses thumbnail, top right
        tw_, th_ = 208, 117
        tx, ty = W - 24 - tw_, 72
        d.rectangle([tx, ty, tx + tw_, ty + th_], fill=LENS)
        frame = s.get("frame")
        if frame is not None:
            fh, fw = frame.shape[:2]
            sc = min(tw_ / fw, th_ / fh)
            nw, nh = max(1, int(fw * sc)), max(1, int(fh * sc))
            small = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_AREA)
            img.paste(Image.fromarray(cv2.cvtColor(small, cv2.COLOR_BGR2RGB)), (tx + (tw_ - nw) // 2, ty + (th_ - nh) // 2))
        self._brackets(d, tx + 8, ty + 8, tw_ - 16, th_ - 16, INK if frame is not None else ASH, 2)
        d.text((tx, ty + th_ + 24), "Glasses live" if frame is not None else "Glasses not connected",
               font=self.f(14, "medium"), fill=SMOKE, anchor="ls")
        label = "Choose video"
        font = self.f(14, "medium")
        bw = int(d.textlength(label, font=font)) + 24
        bx0, by0 = tx + tw_ - bw, ty + th_ + 6
        hov = hover == "action:choose"
        d.rounded_rectangle([bx0, by0, bx0 + bw, by0 + 28], radius=5, outline=SIGNAL if hov else ASH, width=1,
                            fill=HOVER_BG if hov else None)
        d.text((bx0 + bw / 2, by0 + 19), label, font=font, fill=INK, anchor="ms")
        self.hits.append((bx0, by0, bx0 + bw, by0 + 28, "action:choose"))
        label = "Test voice in glasses"
        vw = int(d.textlength(label, font=font)) + 24
        vx0, vy0 = tx + tw_ - vw, by0 + 36
        hov = hover == "action:voice"
        d.rounded_rectangle([vx0, vy0, vx0 + vw, vy0 + 28], radius=5, outline=SIGNAL if hov else ASH, width=1,
                            fill=HOVER_BG if hov else None)
        d.text((vx0 + vw / 2, vy0 + 19), label, font=font, fill=INK, anchor="ms")
        self.hits.append((vx0, vy0, vx0 + vw, vy0 + 28, "action:voice"))

        # the day, as a checklist: Morning / Day / Night / Train
        columns = list(day.get("checklist", []))
        columns.append(("Train", None))
        cols, gap, x0, top = len(columns), 32, 24, 334
        cw = (W - 2 * x0 - gap * (cols - 1)) // cols
        for ci, (cat, rows) in enumerate(columns):
            cx = x0 + ci * (cw + gap)
            d.text((cx, top), cat, font=self.f(30, "medium"), fill=INK, anchor="ls")
            if rows is not None and cat == "Break":
                slips = sum(r[2] == "warn" for r in rows)
                d.text((cx + cw, top), f"{slips} slip" + ("s" if slips > 1 else "") if slips else "Clean so far",
                       font=self.f(14, "medium"), fill=FIX if slips else SIGNAL, anchor="rs")
            elif rows is not None:
                done = sum(r[2] == "done" for r in rows)
                d.text((cx + cw, top), f"{done} of {len(rows)}", font=self.f(14, "medium"),
                       fill=SIGNAL if done else ASH, anchor="rs")
            d.line([(cx, top + 16), (cx + cw, top + 16)], fill=RULE, width=1)
            y = top + 34
            if rows is None:  # workouts: live, clickable
                for card in s.get("workouts", []):
                    h = 74
                    if hover == card["id"]:
                        d.rectangle([cx - 8, y - 4, cx + cw + 8, y + h - 8], fill=HOVER_BG)
                    d.line([(cx, y), (cx, y + h - 14)], fill=SIGNAL, width=2)
                    d.text((cx + 14, y + 20), card["name"], font=self.f(21, "medium"), fill=INK, anchor="ls")
                    d.text((cx + 14, y + 44), self._fit(d, card["blurb"], self.f(15), cw - 54), font=self.f(15), fill=SMOKE, anchor="ls")
                    kx = cx + cw - 26
                    d.rounded_rectangle([kx, y + 2, kx + 26, y + 28], radius=4, outline=SIGNAL if hover == card["id"] else ASH, width=1)
                    d.text((kx + 13, y + 21), card["key"], font=self.f(15, "medium"), fill=INK, anchor="ms")
                    self.hits.append((cx - 8, y - 4, cx + cw + 8, y + h - 8, card["id"]))
                    y += h
                reps = (s.get("today") or {}).get("reps", 0)
                d.text((cx, y + 14), f"{reps} reps today" if reps else "No workout yet today",
                       font=self.f(15, "medium"), fill=SIGNAL if reps else ASH, anchor="ls")
                continue
            for hid, name, state, detail in rows:
                col = {"done": SIGNAL, "warn": FIX}.get(state)
                d.text((cx + 22, y + 18), self._fit(d, name, self.f(18, "medium"), cw - 24), font=self.f(18, "medium"),
                       fill=INK if state != "todo" else SMOKE, anchor="ls")
                if detail:
                    d.text((cx + 22, y + 40), self._fit(d, detail, self.f(14), cw - 30), font=self.f(14),
                           fill=col or ASH, anchor="ls")
                cy = y + 12
                if col:
                    d.ellipse([cx, cy - 6, cx + 12, cy + 6], fill=col)
                else:
                    d.ellipse([cx, cy - 6, cx + 12, cy + 6], outline=ASH, width=1)
                y += 62 if detail else 46
        foot = s.get("debug_text") if s.get("debug") else f"Voice to {s.get('voice_route', 'laptop speakers')}"
        d.text((24, H - 20), "Click Start all-day coach, or a workout. Try Morning / Afternoon / Night to see how Cue's advice changes. Test voice checks your glasses.",
               font=self.f(13, "medium"), fill=ASH, anchor="ls")
        d.text((W - 24, H - 20), self._fit(d, foot, self.f(13), 380), font=self.f(13), fill=ASH, anchor="rs")

    def _clock_chips(self, d, x, y, day, hover, size=14):
        """Live / Morning / Afternoon / Night. Click to see how Cue's advice changes with the time."""
        for mode, label in (("live", "Live"), ("morning", "Morning"), ("afternoon", "Afternoon"), ("night", "Night")):
            font = self.f(size, "medium")
            bw = int(d.textlength(label, font=font)) + 22
            on = day.get("clock_mode", "live") == mode
            hov = hover == "clock:" + mode
            d.rounded_rectangle([x, y, x + bw, y + 26], radius=13, outline=SIGNAL if (on or hov) else ASH, width=1,
                                fill=(36, 48, 66) if on else (HOVER_BG if hov else None))
            d.text((x + bw / 2, y + 18), label, font=font, fill=INK if on else SMOKE, anchor="ms")
            self.hits.append((x, y, x + bw, y + 26, "clock:" + mode))
            x += bw + 8
        return x

    # ---------- rail: all-day coach ----------
    SHORT = {"drinking_water": "water", "coffee": "coffee", "energy_drink": "energy drink", "alcohol": "alcohol",
             "phone_scrolling": "scrolling", "screen": "screen", "fruit_veg": "fruit / veg", "junk_food": "junk food",
             "eating": "eating", "brushing_teeth": "brushing", "sunscreen": "sunscreen", "pills": "vitamins",
             "stairs": "stairs", "book": "book", "desk": "desk", "soda": "soda", "vape": "vape",
             "cigarette": "cigarette", "nicotine_pouch": "nicotine pouch", "betting": "betting app"}

    def _coach(self, d, day):
        demo = day.get("clock_mode", "live") != "live"
        self._clock_chips(d, RX, 80, day, self._hover, size=13)
        d.text((RX, 140), "All-day coach" + ("  ·  demo clock" if demo else ""), font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        d.text((RX + RW, 142), day.get("clock", ""), font=self.f(26, "medium"), fill=INK, anchor="rs")
        score = str(day.get("score", 0))
        pop = max(0.0, 1.0 - day.get("score_age", 9.0) / 0.5)
        big = self.f(int(104 * (1 + 0.08 * pop)), "num")
        d.text((RX - 4, 246), score, font=big, fill=SIGNAL if pop > 0.05 else INK, anchor="ls")
        sw = d.textlength(score, font=big)
        d.text((RX + sw + 8, 246), "/ 100", font=self.f(30, "numlight"), fill=ASH, anchor="ls")
        d.text((RX + RW, 246), "Health score", font=self.f(14), fill=ASH, anchor="rs")
        self._rule(d, 266)
        for i, (label, value, state) in enumerate(day.get("rows", [])):
            y = 296 + i * 32
            col = {"done": SIGNAL, "warn": FIX}.get(state, INK)
            d.text((RX, y), label, font=self.f(16, "medium"), fill=SMOKE, anchor="ls")
            d.text((RX + RW, y), value, font=self.f(19, "medium"), fill=col, anchor="rs")
        self._rule(d, 506)
        # --- what the glasses see (or what's wrong) ---
        age = day.get("obs_age", 99.0)
        problem = ""
        if day.get("coach_on"):
            if not day.get("vision_on", True):
                problem = "Vision is off. Run run_setup_vision.bat, then restart Cue."
            elif not day.get("has_video", True):
                problem = "No glasses video. Click Today, then Choose video."
            elif day.get("covered"):
                problem = "The Cue window is covering the glasses video. Drag Cue to the side."
            elif day.get("vision_error"):
                problem = day["vision_error"]
        if problem:
            d.text((RX, 532), "Needs a fix", font=self.f(15, "semibold"), fill=FIX, anchor="ls")
            for j, line in enumerate(self._wrap(d, problem, self.f(17), RW, 2)):
                d.text((RX, 556 + j * 22), line, font=self.f(17), fill=FIX, anchor="ls")
        else:
            when = "" if age > 60 else ("  ·  just now" if age < 3 else f"  ·  {int(age)} s ago")
            head = "What the glasses see" + (when if day.get("coach_on") else "")
            d.text((RX, 532), head, font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
            note = day.get("note") or ("Looking..." if day.get("coach_on") else "Coach paused")
            note = self._fit(d, note[:1].upper() + note[1:], self.f(18), RW)
            d.text((RX, 558), note, font=self.f(18), fill=INK if day.get("note") else ASH, anchor="ls")
            x = RX
            for sid in day.get("seen", [])[:4]:
                word = self.SHORT.get(sid, sid.replace("_", " "))
                font = self.f(13, "medium")
                bw = int(d.textlength(word, font=font)) + 18
                if x + bw > RX + RW:
                    break
                d.rounded_rectangle([x, 570, x + bw, 594], radius=12, outline=SIGNAL, width=1)
                d.text((x + bw / 2, 587), word, font=font, fill=INK, anchor="ms")
                x += bw + 6
        # --- what Cue last said in your ear ---
        self._rule(d, 606)
        said, sage = day.get("said", ""), day.get("said_age", 99.0)
        if day.get("voice_stuck"):
            d.text((RX, 632), "Voice is restarting...", font=self.f(15, "semibold"), fill=FIX, anchor="ls")
        elif said:
            ago = "now" if sage < 3 else (f"{int(sage)} s ago" if sage < 60 else f"{int(sage // 60)} min ago")
            d.text((RX, 632), "Cue said in your ear", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
            d.text((RX + RW, 632), ago, font=self.f(14, "medium"), fill=SIGNAL if sage < 3 else ASH, anchor="rs")
            col = FIX if day.get("said_warn") else INK
            for j, line in enumerate(self._wrap(d, "\u201c" + said + "\u201d", self.f(17), RW, 2)):
                d.text((RX, 656 + j * 21), line, font=self.f(17), fill=col if sage < 60 else SMOKE, anchor="ls")
        else:
            d.text((RX, 632), "Cue hasn't spoken yet", font=self.f(15, "medium"), fill=ASH, anchor="ls")

    # ---------- rail: start ----------
    def _welcome(self, d):
        d.text((RX, 112), "What are you doing?", font=self.f(30, "semibold"), fill=INK, anchor="ls")
        for i, (key, label, sub) in enumerate((("G", "Gym", "Reps, tempo and the weight you lift"),
                                              ("K", "Kitchen", "Knife grip, the right spoon, each step"))):
            y = 146 + i * 76
            d.rounded_rectangle([RX, y, RX + 34, y + 34], radius=5, outline=ASH, width=1)
            d.text((RX + 17, y + 24), key, font=self.f(17, "medium"), fill=INK, anchor="ms")
            d.text((RX + 52, y + 15), label, font=self.f(20, "medium"), fill=INK, anchor="ls")
            d.text((RX + 52, y + 38), sub, font=self.f(15), fill=SMOKE, anchor="ls")
        self._rule(d, 316)
        d.text((RX, 350), "Skill library", font=self.f(15, "medium"), fill=SMOKE, anchor="ls")
        rows = [("Gym", "Tested"), ("Cooking", "Tested"), ("Hand washing", "Beta"), ("Allergy check", "Beta"),
                ("Medicine", "Beta"), ("Cleaning", "Beta")]
        for i, (name, st) in enumerate(rows):
            y = 386 + i * 32
            d.text((RX, y), name, font=self.f(18), fill=INK if st == "Tested" else SMOKE, anchor="ls")
            d.text((RX + RW, y), st, font=self.f(15, "medium"), fill=SIGNAL if st == "Tested" else ASH, anchor="rs")
        d.text((RX, 386 + 6 * 32 + 6), "13 more planned, from CPR to guitar", font=self.f(15), fill=ASH, anchor="ls")
        d.text((RX, 664), "S  voice test      C  choose video      D  details", font=self.f(13, "medium"), fill=ASH, anchor="ls")
