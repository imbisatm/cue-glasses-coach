"""What Cue can start: the all-day coach and the workouts (Train column on the Today screen).

status:  "live"  works today (click to start)
         "beta"  being tested
         "soon"  on the roadmap
Edit names and blurbs freely; the home screen lays itself out from this list.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SkillCard:
    id: str
    name: str
    blurb: str = ""
    status: str = "soon"
    key: str = ""  # number key that starts a live skill


CATEGORIES: list[tuple[str, list[SkillCard]]] = [
    ("Coach", [
        SkillCard("coach", "All-day coach", "Watches your day and nudges you toward better habits", "live", "3"),
    ]),
    ("Train", [
        SkillCard("curls", "Bicep curls", "Reps + tempo, Cue Clip", "live", "1"),
        SkillCard("squats", "Squats", "Reps from the glasses", "live", "2"),
    ]),
]

BY_ID = {card.id: card for _, cards in CATEGORIES for card in cards}
BY_KEY = {card.key: card for card in BY_ID.values() if card.key}
