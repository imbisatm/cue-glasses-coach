"""Hand checks: finds hands in the frame and judges the "claw grip".

Claw grip (safe cutting): the hand holding the food keeps its fingertips
curled under, behind the knuckles. A flat hand puts fingertips under the blade.

Rule (per finger, using MediaPipe's 21 hand points):
    ratio = distance(wrist, fingertip) / distance(wrist, middle knuckle)
    - straight finger: the tip is well past the knuckle  -> ratio about 1.3-1.5
    - curled finger:   the tip is tucked near the knuckle -> ratio about 0.9-1.15
We average the index, middle and ring fingers. The hand holding the knife
wraps its fingers around the handle, so it reads as curled and never triggers.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

WRIST = 0
# (middle knuckle "PIP", fingertip) for index, middle, ring fingers
FINGERS = ((6, 8), (10, 12), (14, 16))


def curl_ratio(points: np.ndarray) -> float:
    """points: (21, 2) array of x, y for one hand. Lower = more curled."""
    wrist = points[WRIST]
    ratios = []
    for pip, tip in FINGERS:
        d_pip = np.linalg.norm(points[pip] - wrist)
        d_tip = np.linalg.norm(points[tip] - wrist)
        if d_pip > 1e-6:
            ratios.append(d_tip / d_pip)
    return float(np.mean(ratios)) if ratios else 1.0


@dataclass
class HandReading:
    points: np.ndarray  # (21, 2) in pixels
    ratio: float
    flat: bool


@dataclass
class ClawGripMonitor:
    """Warns only when a hand stays flat for `hold` seconds (avoids flicker)."""

    flat_ratio: float = 1.25
    hold: float = 0.5
    _flat_since: Optional[float] = field(default=None, repr=False)

    def update(self, readings: list[HandReading], now: Optional[float] = None) -> bool:
        now = time.monotonic() if now is None else now
        any_flat = any(r.flat for r in readings)
        if not any_flat:
            self._flat_since = None
            return False
        if self._flat_since is None:
            self._flat_since = now
        return now - self._flat_since >= self.hold


class HandTracker:
    """Thin wrapper around MediaPipe Hands (runs on the laptop CPU)."""

    def __init__(self, flat_ratio: float = 1.25, max_hands: int = 2):
        import mediapipe as mp  # imported here so the rest works without it

        self._mp = mp
        self.flat_ratio = flat_ratio
        self._hands = mp.solutions.hands.Hands(
            static_image_mode=False,
            max_num_hands=max_hands,
            model_complexity=0,  # fastest model
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )
        self._draw = mp.solutions.drawing_utils
        self._style = mp.solutions.drawing_styles
        self._last = None

    def process(self, frame_bgr: np.ndarray) -> list[HandReading]:
        import cv2

        h, w = frame_bgr.shape[:2]
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        result = self._hands.process(rgb)
        self._last = result
        readings = []
        for lm in result.multi_hand_landmarks or []:
            pts = np.array([[p.x * w, p.y * h] for p in lm.landmark], dtype=float)
            r = curl_ratio(pts)
            readings.append(HandReading(points=pts, ratio=r, flat=r > self.flat_ratio))
        return readings

    def draw(self, frame_bgr: np.ndarray) -> None:
        if self._last is None:
            return
        for lm in self._last.multi_hand_landmarks or []:
            self._draw.draw_landmarks(
                frame_bgr,
                lm,
                self._mp.solutions.hands.HAND_CONNECTIONS,
                self._style.get_default_hand_landmarks_style(),
                self._style.get_default_hand_connections_style(),
            )

    def close(self) -> None:
        self._hands.close()
