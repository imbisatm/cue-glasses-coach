"""Talks to the vision model running on AMD Radeon Cloud.

The model (Qwen2.5-VL-7B, open source from Hugging Face) is served by vLLM on an
AMD GPU (ROCm). vLLM speaks the same web format as OpenAI's chat API, so we send
a photo + a question and get text back.

VisionClient   one request at a time (waits for the answer)
VisionWorker   runs requests in the background so the video never freezes
"""

from __future__ import annotations

import base64
import json
import queue
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np


def normalize_url(url: str) -> str:
    url = (url or "").strip().rstrip("/")
    if url and not url.startswith("http"):
        url = "https://" + url
    if url.endswith("/chat/completions"):
        url = url[: -len("/chat/completions")]
    if url and not re.search(r"/v\d+[a-z0-9]*(/|$)", url):  # e.g. keep .../v1beta/openai as is
        url += "/v1"
    return url


def frame_to_data_url(frame_bgr: np.ndarray, max_width: int = 768, quality: int = 80) -> str:
    import cv2

    h, w = frame_bgr.shape[:2]
    if w > max_width:
        frame_bgr = cv2.resize(frame_bgr, (max_width, int(h * max_width / w)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", frame_bgr, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise ValueError("could not encode image")
    return "data:image/jpeg;base64," + base64.b64encode(buf.tobytes()).decode()


def parse_json(text: str) -> dict:
    """Pulls the first {...} out of a model reply, even if it added extra words."""
    match = re.search(r"\{.*\}", text, re.S)
    if not match:
        return {}
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return {}


class VisionClient:
    def __init__(self, base_url: str, api_key: str = "", model: str = "cue-vision", timeout: float = 25.0,
                 bill_to: str = ""):
        import requests

        self.base_url = normalize_url(base_url)
        self.model = model
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        if api_key:
            self.session.headers["Authorization"] = f"Bearer {api_key}"
        if bill_to:  # Hugging Face: charge an organization's credits (e.g. hackathon credits)
            self.session.headers["X-HF-Bill-To"] = bill_to
        self.last_latency = 0.0

    # ---- raw calls ----
    def list_models(self) -> list[str]:
        r = self.session.get(f"{self.base_url}/models", timeout=self.timeout)
        r.raise_for_status()
        return [m["id"] for m in r.json().get("data", [])]

    def chat(self, content: list | str, max_tokens: int = 200, system: str | None = None) -> str:
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": content})
        if "googleapis.com" in self.base_url:
            max_tokens = max(max_tokens, 1024)  # some Gemini models "think" first, using up the token budget
        body = {"model": self.model, "messages": messages, "max_tokens": max_tokens, "temperature": 0}
        start = time.monotonic()
        r = self.session.post(f"{self.base_url}/chat/completions", json=body, timeout=self.timeout)
        self.last_latency = time.monotonic() - start
        if r.status_code >= 400:
            raise RuntimeError(f"Vision model error {r.status_code}: {r.text[:800]}")
        return r.json()["choices"][0]["message"]["content"].strip()

    def ask(self, frame_bgr: np.ndarray, question: str, max_tokens: int = 200) -> str:
        content = [
            {"type": "image_url", "image_url": {"url": frame_to_data_url(frame_bgr)}},
            {"type": "text", "text": question},
        ]
        return self.chat(content, max_tokens=max_tokens)

    # ---- coaching helpers ----
    def check(self, frame_bgr: np.ndarray, statement: str) -> tuple[str, str]:
        """Is `statement` true in this photo? Returns ("yes"|"no"|"unsure", short reason)."""
        reply = self.ask(
            frame_bgr,
            "You are checking a step for a coaching app. Look only at what is visible.\n"
            f'Statement: "{statement}"\n'
            'Reply with JSON only: {"answer": "yes" or "no" or "unsure", "reason": "max 8 words"}',
            max_tokens=60,
        )
        data = parse_json(reply)
        answer = str(data.get("answer", "unsure")).lower()
        if answer not in ("yes", "no", "unsure"):
            answer = "unsure"
        return answer, str(data.get("reason", reply[:60]))

    def read_weight(self, frame_bgr: np.ndarray) -> tuple[Optional[float], Optional[str]]:
        reply = self.ask(
            frame_bgr,
            "Find the weight number printed on the dumbbell, plate or label in this photo.\n"
            'Reply with JSON only: {"weight": number or null, "unit": "lb" or "kg" or null}',
            max_tokens=40,
        )
        data = parse_json(reply)
        weight = data.get("weight")
        try:
            weight = float(weight) if weight is not None else None
        except (TypeError, ValueError):
            weight = None
        unit = data.get("unit") if data.get("unit") in ("lb", "kg") else None
        return weight, unit

    def identify_spoon(self, frame_bgr: np.ndarray) -> str:
        """Returns "teaspoon", "tablespoon", "cup", "other" or "none"."""
        reply = self.ask(
            frame_bgr,
            "Is the person holding or using a measuring spoon or cup? Read any size printed on it.\n"
            'Reply with JSON only: {"tool": "teaspoon" or "tablespoon" or "cup" or "other" or "none"}',
            max_tokens=30,
        )
        tool = str(parse_json(reply).get("tool", "none")).lower()
        return tool if tool in ("teaspoon", "tablespoon", "cup", "other", "none") else "none"

    def observe(self, frame_bgr: np.ndarray) -> dict:
        """All-day coach: which habits are happening in this frame (see cue_core/habits.py)."""
        from cue_core.habits import build_prompt, parse_observation

        reply = self.ask(frame_bgr, build_prompt(), max_tokens=120)
        return parse_observation(parse_json(reply))

    def read_label(self, frame_bgr: np.ndarray) -> str:
        return self.ask(
            frame_bgr,
            "Read the label in this photo. Write out the product name and the full ingredients "
            "and warnings text exactly as printed. If you can't read it, say UNREADABLE.",
            max_tokens=300,
        )


@dataclass
class Job:
    kind: str
    run: Callable[[], Any]
    done: Optional[Callable[[Any], None]] = None
    submitted: float = field(default_factory=time.monotonic)


class VisionWorker:
    """Runs model calls in a background thread. Results come back via callbacks
    that are executed on the main thread when you call poll()."""

    def __init__(self, client: VisionClient):
        self.client = client
        self._jobs: "queue.Queue[Job]" = queue.Queue(maxsize=4)
        self._results: "queue.Queue[tuple[Job, Any]]" = queue.Queue()
        self.busy = False
        self.last_error = ""
        self._last_printed = ""
        threading.Thread(target=self._loop, daemon=True).start()

    def submit(self, kind: str, run: Callable[[], Any], done: Optional[Callable[[Any], None]] = None) -> bool:
        try:
            self._jobs.put_nowait(Job(kind, run, done))
            return True
        except queue.Full:
            return False

    def poll(self) -> None:
        while True:
            try:
                job, result = self._results.get_nowait()
            except queue.Empty:
                return
            if job.done and not isinstance(result, Exception):
                job.done(result)

    def _loop(self) -> None:
        while True:
            job = self._jobs.get()
            self.busy = True
            try:
                result = job.run()
                self.last_error = ""
            except Exception as exc:
                result = exc
                self.last_error = f"{job.kind}: {exc}"
                friendly = friendly_vision_error(self.last_error)
                if friendly != self._last_printed:   # say it once, not every few seconds
                    self._last_printed = friendly
                    print(f"[Cue] {time.strftime('%H:%M:%S')}  Vision problem: {friendly}")
                    print(f"      (details: {str(exc)[:160]})")
            else:
                if self._last_printed:
                    print(f"[Cue] {time.strftime('%H:%M:%S')}  Vision is working again.")
                self._last_printed = ""
            self.busy = False
            self._results.put((job, result))


def friendly_vision_error(err: str) -> str:
    """A vision error in plain words (shown in the app and the black window)."""
    e = (err or "").lower()
    if not e:
        return ""
    if "perday" in e or "per day" in e or "per_day" in e:
        return "Today's free vision limit is used up. Make a new Gemini key in a NEW project, then run run_setup_vision.bat."
    if "429" in e or "quota" in e or ("rate" in e and "limit" in e) or "resource_exhausted" in e:
        return "Too many requests for the free plan. Cue is looking less often for a minute."
    if "401" in e or "403" in e or "api key" in e or "api_key" in e or "permission" in e or "unauthorized" in e:
        return "The vision key was refused. Run run_setup_vision.bat again."
    if "404" in e or "not found" in e:
        return "Vision model not found. Run run_setup_vision.bat again."
    if any(w in e for w in ("timed out", "timeout", "connection", "resolve", "max retries", "network", "ssl")):
        return "Can't reach the vision model. Check the laptop's Wi-Fi."
    if any(w in e for w in ("500", "502", "503", "504", "unavailable", "overloaded")):
        return "The vision service is busy. Cue keeps trying."
    return "The vision model had a hiccup. Cue keeps trying."


def make_vision_client(cfg: dict) -> VisionClient:
    """The right client for config.json: AMD through the notebook, or a direct web address."""
    if cfg.get("vision_mode") == "amd_notebook":
        from cue_core.amd_relay import NotebookRelayClient

        return NotebookRelayClient(cfg["amd_notebook"], cfg.get("amd_token", ""), cfg.get("vision_key", ""),
                                   cfg.get("vision_model", "cue-vision"), cookie=cfg.get("amd_cookie", ""))
    return VisionClient(cfg["vision_url"], cfg.get("vision_key", ""), cfg.get("vision_model", "cue-vision"),
                        bill_to=cfg.get("vision_bill_to", ""))
