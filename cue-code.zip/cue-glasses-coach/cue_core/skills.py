"""Runs a step-by-step skill (like a recipe): says each step, checks it with the
vision model, and moves on only when the step is really done.

A skill is a small JSON file in the skills/ folder, for example:
{
  "name": "Banana oat bowl",
  "steps": [
    {"say": "Slice the banana. Keep your fingertips curled.",
     "check": "A banana has been cut into round slices", "claw": true},
    {"say": "Add one teaspoon of oats to the bowl.",
     "check": "Oats are visible in the bowl", "tool": "teaspoon"}
  ]
}
  say    what Cue tells you
  check  a sentence the camera can confirm (Cue asks the model "is this true?")
  tool   optional: "teaspoon", "tablespoon" or "cup"; Cue warns if you grab the wrong one,
         and the step only finishes once it has seen the right one
  claw   optional: true = watch for a flat hand while cutting
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional


@dataclass
class Step:
    say: str
    check: str
    tool: Optional[str] = None
    claw: bool = False


@dataclass
class Skill:
    name: str
    steps: list[Step]

    @staticmethod
    def load(path: str | Path) -> "Skill":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return Skill(data["name"], [Step(**s) for s in data["steps"]])


class SkillRunner:
    def __init__(self, skill: Skill, worker, say: Callable[..., bool], log: Callable[..., None],
                 warn: Callable[[], None], check_every: float = 3.5):
        self.skill = skill
        self.worker = worker  # VisionWorker or None (then only manual N to advance)
        self.say = say
        self.log = log
        self.warn = warn
        self.check_every = check_every
        self.index = 0
        self.finished = False
        self.last_reason = ""
        self._last_check = 0.0
        self._last_tool = 0.0
        self._tool_ok = -1  # index of the step whose tool was confirmed
        self._started = time.monotonic()

    @property
    def step(self) -> Optional[Step]:
        return None if self.finished else self.skill.steps[self.index]

    @property
    def claw_active(self) -> bool:
        return bool(self.step and self.step.claw)

    def start(self) -> None:
        self.index, self.finished, self.last_reason = 0, False, ""
        self._started = time.monotonic()
        self.say(f"{self.skill.name}. Step 1. {self.skill.steps[0].say}", force=True)
        self.log("kitchen", "skill_start", self.skill.name)

    def advance(self, reason: str = "") -> None:
        if self.finished:
            return
        self.log("kitchen", "step_done", self.index + 1, reason)
        self.index += 1
        self.last_reason = ""
        if self.index >= len(self.skill.steps):
            self.finished = True
            took = time.monotonic() - self._started
            when = f"{took:.0f} seconds" if took < 90 else f"{took / 60:.0f} minutes"
            self.say(f"All done. {self.skill.name} finished in {when}. Nice work.", force=True)
            self.log("kitchen", "skill_done", self.skill.name, f"seconds={took:.0f}")
            return
        self.say(f"Good. Step {self.index + 1}. {self.step.say}", force=True)

    def update(self, frame) -> None:
        """Call every frame. Sends at most one model request at a time."""
        if self.finished or self.worker is None or self.worker.busy:
            return
        now = time.monotonic()
        step, idx = self.step, self.index
        client = self.worker.client

        if step.tool and now - self._last_tool > 3.0:
            self._last_tool = now
            img = frame.copy()
            self.worker.submit("tool", lambda: client.identify_spoon(img),
                               lambda tool: self._on_tool(idx, step.tool, tool))
            return
        if now - self._last_check > self.check_every:
            self._last_check = now
            img = frame.copy()
            self.worker.submit("check", lambda: client.check(img, step.check),
                               lambda res: self._on_check(idx, res))

    # ---- results (run on the main thread) ----
    def _on_check(self, idx: int, result) -> None:
        if idx != self.index or self.finished:
            return  # answer for an old step
        answer, reason = result
        self.last_reason = f"{answer}: {reason}"
        if answer == "yes":
            if self.step.tool and self._tool_ok != idx:
                self.last_reason = f"Waiting to see the {self.step.tool}."
                return
            self.advance(reason)

    def _on_tool(self, idx: int, expected: str, seen: str) -> None:
        if idx != self.index or self.finished or seen in ("none", "other"):
            return
        if seen != expected:
            if self.say(f"That's a {seen}. You need a {expected}.", key="tool", cooldown=5.0):
                self.log("kitchen", "wrong_tool", seen, f"expected={expected}")
                self.warn()
        else:
            if self._tool_ok != idx:
                self.say(f"Right, the {expected}.", key="tool_ok", cooldown=2.0)
            self._tool_ok = idx
