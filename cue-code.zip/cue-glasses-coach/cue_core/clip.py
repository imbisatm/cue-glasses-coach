"""Talks to the Cue Clip over Bluetooth (runs in the background).

- Finds the clip by name ("CueClip"), connects, and reconnects if it drops.
- Collects motion samples: tilt (pitch, roll), rotation speed, acceleration size.
- Sends buzz commands: 1 short (good), 2 double (warning), 3 long (fix), or a steady rhythm.
"""

from __future__ import annotations

import asyncio
import struct
import threading
import time
from collections import deque
from dataclasses import dataclass

MOTION_UUID = "6e5a0002-8b3c-4f1e-9a2d-c0e5c11b0001"
BUZZ_UUID = "6e5a0003-8b3c-4f1e-9a2d-c0e5c11b0001"

GOOD, WARNING, FIX = 1, 2, 3


@dataclass
class ClipSample:
    t: float  # time.monotonic() when received
    pitch: float  # degrees
    roll: float  # degrees
    gx: float  # rotation speed, degrees per second
    gy: float
    gz: float
    accel_mg: float  # total acceleration in milli-g (about 1000 when still)


class ClipClient:
    def __init__(self, name: str = "CueClip"):
        self.name = name
        self.status = "searching for CueClip..."
        self.connected = False
        self.samples: deque[ClipSample] = deque(maxlen=1000)
        self._read_index = 0
        self._total = 0
        self._client = None
        self._stop = False
        self._lock = threading.Lock()
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._thread_main, daemon=True)
        self._thread.start()

    # ---- public API (safe to call from the main thread) ----
    def new_samples(self) -> list[ClipSample]:
        """Samples that arrived since the last call."""
        with self._lock:
            fresh = self._total - self._read_index
            self._read_index = self._total
            if fresh <= 0:
                return []
            return list(self.samples)[-min(fresh, len(self.samples)):]

    def latest(self) -> ClipSample | None:
        return self.samples[-1] if self.samples else None

    def buzz(self, pattern: int = GOOD) -> None:
        self._send(bytes([pattern]))

    def rhythm(self, period_ms: int) -> None:
        """Steady beat every period_ms (0 = stop)."""
        if period_ms <= 0:
            self._send(bytes([0]))
        else:
            self._send(bytes([4, period_ms & 0xFF, (period_ms >> 8) & 0xFF]))

    def close(self) -> None:
        self._stop = True
        self.rhythm(0)
        time.sleep(0.2)
        self._loop.call_soon_threadsafe(self._loop.stop)

    # ---- background work ----
    def _send(self, data: bytes) -> None:
        client = self._client
        if not (self.connected and client):
            return

        async def write():
            try:
                await client.write_gatt_char(BUZZ_UUID, data, response=False)
            except Exception as exc:
                print(f"[clip] buzz failed: {exc}")

        asyncio.run_coroutine_threadsafe(write(), self._loop)

    def _thread_main(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.create_task(self._run())
        self._loop.run_forever()

    def _on_motion(self, _sender, data: bytearray) -> None:
        if len(data) < 12:
            return
        p, r, gx, gy, gz, a = struct.unpack("<6h", bytes(data[:12]))
        sample = ClipSample(time.monotonic(), p / 100, r / 100, gx / 10, gy / 10, gz / 10, float(a))
        with self._lock:
            self.samples.append(sample)
            self._total += 1

    async def _run(self) -> None:
        try:
            from bleak import BleakClient, BleakScanner
        except ImportError:
            self.status = "bleak not installed: run install.bat again"
            return
        while not self._stop:
            try:
                self.status = "searching for CueClip..."
                device = await BleakScanner.find_device_by_name(self.name, timeout=8.0)
                if device is None:
                    self.status = "CueClip not found (is it powered? Bluetooth on?)"
                    await asyncio.sleep(2)
                    continue
                self.status = "connecting..."
                async with BleakClient(device) as client:
                    self._client = client
                    await client.start_notify(MOTION_UUID, self._on_motion)
                    self.connected = True
                    self.status = "connected"
                    while client.is_connected and not self._stop:
                        await asyncio.sleep(0.2)
            except Exception as exc:
                self.status = f"clip error: {exc}"
                await asyncio.sleep(2)
            finally:
                self.connected = False
                self._client = None
