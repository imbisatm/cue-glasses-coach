"""Compact Cue Clip case v2 for the MLH parts: SG92R servo (on its side) + Grove accelerometer.
Sized to print in well under an hour. Sizes in mm.
"""
from pathlib import Path

import trimesh
from trimesh.creation import box, cylinder

HERE = Path(__file__).resolve().parent
IN_L, IN_W, IN_H = 60.0, 36.0, 16.0   # servo lying flat (32 x 31 x 12) + accelerometer (20 x 20)
WALL, BASE = 1.6, 5.0                  # floor holds two strap tunnels
STRAP_W, STRAP_H = 27.0, 3.2
WIRE_W, WIRE_H = 12.0, 7.0
FIT = 0.3
OUT_L, OUT_W, OUT_H = IN_L + 2 * WALL, IN_W + 2 * WALL, BASE + IN_H


def at(m, x=0.0, y=0.0, z=0.0):
    m.apply_translation([x, y, z])
    return m


def case():
    shell = at(box([OUT_L, OUT_W, OUT_H]), z=OUT_H / 2)
    cuts = [at(box([IN_L, IN_W, IN_H + 1]), z=BASE + (IN_H + 1) / 2),
            at(box([WALL * 3, WIRE_W, WIRE_H]), x=-OUT_L / 2, z=BASE + 2 + WIRE_H / 2)]
    for side in (-1, 1):
        cuts.append(at(box([STRAP_W, OUT_W + 2, STRAP_H]), x=side * (OUT_L / 2 - STRAP_W / 2 - 2.5), z=0.8 + STRAP_H / 2))
    return trimesh.boolean.difference([shell] + cuts, engine="manifold")


def lid():
    plate = at(box([OUT_L, OUT_W, 1.6]), z=0.8)
    lo = at(box([IN_L - 2 * FIT, IN_W - 2 * FIT, 2.5]), z=1.6 + 1.25)
    li = at(box([IN_L - 2 * FIT - 2.4, IN_W - 2 * FIT - 2.4, 2.7]), z=1.6 + 1.35)
    lip = trimesh.boolean.difference([lo, li], engine="manifold")
    ring = at(cylinder(radius=6, height=1.0, sections=64), z=0.0)
    hole = at(cylinder(radius=4, height=1.2, sections=64), z=0.0)
    mark = trimesh.boolean.difference([ring, hole, at(box([6, 5, 1.4]), x=4.5)], engine="manifold")
    return trimesh.boolean.difference([trimesh.boolean.union([plate, lip], engine="manifold"), mark], engine="manifold")


if __name__ == "__main__":
    for name, m in (("cue_case.stl", case()), ("cue_case_lid.stl", lid())):
        assert m.is_watertight, name
        m.export(HERE / name)
        x, y, z = m.extents
        print(f"{name}: {x:.0f} x {y:.0f} x {z:.0f} mm, {m.volume / 1000:.1f} cm^3")
