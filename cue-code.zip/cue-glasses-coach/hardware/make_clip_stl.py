"""Generates the Cue Clip case: clip_base.stl and clip_lid.stl.

Change the numbers below if your board is bigger, then run:  python make_clip_stl.py
All sizes in millimetres.
"""

from pathlib import Path

import trimesh
from trimesh.creation import box, cylinder

HERE = Path(__file__).resolve().parent

# Inside space: fits an ESP32 DevKit (about 55 x 28 mm) + MPU6050 + motor + wires
INNER_L, INNER_W, INNER_H = 72.0, 40.0, 24.0
WALL = 2.2
BASE = 6.0  # thick floor with two tunnels for the strap underneath
STRAP_W, STRAP_H = 27.0, 3.6  # fits a 25 mm velcro strap
USB_W, USB_H = 13.0, 8.0  # cable hole in one end wall
FIT = 0.35  # gap so the lid slides in

OUT_L, OUT_W, OUT_H = INNER_L + 2 * WALL, INNER_W + 2 * WALL, BASE + INNER_H


def at(mesh, x=0.0, y=0.0, z=0.0):
    mesh.apply_translation([x, y, z])
    return mesh


def make_base():
    shell = at(box([OUT_L, OUT_W, OUT_H]), z=OUT_H / 2)
    cavity = at(box([INNER_L, INNER_W, INNER_H + 1]), z=BASE + (INNER_H + 1) / 2)
    parts_to_cut = [cavity]
    for side in (-1, 1):  # strap tunnels running across the width, under the floor
        x = side * (OUT_L / 2 - STRAP_W / 2 - 4)
        parts_to_cut.append(at(box([STRAP_W, OUT_W + 2, STRAP_H]), x=x, z=1.2 + STRAP_H / 2))
    # USB cable hole in the -X end wall
    parts_to_cut.append(at(box([WALL * 3, USB_W, USB_H]), x=-OUT_L / 2, z=BASE + 3 + USB_H / 2))
    return trimesh.boolean.difference([shell] + parts_to_cut, engine="manifold")


def make_lid():
    plate = at(box([OUT_L, OUT_W, 2.0]), z=1.0)
    lip_l, lip_w = INNER_L - 2 * FIT, INNER_W - 2 * FIT
    lip_outer = at(box([lip_l, lip_w, 3.0]), z=2.0 + 1.5)
    lip_inner = at(box([lip_l - 3.2, lip_w - 3.2, 3.2]), z=2.0 + 1.6)
    lip = trimesh.boolean.difference([lip_outer, lip_inner], engine="manifold")
    # Little "C" mark on the outside face (the face that sits on the print bed is
    # the outside, so the mark is recessed 0.6 mm into it).
    ring = at(cylinder(radius=8, height=1.2, sections=64), z=0.0)
    hole = at(cylinder(radius=5.5, height=1.4, sections=64), z=0.0)
    c_mark = trimesh.boolean.difference([ring, hole, at(box([8, 6, 1.6]), x=6, z=0.0)], engine="manifold")
    lid = trimesh.boolean.union([plate, lip], engine="manifold")
    return trimesh.boolean.difference([lid, c_mark], engine="manifold")


if __name__ == "__main__":
    base, lid = make_base(), make_lid()
    for name, mesh in (("clip_base.stl", base), ("clip_lid.stl", lid)):
        assert mesh.is_watertight, f"{name} is not watertight"
        mesh.export(HERE / name)
        x, y, z = mesh.extents
        print(f"{name}: {x:.1f} x {y:.1f} x {z:.1f} mm, volume {mesh.volume / 1000:.1f} cm^3")
