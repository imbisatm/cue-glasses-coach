"""Optional tray that holds the Arduino UNO (+ Grove Base Shield) on the dumbbell.

Open on one short end for the USB and power sockets. Strap goes through the two
tunnels under the floor; a rubber band over the top holds the board in.
"""
from pathlib import Path

import trimesh
from trimesh.creation import box

HERE = Path(__file__).resolve().parent
IN_L, IN_W = 70.5, 55.5  # UNO is 68.6 x 53.4 mm
WALL, BASE, WALL_H = 2.2, 6.0, 10.0
STRAP_W, STRAP_H = 27.0, 3.6
OUT_L, OUT_W, OUT_H = IN_L + 2 * WALL, IN_W + 2 * WALL, BASE + WALL_H


def at(m, x=0.0, y=0.0, z=0.0):
    m.apply_translation([x, y, z])
    return m


shell = at(box([OUT_L, OUT_W, OUT_H]), z=OUT_H / 2)
cuts = [at(box([IN_L, IN_W, WALL_H + 1]), z=BASE + (WALL_H + 1) / 2),
        at(box([WALL * 3, IN_W, WALL_H + 1]), x=OUT_L / 2, z=BASE + (WALL_H + 1) / 2)]  # open USB end
for side in (-1, 1):
    cuts.append(at(box([STRAP_W, OUT_W + 2, STRAP_H]), x=side * (OUT_L / 2 - STRAP_W / 2 - 4), z=1.2 + STRAP_H / 2))
tray = trimesh.boolean.difference([shell] + cuts, engine="manifold")
assert tray.is_watertight
tray.export(HERE / "uno_tray.stl")
x, y, z = tray.extents
print(f"uno_tray.stl: {x:.0f} x {y:.0f} x {z:.0f} mm, {tray.volume / 1000:.1f} cm^3")
