# Cue Clip (USB version): MLH hardware lab parts

Parts: **Arduino board** (from the Arduino Kit) + **Grove 3-Axis Digital Accelerometer** + **Servo Motor** + **Grove Buzzer** (optional) + **breadboard** + **Grove jumper wires** + **jumper wires** + **USB cable**.

The clip talks to the laptop over the USB cable. No Bluetooth, no battery.

## 1. Wire it (15 minutes)

### Easiest: with the Grove Base Shield (the black board with white sockets on top of the Arduino)
1. Find the small **switch** on the shield marked **5V / 3V3** (near the corner). Slide it to **5V**.
2. **Accelerometer:** Grove cable (white plug on both ends) from the sensor into **any socket labeled I2C**.
3. **Buzzer (optional):** Grove cable into socket **D8**.
4. **Servo:** take a **Grove jumper wire** (white plug on one end, 4 loose pins on the other):
   - white plug into **any D socket (D2–D8)**; the code drives all of pins 2–13
   - push the pins into the servo's plug, matching colors: **yellow → orange**, **red → red**, **black → brown**
   - leave the **white** pin unconnected (tape it so it doesn't touch anything)

That's it: no loose wires on the Arduino itself.

### No breadboard? Use this (simplest)
The Arduino has 3 GND pins, one 5V and one 3.3V, which is enough for the sensor and the servo. Skip the buzzer.

| Part | Wire | Arduino pin |
|---|---|---|
| Accelerometer | Red | **3.3V** |
| Accelerometer | Black | **GND** (next to 5V) |
| Accelerometer | White | **SDA** (or A4) |
| Accelerometer | Yellow | **SCL** (or A5) |
| Servo | Red | **5V** |
| Servo | Brown or black | the **other GND** (next to 5V) |
| Servo | Orange or yellow | pin **5** |

### With a breadboard

The Arduino has only one **5V** pin, so we use the breadboard's long **side rails** to share power:
- Arduino **5V** → breadboard **red (+) rail** (male-to-male jumper)
- Arduino **GND** → breadboard **blue (−) rail** (male-to-male jumper)

**Grove wire colors:** black = GND, red = power, white = SDA / unused, yellow = SCL / signal.

**Accelerometer** (Grove jumper wire):
| Wire | Goes to |
|---|---|
| Black | breadboard − rail |
| Red | breadboard + rail |
| White | Arduino **SDA** (top-left pins near AREF, or **A4**) |
| Yellow | Arduino **SCL** (next to SDA, or **A5**) |

**Servo** (3 wires: plug male-to-male jumpers into its connector):
| Servo wire | Goes to |
|---|---|
| Brown or black | breadboard − rail |
| Red | breadboard + rail |
| Orange or yellow | Arduino pin **5** |

**Buzzer (optional)** (Grove jumper wire):
| Wire | Goes to |
|---|---|
| Black | breadboard − rail |
| Red | breadboard + rail |
| Yellow | Arduino pin **8** |
| White | nothing |

## 2. Upload the code (10 minutes)
1. Install **Arduino IDE 2** from https://www.arduino.cc/en/software (no extra packages needed for a normal UNO).
2. Open `firmware/cue_clip_usb/cue_clip_usb.ino`.
3. Plug the Arduino into the laptop.
4. **Tools → Board** → pick your board (for example **Arduino Uno**, or **Arduino UNO R4 WiFi**). If the IDE offers to install the board package, click **Install**.
5. **Tools → Port** → pick the COM port that appeared.
6. Click **Upload** (→). Wait for "Done uploading."
7. **Tools → Serial Monitor**, set **115200 baud**. You should see:
   - `CUE,ADXL345` (or another sensor name) at the start
   - then lots of lines like `M,12.3,-4.5,1002`. The first number changes when you tilt the sensor.
   - the servo **twitches twice** at start (hello buzz)
8. **Close the Serial Monitor** before running Cue. Only one program can use the port at a time.

## 3. Test with the laptop
1. Run **install.bat** again (adds the USB library), then **run_clip_test.bat**.
2. You should see `connected (ADXL345)`, live tilt numbers, a servo buzz every 4 seconds, and `REP 1, 2, 3...` when you do curls.

## 4. Mount it on the dumbbell
- Accelerometer and servo go **inside the printed case**. Tape the accelerometer flat to the floor so it can't wobble. Lay the servo on its side.
- Tape a **coin to the servo arm**. The extra weight makes the wiggle much easier to feel.
- Strap the case to the dumbbell handle with velcro through the two tunnels.
- Strap the **Arduino** and breadboard to the other end of the dumbbell (rubber bands or velcro), so only the **USB cable** runs to the laptop.

## If something goes wrong
| Problem | Fix |
|---|---|
| No COM port | Try another USB cable (many are charge-only). |
| `motion sensor not found` | Check the accelerometer's 4 wires; swap white and yellow if unsure. |
| Servo doesn't move | Check the servo's 3 wires. The orange (signal) wire must be in a pin 2–13 hole or a D socket (not UART, not A0–A3). |
| Arduino keeps restarting when the servo moves | The servo draws too much power: unplug the buzzer, or use a shorter USB cable directly into the laptop (no hub). |
| Cue says "Arduino clip not found" | Close the Arduino Serial Monitor; unplug and replug the USB cable. |
| Any error text | Copy it and send it to Claude. |
