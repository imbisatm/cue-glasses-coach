# Cue Clip: wiring, upload, test

Total time: about 1 hour (print runs in the background).

## 0. Start the print first (2 minutes)
- Files: `clip_base.stl` and `clip_lid.stl` (this folder).
- Settings: **PLA, 0.2 mm layers, 15% infill, no supports.** Lid goes flat side down.
- Time: about 1.5–2 h for the base, about 30 min for the lid.
- Fits an ESP32 DevKit (about 55 x 28 mm). If your board is bigger, tell Claude the size and you'll get new files.

## 1. Wire it on the breadboard first

**Motion sensor (MPU6050 / GY-521)**, 4 wires:

| MPU6050 pin | Goes to ESP32 |
|---|---|
| VCC | **3V3** (not 5V) |
| GND | GND |
| SCL | SCL pin (table below) |
| SDA | SDA pin (table below) |

**Which pins are SDA, SCL and motor on your board:**

| Board | SDA | SCL | Motor |
|---|---|---|---|
| ESP32 DevKit (most common, "ESP32-WROOM") | GPIO **21** | GPIO **22** | GPIO **25** |
| ESP32-C3 SuperMini / DevKit | GPIO **8** | GPIO **9** | GPIO **3** |
| Seeed XIAO ESP32-C3 | **D4** | **D5** | **D1** |
| ESP32-S3 DevKit | GPIO **8** | GPIO **9** | GPIO **4** |

> Not sure? After uploading (step 3), the Serial Monitor prints `SDA pin = X, SCL pin = Y, motor pin = Z`. Use those.

**Vibration motor:** choose the one you have.

**A) Vibration motor module** (small board, 3 pins). Easiest.

| Module pin | Goes to |
|---|---|
| VCC / + | 3V3 |
| GND / − | GND |
| IN / SIG / S | Motor pin |

**B) Bare coin motor** (2 thin wires). Needs a transistor, because the ESP32 pin can't power a motor directly.
- Motor **red** wire → **3V3**
- Motor **blue/black** wire → transistor **C** (collector)
- Transistor **E** (emitter) → **GND**
- Transistor **B** (base) → **1k resistor** → **motor pin**
- **Diode** across the motor: the end with the **stripe** goes to the red (3V3) side, the other end to the collector side.
- Plastic 2N2222 / PN2222 / 2N3904: hold the **flat face toward you, legs down**. Left to right the legs are **E, B, C**.

## 2. Install the Arduino software (one time, about 10 minutes)
1. Download **Arduino IDE 2** for Windows: https://www.arduino.cc/en/software and install it.
2. Open it. **File → Preferences → "Additional boards manager URLs"**, paste:
   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`
3. **Tools → Board → Boards Manager**, search **esp32**, install **"esp32 by Espressif Systems"** (large download).

## 3. Upload the firmware
1. Open `firmware/cue_clip/cue_clip.ino` in Arduino IDE.
2. Plug the ESP32 into the laptop with the USB cable.
3. **Tools → Board → esp32 →** pick yours:
   - ESP32 DevKit → **ESP32 Dev Module**
   - ESP32-C3 → **ESP32C3 Dev Module** (XIAO: **XIAO_ESP32C3**)
   - ESP32-S3 → **ESP32S3 Dev Module**
4. **C3 or S3 boards only:** **Tools → USB CDC On Boot → Enabled** (otherwise the Serial Monitor shows nothing).
5. **Tools → Port →** pick the COM port that appeared when you plugged it in.
6. Click **Upload** (the → arrow). Wait for "Done uploading."
7. **Tools → Serial Monitor**, set **115200 baud**. You should see:
   - `Motion sensor found at 0x68`
   - `Bluetooth ready as "CueClip"`
   - tilt numbers changing when you tilt the board
   - and you **feel a double "hello" buzz** at start.

## 4. Test with the laptop
1. **Close the Arduino Serial Monitor** (it can block things).
2. Make sure **Bluetooth is on** in Windows (Settings → Bluetooth). You do **not** need to pair it in Windows settings.
3. In the cue folder, run **install.bat** again (it adds the Bluetooth library), then double-click **run_clip_test.bat**.
4. You should see `[clip] connected`, live tilt numbers, a buzz every 4 seconds, and `REP 1, 2, 3...` when you do curls with the board taped to a bottle.

## 5. Put it in the case
- Tape or hot-glue the **MPU6050 flat to the floor** of the case. It must not wobble.
- Glue the **motor to the floor** too, so the buzz is felt through the case.
- ESP32 on top, with a bit of foam or tape. USB cable goes out through the end hole to the power bank.
- **Strap:** thread velcro through the two tunnels under the case and wrap it around the dumbbell or bottle.

## If something goes wrong

| Problem | Fix |
|---|---|
| No COM port appears | Try another USB cable (many are charge-only). Still nothing: install the **CP210x** or **CH340** driver (the chip name is printed near the USB port). |
| "Failed to connect… wrong boot mode" | Hold the **BOOT** button on the board while clicking Upload, release when it says "Connecting…" |
| "Motion sensor NOT found" | Check the 4 sensor wires; make sure SDA and SCL aren't swapped. |
| No buzz | Check the motor wiring. With a bare motor, check the transistor's E/B/C legs. |
| Laptop can't find "CueClip" | Close Serial Monitor, turn Bluetooth off and on, move closer. |
| Clip switches off after about 30 s on the power bank | Some power banks sleep at low power. Try another bank, or run it from the laptop's USB for the demo. |
| Any error text | Copy the whole thing and send it to Claude. |
