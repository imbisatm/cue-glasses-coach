"""Generates two demo measuring scoops with big raised labels: TSP (5 mL) and TBSP (15 mL).

Big letters let the vision model tell them apart through the glasses video.
Demo prop only: printed PLA is not food-safe, so use it with dry oats, not food you'll eat.
"""

import math
from pathlib import Path

import trimesh
from matplotlib.font_manager import FontProperties
from matplotlib.textpath import TextPath
from shapely.geometry import Polygon
from trimesh.creation import box, cylinder, extrude_polygon

HERE = Path(__file__).resolve().parent
WALL, FLOOR = 1.8, 1.8
HANDLE_W, HANDLE_T = 16.0, 4.0
TEXT_H = 1.4  # raised letters


def text_mesh(text: str, height_mm: float) -> trimesh.Trimesh:
    path = TextPath((0, 0), text, size=10, prop=FontProperties(family="DejaVu Sans", weight="bold"))
    polys = []
    for ring in path.to_polygons(closed_only=True):
        if len(ring) >= 3:
            polys.append(Polygon(ring))
    # Outer letter shapes are the big rings; holes (inside "P", "B") are inside them.
    polys.sort(key=lambda p: -p.area)
    shapes = []
    for p in polys:
        for i, s in enumerate(shapes):
            if s.contains(p):
                shapes[i] = s.difference(p)
                break
        else:
            shapes.append(p)
    meshes = [extrude_polygon(s, TEXT_H) for s in shapes if not s.is_empty and s.area > 0.5]
    m = trimesh.util.concatenate(meshes)
    x0, y0, _ = m.bounds[0]
    x1, y1, _ = m.bounds[1]
    scale = height_mm / (y1 - y0)
    m.apply_translation([-(x0 + x1) / 2, -(y0 + y1) / 2, 0])
    m.apply_scale([scale, scale, 1])
    return m


def scoop(volume_ml: float, label: str, handle_len: float) -> trimesh.Trimesh:
    radius = 11.0 if volume_ml <= 6 else 15.0
    depth = volume_ml * 1000 / (math.pi * radius**2)
    outer = cylinder(radius=radius + WALL, height=depth + FLOOR, sections=96)
    outer.apply_translation([0, 0, (depth + FLOOR) / 2])
    inner = cylinder(radius=radius, height=depth + 1, sections=96)
    inner.apply_translation([0, 0, FLOOR + (depth + 1) / 2])
    handle = box([handle_len, HANDLE_W, HANDLE_T])
    handle.apply_translation([radius + handle_len / 2, 0, HANDLE_T / 2])
    body = trimesh.boolean.union([outer, handle], engine="manifold")
    body = trimesh.boolean.difference([body, inner], engine="manifold")
    letters = text_mesh(label, HANDLE_W * 0.62)
    if letters.extents[0] > handle_len - 14:
        s = (handle_len - 14) / letters.extents[0]
        letters.apply_scale([s, s, 1])
    letters.apply_translation([radius + WALL + 4 + handle_len / 2 - 2, 0, HANDLE_T])
    return trimesh.boolean.union([body, letters], engine="manifold")


if __name__ == "__main__":
    for name, ml, label, length in (("spoon_tsp.stl", 5, "TSP", 60), ("spoon_tbsp.stl", 15, "TBSP", 75)):
        m = scoop(ml, label, length)
        assert m.is_watertight, name
        m.export(HERE / name)
        print(f"{name}: {m.extents[0]:.0f} x {m.extents[1]:.0f} x {m.extents[2]:.0f} mm, {m.volume / 1000:.1f} cm^3")
