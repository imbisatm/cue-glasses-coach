"""Cue bridge: watches the glasses video (WhatsApp call on your screen) and coaches you.

Run:  double-click run_bridge.bat   (or run_webcam_test.bat to test with your laptop camera)

Today screen: Enter (or 3) starts the all-day coach, 1 curls, 2 squats. Click Live/Morning/Afternoon/Night
or press Z to change the demo clock.
Keys (click the Cue window first so it has focus):
  Esc / H  back to the Skills home screen
  G  gym (curls with the clip, or squats)   Z  demo clock (Live / Morning / Afternoon / Night)
  C  choose the screen area again (the glasses video)
  S  say a test sentence (check you hear it in the glasses)
  W  gym: read the weight on the dumbbell again (AMD model)
  N  kitchen: skip to the next step
  R  reset rep count
  T  "these were good reps": set the tempo target from your last 3 reps
  B  connect the Cue Clip (USB Arduino)
  D  show/hide technical details
  M  gym: count reps from the camera or from the clip
  Y  clip rhythm on/off (buzzes the target pace)
  +  /  -   rep sensitivity (bigger number = needs bigger movement)
  ]  /  [   claw-grip strictness
  Q  quit
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from collections import deque
from pathlib import Path

import cv2
import numpy as np

from cue_core.capture import ScreenSource, WebcamSource
from cue_core.clip import FIX, GOOD, WARNING
from cue_core.serial_clip import make_clip
from cue_core.config import load_config, save_config
from cue_core.hands import ClawGripMonitor, HandTracker
from cue_core.skills import Skill, SkillRunner
from cue_core.vision import VisionClient, VisionWorker, friendly_vision_error, make_vision_client
from cue_core.motion import CLIP_TEMPO, RepCounter, TempoTarget, TiltTracker, VerticalMotionTracker, target_from_reps, tempo_feedback
from cue_core.speech import Speaker
from cue_core.ui import CueUI
from cue_core.catalog import BY_ID, BY_KEY, CATEGORIES
from cue_core.habits import CHECKLIST, HabitCoach

HERE = Path(__file__).resolve().parent
VERSION = "22"   # shown in the app, so we can tell which update is running
LOG_PATH = HERE / "session_log.csv"

# Spoken lines that are corrections show as orange captions on screen.
CORRECTIONS = ("curl your", "slower", "all the way", "go a little deeper", "control the", "steady pace", "you need a", "couldn't read", "isn't connected",
               "put the", "phone down", "stop scrolling", "late meal", "heads up", "put the screen")

GREEN, RED, YELLOW, WHITE, GREY = (90, 200, 90), (60, 60, 230), (40, 200, 230), (245, 245, 245), (120, 120, 120)


def put_text(img, text, org, color=WHITE, scale=0.7, thick=2):
    (w, h), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, thick)
    x, y = org
    cv2.rectangle(img, (x - 6, y - h - 8), (x + w + 6, y + base + 4), (20, 20, 20), -1)
    cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick, cv2.LINE_AA)


def draw_chart(img, values, threshold, height=110):
    """Strip chart of the motion signal at the bottom of the window."""
    h, w = img.shape[:2]
    top = h - height
    overlay = img.copy()
    cv2.rectangle(overlay, (0, top), (w, h), (15, 15, 15), -1)
    cv2.addWeighted(overlay, 0.75, img, 0.25, 0, img)
    if len(values) < 2:
        return
    v = np.array(values, dtype=float)
    span = max(np.abs(v).max(), threshold * 2, 1e-3)
    mid = top + height // 2
    for level in (threshold, -threshold):
        y = int(mid - level / span * (height / 2 - 6))
        cv2.line(img, (0, y), (w, y), GREY, 1)
    xs = np.linspace(0, w - 1, len(v)).astype(int)
    ys = (mid - v / span * (height / 2 - 6)).astype(int)
    pts = np.stack([xs, ys], axis=1).reshape(-1, 1, 2)
    cv2.polylines(img, [pts], False, YELLOW, 2, cv2.LINE_AA)
    put_text(img, "motion", (8, top + 22), GREY, 0.5, 1)


ARROWS = {2424832: "left", 2490368: "up", 2555904: "right", 2621440: "down",   # Windows
          65361: "left", 65362: "up", 65363: "right", 65364: "down"}               # Linux


def load_today(path: Path) -> dict:
    """Today's totals from session_log.csv, for the home screen."""
    today = {"reps": 0, "recipes": 0, "saves": 0, "cpr": 0}
    if not path.exists():
        return today
    stamp = time.strftime("%Y-%m-%d")
    try:
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if not row.get("time", "").startswith(stamp):
                    continue
                ev = row.get("event")
                today["reps"] += ev == "rep"
                today["recipes"] += ev == "skill_done"
                today["saves"] += ev == "claw_warning"
                today["cpr"] += ev == "cpr_done"
    except Exception:
        pass
    return today


# ---- live link: the Cue web app (opened on this laptop) reads today's real data from here ----
LIVE = {"data": {"app": "cue", "ok": False}}


class LiveHandler(BaseHTTPRequestHandler):
    def _head(self, code: int = 200) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def do_OPTIONS(self):  # browser pre-check
        self._head(204)

    def do_GET(self):
        body = json.dumps(LIVE["data"]).encode()
        self._head(200)
        self.wfile.write(body)

    def log_message(self, *args):  # keep the console quiet
        pass


def start_live_server(port: int):
    """Only this laptop can reach it (127.0.0.1)."""
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), LiveHandler)
    except OSError as exc:
        print(f"[live] web app link is off: {exc}")
        return None
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"[live] web app link on http://127.0.0.1:{port}/live.json")
    return server


class Logger:
    def __init__(self, path: Path):
        new = not path.exists()
        self._f = open(path, "a", newline="", encoding="utf-8")
        self._w = csv.writer(self._f)
        if new:
            self._w.writerow(["time", "mode", "event", "value", "detail"])

    def log(self, mode, event, value="", detail=""):
        self._w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), mode, event, value, detail])
        self._f.flush()


def main() -> None:
    parser = argparse.ArgumentParser(description="Cue bridge")
    parser.add_argument("--webcam", type=int, default=None, help="use webcam N instead of the screen")
    args = parser.parse_args()

    cfg = load_config()
    if args.webcam is not None:
        source = WebcamSource(args.webcam)
        source_name = f"webcam {args.webcam}"
    else:
        source = ScreenSource(cfg.get("region"), cfg.get("monitor", 1))
        source_name = "screen"
        if not cfg.get("region"):
            print("Pick the glasses video: drag a box around it, then press ENTER.")
            region = source.select_region()
            if region:
                cfg["region"] = region
                save_config(cfg)

    speaker = Speaker(rate=cfg["voice_rate"], device=cfg["audio_device"], also_speakers=cfg.get("voice_on_speakers", True))
    ui = CueUI()
    debug = False
    labels: list = []
    last_rep: dict = {}
    logger = Logger(LOG_PATH)
    tracker = VerticalMotionTracker()
    counter = RepCounter(threshold=cfg["rep_threshold"])
    target = TempoTarget(down=cfg["tempo_down"], up=cfg["tempo_up"])
    clip_target = TempoTarget(down=cfg.get("clip_tempo_away", CLIP_TEMPO.down), up=cfg.get("clip_tempo_back", CLIP_TEMPO.up))
    tilt = TiltTracker()
    hands = None  # created the first time kitchen mode is used (takes a second)
    claw = ClawGripMonitor(flat_ratio=cfg["claw_flat_ratio"])

    clip = make_clip(cfg) if cfg.get("use_clip") else None
    worker = None
    if cfg.get("vision_url"):
        worker = VisionWorker(make_vision_client(cfg))
    skill_path = HERE / cfg.get("kitchen_skill", "skills/kitchen_basics.json")
    runner = None
    weight_text = ""
    weight_due = 0.0  # when to read the dumbbell weight (0 = not scheduled)
    clip_counter = RepCounter(threshold=cfg["clip_rep_threshold"], smoothing=0.2)
    motion_source = "camera"
    rhythm_on = False
    habits = HabitCoach(save_path=HERE / "today.json", log=logger.log)
    start_live_server(int(cfg.get("live_port", 8765)))
    live_at = 0.0
    rep_depths: deque = deque(maxlen=6)   # size of recent full reps, to catch half reps
    habit_every = min(5.0, float(cfg.get("habit_every", 3.0)))   # seconds between looks at the day
    last_look, last_obs_done, last_tick = 0.0, time.monotonic(), 0.0
    last_score, score_at = habits.score(), 0.0

    mode = "home"
    session_mode = ""
    goal = int(cfg.get("set_goal", 10))
    set_no, set_history, gym_summary, kitchen_summary = 1, [], None, None
    last_rep_at, summary_at, grip_warnings = -99.0, 0.0, 0
    focus, last_mouse_pos, hover_action = None, None, None
    today = load_today(LOG_PATH)
    grid = [["coach", "curls", "squats"]]
    skill_name = ""
    mouse = {"click": None, "pos": None}
    status = ""
    status_until = time.monotonic() + 6
    last_claw = None
    warn_until = 0.0
    chart = deque(maxlen=180)
    frame_gap = 1.0 / max(1, cfg["fps"])
    fps_est = 0.0
    t0 = time.monotonic()

    def warn() -> None:
        nonlocal warn_until
        warn_until = time.monotonic() + 0.8
        if clip:
            clip.buzz(WARNING)

    def on_weight(result) -> None:
        nonlocal weight_text
        weight, unit = result
        if weight:
            unit_word = {"lb": "pounds", "kg": "kilos"}.get(unit or "", "")
            weight_text = f"{weight:g} {unit or ''}".strip()
            speaker.say(f"{weight:g} {unit_word}. Logged. Start when you're ready.", force=True)
            logger.log("gym", "weight", weight, unit or "")
        else:
            speaker.say("I couldn't read the weight. Hold it closer and press W.", force=True)

    def next_set() -> None:
        nonlocal set_no, set_history, gym_summary, last_rep
        set_no += 1
        set_history, gym_summary, last_rep = [], None, {}
        counter.reset(); clip_counter.reset(); tilt.reset(); tracker.reset(); chart.clear(); rep_depths.clear()
        speaker.say(f"Set {set_no}. Hold still, then go.", force=True)

    def new_day() -> None:
        nonlocal status, status_until
        habits.reset_day()
        today["reps"] = today["recipes"] = today["saves"] = 0
        status, status_until = "New day started: score and checklist reset", time.monotonic() + 3
        speaker.say("New day. Let's make it a good one.", force=True)

    warn_lines: set = set()   # spoken lines that were warnings (orange on screen)

    def speak_nudges(nudges) -> None:
        nonlocal warn_until
        for n in nudges:
            print(f"[Cue] {time.strftime('%H:%M:%S')}  {'WARNING in your ear' if n.warn else 'In your ear'}: \"{n.text}\"")
            speaker.say(n.text, key="habit:" + n.habit, cooldown=0, force=True)
            if n.warn:
                warn_lines.add(n.text)
                warn_until = time.monotonic() + 1.0
                if clip and clip.connected:
                    clip.buzz(WARNING)

    def on_observe(obs) -> None:
        nonlocal last_obs_done
        now_m = time.monotonic()
        dt = now_m - last_obs_done
        last_obs_done = now_m
        if mode in ("coach", "home"):
            things = ", ".join(s.replace("_", " ") for s in obs.get("seen", [])) or "nothing from the list"
            print(f"[Cue] {time.strftime('%H:%M:%S')}  Glasses see: {things}   ({obs.get('note', '')})")
            speak_nudges(habits.observe(obs, dt))

    def start_skill(card_id: str) -> None:
        """Opens a skill from the home screen (click or number key)."""
        nonlocal mode, session_mode, skill_name, motion_source, runner, status, status_until, weight_due, last_rep, clip
        nonlocal set_no, set_history, gym_summary, kitchen_summary, grip_warnings
        card = BY_ID.get(card_id)
        if card is None:
            return
        if card.status != "live":
            when = "in testing" if card.status == "beta" else "coming soon"
            status, status_until = f"{card.name} is {when}", time.monotonic() + 3
            speaker.say(f"{card.name} is {when}.", force=True)
            return
        skill_name = card.name
        logger.log("app", "start_skill", card.id)
        set_no, set_history, gym_summary, kitchen_summary, grip_warnings = 1, [], None, None, 0
        tracker.reset(); counter.reset(); clip_counter.reset(); tilt.reset(); chart.clear(); rep_depths.clear()
        last_rep = {}
        if card.id in ("curls", "squats"):
            mode = "gym"
            if card.id == "curls":
                if clip is None:
                    clip = make_clip(cfg)
                    cfg["use_clip"] = True
                    save_config(cfg)
                motion_source = "clip"
                if worker:
                    speaker.say("Bicep curls. Show me your dumbbell.", force=True)
                    weight_due = time.monotonic() + 2.5
                elif clip.connected:
                    speaker.say("Bicep curls. Hold the weight still at your side, then go.", force=True)
                else:
                    speaker.say("Bicep curls. The clip isn't connected yet.", force=True)
            else:
                motion_source = "camera"
                speaker.say("Squats. Stand tall, then go.", force=True)
        elif card.id == "coach":
            mode = "coach"
            if worker:
                speaker.say("All-day coach on. I'll keep an eye on your day.", force=True)
            else:
                speaker.say("The vision model isn't connected, so I can't see your habits yet. Run setup vision.", force=True)
        else:
            mode = "kitchen"
            if card.id == "recipe":
                try:
                    runner = SkillRunner(Skill.load(skill_path), worker, speaker.say, logger.log, warn)
                    runner.start()
                except Exception as exc:
                    runner = None
                    print(f"Could not load the recipe ({exc}); knife grip check only")
                    speaker.say("Kitchen. I'll watch your knife grip.", force=True)
            else:
                runner = None
                speaker.say("Knife grip. I'll tell you if your fingers go flat.", force=True)
        session_mode = mode

    view = {"dx": 0, "dy": 0}  # letterbox offset of the app picture inside the window

    def fit_window(img):
        """Pads the 1280x720 app picture to the window's shape, so it never looks stretched."""
        try:
            _, _, ww, wh = cv2.getWindowImageRect("Cue")
        except Exception:
            ww = wh = 0
        ih, iw = img.shape[:2]
        view["dx"] = view["dy"] = 0
        if ww < 50 or wh < 50 or abs(ww / wh - iw / ih) < 0.02:
            return img
        if ww / wh < iw / ih:  # window is taller than the app: pad top and bottom
            nh = int(round(iw * wh / ww))
            canvas = np.full((nh, iw, 3), (23, 21, 20), np.uint8)
            view["dy"] = (nh - ih) // 2
            canvas[view["dy"]:view["dy"] + ih] = img
        else:  # window is wider: pad left and right
            nw = int(round(ih * ww / wh))
            canvas = np.full((ih, nw, 3), (23, 21, 20), np.uint8)
            view["dx"] = (nw - iw) // 2
            canvas[:, view["dx"]:view["dx"] + iw] = img
        return canvas

    def hit(xy):
        if not xy:
            return None
        x, y = xy[0] - view["dx"], xy[1] - view["dy"]
        for x0, y0, x1, y1, hid in ui.hits:
            if x0 <= x <= x1 and y0 <= y <= y1:
                return hid
        return None

    def choose_video() -> None:
        nonlocal status, status_until
        if not isinstance(source, ScreenSource):
            status, status_until = "This is the webcam test. Use run_bridge.bat for the glasses.", time.monotonic() + 5
            speaker.say("This is the webcam test. Use run bridge for the glasses.", force=True)
            return
        print("Choose the glasses video in the new window: drag a box, then press ENTER.")
        region = source.select_region()
        if region:
            cfg["region"] = region
            save_config(cfg)
            tracker.reset()
            status, status_until = "Glasses video selected", time.monotonic() + 3
        else:
            status, status_until = "No area chosen. Click Choose video to try again.", time.monotonic() + 4

    def on_mouse(event, x, y, flags, param):
        if event == cv2.EVENT_MOUSEMOVE:
            mouse["pos"] = (x, y)
        elif event == cv2.EVENT_LBUTTONUP:
            mouse["click"] = (x, y)

    cv2.namedWindow("Cue", cv2.WINDOW_NORMAL)
    cv2.resizeWindow("Cue", 1280, 720)
    cv2.setMouseCallback("Cue", on_mouse)
    print("=" * 64)
    print(f"  Cue (update {VERSION}) is running. Use the Cue window: everything is a button.")
    print(f"  Voice goes to: {speaker.route}")
    print("  Vision: " + (cfg.get("vision_model") or "AMD") if worker else "  Vision: OFF (run run_setup_vision.bat)")
    print("  This black window shows what Cue sees and says. You can ignore it.")
    print("=" * 64)
    voice_tests = 0
    if worker and (cfg.get("region") or not isinstance(source, ScreenSource)):
        # all-day coach: open straight on it, no clicks needed
        mode, session_mode, skill_name = "coach", "coach", BY_ID["coach"].name
        speaker.say("Cue is on and watching your day. If you hear me in your glasses, the voice works.", force=True)
    else:
        speaker.say("Cue is on. If you can hear me in your glasses, the voice is working.", force=True)
    cover = {"at": 0.0, "covered": False}

    def cue_covers_video() -> bool:
        """True when the Cue window sits on top of the glasses video it is supposed to watch."""
        if time.monotonic() - cover["at"] < 2.0:
            return cover["covered"]
        cover["at"] = time.monotonic()
        region = getattr(source, "region", None)
        covered = False
        try:
            if region:
                x, y, w, h = cv2.getWindowImageRect("Cue")
                ox = max(0, min(x + w, region["left"] + region["width"]) - max(x, region["left"]))
                oy = max(0, min(y + h, region["top"] + region["height"]) - max(y, region["top"]))
                covered = w > 50 and ox * oy > 0.4 * region["width"] * region["height"]
        except Exception:
            covered = False
        cover["covered"] = covered
        return covered

    last_clip_status = ""
    while True:
        loop_start = time.monotonic()
        speaker.watchdog()
        if clip is not None and clip.status != last_clip_status:
            last_clip_status = clip.status
            print(f"[Cue] {time.strftime('%H:%M:%S')}  Clip: {clip.status}")
        if worker:
            worker.poll()
        frame = source.read()
        labels = []
        if frame is not None:
            pw = cfg["process_width"]
            if frame.shape[1] > pw:
                frame = cv2.resize(frame, (pw, int(frame.shape[0] * pw / frame.shape[1])), interpolation=cv2.INTER_AREA)

            now = time.monotonic() - t0
            if mode == "gym" and worker and weight_due and time.monotonic() >= weight_due:
                weight_due = 0.0
                img = frame.copy()
                worker.submit("weight", lambda: worker.client.read_weight(img), on_weight)
            if mode == "gym" and gym_summary is None:
                active = counter
                if motion_source == "clip" and clip:
                    active = clip_counter
                    rep = None
                    for smp in clip.new_samples():
                        ang, relearned = tilt.update(smp.t - t0, smp.pitch, smp.roll, clip_counter.state == RepCounter.REST)
                        if relearned:
                            clip_counter.rebase(0.0)
                        rep = clip_counter.update(smp.t - t0, ang) or rep
                        chart.append(clip_counter.deviation)
                else:
                    pos = tracker.update(frame)
                    rep = counter.update(now, pos)
                    chart.append(counter.deviation)
                if rep:
                    if motion_source == "clip" and clip:  # curls: lift (away from rest) then lower
                        good, cue = tempo_feedback(rep, clip_target, away="up", back="down")
                        last_rep = {"away_word": "up", "back_word": "down"}
                    else:
                        good, cue = tempo_feedback(rep, target)
                        last_rep = {"away_word": "down", "back_word": "up"}
                    # form: a rep much smaller than your recent full reps is a half rep
                    is_clip = motion_source == "clip" and clip
                    half = not rep.partial and ((len(rep_depths) >= 2 and rep.depth < 0.7 * float(np.median(rep_depths)))
                                                or (is_clip and rep.depth < 60))
                    if half:
                        good, cue = False, ("All the way up and down" if is_clip else "Go a little deeper")
                    elif not rep.partial:
                        rep_depths.append(rep.depth)
                    last_rep.update(away=rep.down_time, back=rep.up_time, good=good, cue=cue)
                    speaker.say(f"{rep.number}. {cue}" if cue else str(rep.number), key="rep", cooldown=0, force=True)
                    logger.log("gym", "rep", rep.number, f"down={rep.down_time:.2f};up={rep.up_time:.2f};good={good};source={motion_source}")
                    if clip:
                        clip.buzz(GOOD if good else FIX)
                    if not good:
                        warn_until = time.monotonic() + 1.0
                    set_history.append(good)
                    last_rep_at = time.monotonic()
                    today["reps"] += 1
                    habits.add_reps(1)
                    if len(set_history) >= goal:
                        done = (clip_counter if (motion_source == "clip" and clip) else counter).reps[-goal:]
                        n_good = sum(set_history[-goal:])
                        gym_summary = {
                            "set_no": set_no, "reps": goal, "good": n_good,
                            "avg_away": float(np.mean([r.down_time for r in done])) if done else 0.0,
                            "avg_back": float(np.mean([r.up_time for r in done])) if done else 0.0,
                            "weight": weight_text, "history": list(set_history[-goal:]),
                        }
                        summary_at = time.monotonic()
                        logger.log("gym", "set_done", set_no, f"good={n_good}/{goal}")
                        speaker.say(f"Set complete. {n_good} of {goal} on tempo.", force=True)
                        if clip:
                            clip.buzz(FIX)
            elif mode in ("coach", "home"):   # the all-day coach also keeps watching on the Today screen
                wait = habit_every * (5 if worker and "429" in worker.last_error else 1)  # rate-limited: slow down
                if worker and not worker.busy and time.monotonic() - last_look >= wait:
                    last_look = time.monotonic()
                    img = frame.copy()
                    worker.submit("habits", lambda: worker.client.observe(img), on_observe)
                if time.monotonic() - last_tick > 5.0:
                    last_tick = time.monotonic()
                    speak_nudges(habits.tick())
            elif mode == "kitchen":
                if hands is None:
                    status, status_until = "Loading hand tracking...", time.monotonic() + 2
                    hands = HandTracker(flat_ratio=cfg["claw_flat_ratio"])
                if runner:
                    runner.update(frame)
                readings = hands.process(frame) if (runner is None or runner.claw_active) else []
                hands.draw(frame)
                for r in readings:
                    x, y = r.points[0].astype(int)
                    labels.append((x, y, ("flat" if r.flat else "curled") + (f" {r.ratio:.2f}" if debug else ""), r.flat))
                last_claw = None if not readings else any(r.flat for r in readings)
                if claw.update(readings):
                    if speaker.say("Curl your fingertips", key="claw", cooldown=3.0):
                        logger.log("kitchen", "claw_warning")
                        grip_warnings += 1
                        today["saves"] += 1
                        warn()
                if runner and runner.finished and kitchen_summary is None:
                    kitchen_summary = {"name": runner.skill.name, "seconds": time.monotonic() - runner._started,
                                       "steps": len(runner.skill.steps), "warnings": grip_warnings}
                    summary_at = time.monotonic()
                    today["recipes"] += 1

        # ---- draw the app screen ----
        if mouse["pos"] != last_mouse_pos:
            last_mouse_pos = mouse["pos"]
            hid = hit(mouse["pos"])
            if hid in BY_ID and mode == "home":
                focus = hid
            hover_action = hid if (hid or "").startswith(("action:", "clock:", "tab:")) else None
        active = clip_counter if (motion_source == "clip" and clip) else counter
        amd = "off" if worker is None else ("error" if worker.last_error else ("thinking" if worker.busy else "ready"))
        state = {
            "frame": frame, "mode": mode, "glasses_live": frame is not None, "labels": labels,
            "skill_name": skill_name, "hover": (hover_action or focus) if mode == "home" else hover_action, "today": today,
            "summary_age": time.monotonic() - summary_at,
            "warn": time.monotonic() < warn_until, "status": status if time.monotonic() < status_until else "",
            "clip": None if clip is None else {"connected": clip.connected, "status": clip.status},
            "version": VERSION, "amd": amd, "vision_label": "AMD" if cfg.get("vision_mode") == "amd_notebook" else "Vision", "voice_route": speaker.route, "last_voice": speaker.last_text, "debug": debug,
            "voice_age": time.monotonic() - getattr(speaker, "last_time", 0.0),
            "voice_warn": speaker.last_text in warn_lines or any(w in speaker.last_text.lower() for w in CORRECTIONS),
            "debug_text": f"{source_name} | {fps_est:4.1f} fps | sens {active.threshold:.1f} | claw {claw.flat_ratio:.2f}"
                          + (f" | clip: {clip.status}" if clip else "") + (f" | AMD: {worker.last_error[:40]}" if worker and worker.last_error else ""),
        }
        score = habits.score()
        if score != last_score:
            last_score, score_at = score, time.monotonic()
        checklist = [(cat, [(hid, name) + habits.status(hid) for hid, name in rows]) for cat, rows in CHECKLIST]

        def rail_row(label, hid, empty):
            st, detail = habits.status(hid)
            return (label, detail or empty, st if st != "todo" else "")

        state["day"] = {
            "score": score, "score_age": time.monotonic() - score_at, "clock": habits.clock.label(),
            "clock_mode": habits.clock.mode, "checklist": checklist, "coach_on": mode in ("coach", "home"),
            "seen": habits.last_seen, "note": habits.last_note,
            "obs_age": time.monotonic() - habits.last_obs_time if habits.last_obs_time else 99.0,
            "said": speaker.last_text,
            "said_age": time.monotonic() - speaker.last_time if speaker.last_time else 99.0,
            "said_warn": speaker.last_text in warn_lines,
            "voice_stuck": speaker.stuck,
            "vision_on": worker is not None,
            "vision_error": friendly_vision_error(worker.last_error) if worker else "",
            "covered": mode == "coach" and isinstance(source, ScreenSource) and cue_covers_video(),
            "has_video": frame is not None,
            "rows": [rail_row("Water", "water", "0 of 2 L"), rail_row("Morning light", "sun", "0 of 10 min"),
                     rail_row("Caffeine", "caffeine", "None yet"), rail_row("Fruit and veg", "veg", "0 of 3"),
                     rail_row("Scrolling and screens", "scroll", "None"), rail_row("Vape and nicotine", "nicotine", "Free today"),
                     rail_row("Move", "move", "Nothing yet")],
        }
        state["workouts"] = [{"id": c.id, "name": c.name, "blurb": c.blurb, "key": c.key}
                             for c in (BY_ID["curls"], BY_ID["squats"])]
        if mode == "gym":
            tgt = clip_target if active is clip_counter else target
            away_word = "Up" if active is clip_counter else "Down"
            back_word = "Down" if active is clip_counter else "Up"
            phase = {"out": away_word, "returning": back_word}.get(active.state, "Ready")
            state["gym"] = {"reps": len(set_history), "source": "clip" if active is clip_counter else "camera",
                            "goal": goal, "set_no": set_no, "history": list(set_history), "phase": phase,
                            "streak": next((i for i, g in enumerate(reversed(set_history)) if not g), len(set_history)),
                            "pop": time.monotonic() - last_rep_at, "summary": gym_summary,
                            "last": last_rep or None, "weight": weight_text, "chart": list(chart),
                            "threshold": active.threshold, "target": (tgt.down, tgt.up),
                            "clip_ok": bool(clip and clip.connected), "clip_status": clip.status if clip else "not started"}
        elif mode == "kitchen":
            state["kitchen"] = {
                "skill": runner.skill.name if runner else (skill_name or "Kitchen"),
                "steps": [st.say for st in runner.skill.steps] if runner else [],
                "index": runner.index if runner else 0, "finished": runner.finished if runner else False,
                "reason": runner.last_reason if runner else "",
                "claw_active": runner is None or runner.claw_active,
                "claw": last_claw if frame is not None else None,
                "summary": kitchen_summary,
            }
        if time.monotonic() - live_at > 0.5:  # share today's real data with the web app
            live_at = time.monotonic()
            st = dict(habits.stats.__dict__)
            st["log"] = [list(x) for x in st.get("log", [])][-20:]
            LIVE["data"] = {
                "app": "cue", "ok": True, "t": time.time(), "mode": mode, "coach_on": mode in ("coach", "home"),
                "score": habits.score(), "clock": habits.clock.label(), "clock_mode": habits.clock.mode, "stats": st,
                "status": {hid: list(habits.status(hid)) for _, rows in CHECKLIST for hid, _ in rows},
                "seen": list(habits.last_seen), "note": habits.last_note,
                "obs_age": (time.monotonic() - habits.last_obs_time) if habits.last_obs_time else None,
                "reps_today": today.get("reps", 0), "set_reps": len(set_history), "set_goal": goal,
                "last_voice": speaker.last_text, "voice_age": time.monotonic() - getattr(speaker, "last_time", 0.0),
                "glasses_live": frame is not None, "clip": {"connected": bool(clip and clip.connected)},
                "vision": "AMD" if cfg.get("vision_mode") == "amd_notebook" else (cfg.get("vision_model") or ""),
            }
        cv2.imshow("Cue", fit_window(ui.render(state)))
        if mouse["click"]:
            hid = hit(mouse["click"])
            mouse["click"] = None
            if hid == "action:choose":
                choose_video()
            elif hid == "action:voice":
                voice_tests += 1
                speaker.say(f"Voice test {voice_tests}. Can you hear me in the glasses?", force=True)
                status, status_until = f"Voice test sent to: {speaker.route}", time.monotonic() + 4
            elif hid == "action:coach":
                start_skill("coach")
            elif hid == "action:next" and mode == "gym" and gym_summary:
                next_set()
            elif hid == "action:again":
                start_skill("recipe")
            elif hid == "action:newday":
                new_day()
            elif hid == "action:clip":
                if clip is None:
                    clip = make_clip(cfg)
                    cfg["use_clip"] = True; save_config(cfg)
                    speaker.say("Looking for the clip.", force=True)
                elif clip.connected:
                    speaker.say("Clip connected.", force=True)
                else:
                    speaker.say("Still looking for the clip. Unplug it and plug it back in.", force=True)
            elif hid and hid.startswith("clock:"):
                habits.set_clock(hid.split(":", 1)[1])
                if mode == "home":
                    mode, session_mode, skill_name = "coach", "coach", BY_ID["coach"].name
                last_look = 0.0   # look again right away with the new time of day
                status, status_until = f"Clock: {habits.clock.label()}" + ("" if habits.clock.mode == "live" else " (demo)"), time.monotonic() + 3
                when = {"live": "real time", "morning": "morning", "afternoon": "afternoon", "night": "night"}[habits.clock.mode]
                speaker.say(f"It's {when} now, {habits.clock.label()}.", force=True)
            elif hid == "tab:home":
                mode = "home"
            elif hid == "tab:session" and session_mode:
                mode = session_mode
            elif hid and not hid.startswith(("tab:", "action:")) and mode == "home":
                start_skill(hid)

        # ---- keys ----
        raw = cv2.waitKeyEx(1)
        key = raw & 0xFF if raw != -1 else 255
        arrow = ARROWS.get(raw)
        if arrow and mode == "home":
            if focus is None:
                focus = "curls"
            else:
                ci = next(i for i, col in enumerate(grid) if focus in col)
                ri = grid[ci].index(focus)
                if arrow in ("left", "right"):
                    ci = max(0, min(len(grid) - 1, ci + (1 if arrow == "right" else -1)))
                    ri = min(ri, len(grid[ci]) - 1)
                else:
                    ri = max(0, min(len(grid[ci]) - 1, ri + (1 if arrow == "down" else -1)))
                focus = grid[ci][ri]
            key = 255
        if key == ord("q"):
            break
        elif key in (27, ord("h"), ord("o")):
            mode = "home"
        elif key == 13:  # Enter
            if mode == "home":
                start_skill(focus or "coach")
            elif mode == "gym" and gym_summary:
                next_set()
            elif mode == "kitchen" and kitchen_summary:
                start_skill("recipe")
        elif chr(key) in BY_KEY and mode == "home":
            start_skill(BY_KEY[chr(key)].id)
        elif key == ord("g"):
            start_skill("curls" if clip else "squats")
        elif key == ord("z"):
            habits.cycle_clock()
            last_look = 0.0
            when = {"live": "real time", "morning": "morning", "afternoon": "afternoon", "night": "night"}[habits.clock.mode]
            speaker.say(f"Clock set to {when}, {habits.clock.label()}.", force=True)
        elif key == ord("w") and worker:
            weight_due = time.monotonic()
        elif key == ord("n") and runner:
            runner.advance("manual")
        elif key == ord("d"):
            debug = not debug
        elif key == ord("s"):
            speaker.say("Cue voice test. Can you hear me in the glasses?", force=True)
        elif key == ord("r"):
            counter.reset(); clip_counter.reset(); tilt.reset(); tracker.reset(); chart.clear(); last_rep = {}
        elif key == ord("b"):
            if clip is None:
                clip = make_clip(cfg)
                cfg["use_clip"] = True; save_config(cfg)
                status, status_until = "Looking for the Cue Clip...", time.monotonic() + 4
            elif clip.connected:
                speaker.say("Clip connected", force=True)
            else:
                speaker.say("Still looking for the clip. " + clip.status[:80], force=True)
        elif key == ord("m"):
            if clip is None:
                status, status_until = "Press B first to connect the clip", time.monotonic() + 3
            else:
                motion_source = "clip" if motion_source == "camera" else "camera"
                chart.clear(); counter.reset(); clip_counter.reset(); tilt.reset(); tracker.reset()
                if motion_source == "clip" and not clip.connected:
                    speaker.say("Counting with the clip, but it isn't connected yet. Close Arduino and the clip test.", force=True)
                elif motion_source == "clip":
                    speaker.say("Counting with the clip. Hold the weight still at your side for a second, then go.", force=True)
                else:
                    speaker.say("Counting with the camera", force=True)
        elif key == ord("y") and clip:
            rhythm_on = not rhythm_on
            clip.rhythm(cfg["rhythm_period_ms"] if rhythm_on else 0)
        elif key == ord("t"):
            good = (clip_counter if (motion_source == "clip" and clip) else counter).reps[-3:]
            if len(good) >= 2 and motion_source == "clip" and clip:
                clip_target = target_from_reps(good)
                cfg["clip_tempo_away"], cfg["clip_tempo_back"] = round(clip_target.down, 2), round(clip_target.up, 2)
                save_config(cfg)
                status, status_until = f"Clip target set: up {clip_target.down:.1f}s, down {clip_target.up:.1f}s", time.monotonic() + 4
            elif len(good) >= 2:
                target = target_from_reps(good)
                cfg["tempo_down"], cfg["tempo_up"] = round(target.down, 2), round(target.up, 2)
                save_config(cfg)
                status, status_until = f"Target set: down {target.down:.1f}s, up {target.up:.1f}s", time.monotonic() + 4
            else:
                status, status_until = "Do at least 2 good reps first", time.monotonic() + 3
        elif key in (ord("+"), ord("="), ord("-"), ord("_")):
            step = 1 if key in (ord("+"), ord("=")) else -1
            if motion_source == "clip" and clip:
                clip_counter.threshold = max(3.0, round(clip_counter.threshold + 3 * step, 1))
                cfg["clip_rep_threshold"] = clip_counter.threshold
            else:
                counter.threshold = max(1.0, round(counter.threshold + step, 1))
                cfg["rep_threshold"] = counter.threshold
            save_config(cfg)
        elif key == ord("]"):
            claw.flat_ratio = round(claw.flat_ratio - 0.05, 2); cfg["claw_flat_ratio"] = claw.flat_ratio; save_config(cfg)
            if hands: hands.flat_ratio = claw.flat_ratio
        elif key == ord("["):
            claw.flat_ratio = round(claw.flat_ratio + 0.05, 2); cfg["claw_flat_ratio"] = claw.flat_ratio; save_config(cfg)
            if hands: hands.flat_ratio = claw.flat_ratio
        elif key == ord("c"):
            choose_video()

        # ---- pace the loop ----
        spent = time.monotonic() - loop_start
        if spent < frame_gap:
            time.sleep(frame_gap - spent)
        fps_est = 0.9 * fps_est + 0.1 / max(1e-3, time.monotonic() - loop_start)

    source.close()
    if clip:
        clip.close()
    if hands:
        hands.close()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    os.chdir(HERE)
    main()
